-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Oct 01, 2026 at 07:49 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `simwarga_rt007`
--

-- --------------------------------------------------------

--
-- Table structure for table `audit_log`
--

CREATE TABLE `audit_log` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `user_id` int(10) UNSIGNED DEFAULT NULL,
  `aksi` varchar(80) NOT NULL,
  `modul` varchar(80) NOT NULL,
  `referensi_id` varchar(80) DEFAULT NULL,
  `ringkasan` text DEFAULT NULL,
  `data_lama` longtext DEFAULT NULL,
  `data_baru` longtext DEFAULT NULL,
  `created_at` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `iuran_generation_log`
--

CREATE TABLE `iuran_generation_log` (
  `id` int(10) UNSIGNED NOT NULL,
  `periode` varchar(20) NOT NULL,
  `tahun` year(4) NOT NULL,
  `jenis_iuran_ids` text NOT NULL,
  `kk_diproses` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `dibuat` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `dilewati` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `total_nominal` decimal(15,2) NOT NULL DEFAULT 0.00,
  `created_by` int(10) UNSIGNED NOT NULL,
  `created_at` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `jenis_iuran`
--

CREATE TABLE `jenis_iuran` (
  `id` int(10) UNSIGNED NOT NULL,
  `kode_iuran` varchar(30) NOT NULL,
  `nama_iuran` varchar(100) NOT NULL,
  `deskripsi` varchar(255) DEFAULT NULL,
  `nominal` decimal(15,2) NOT NULL DEFAULT 0.00,
  `sifat_iuran` enum('wajib','sukarela') NOT NULL DEFAULT 'wajib',
  `periode` enum('bulanan','tahunan','sekali') NOT NULL DEFAULT 'bulanan',
  `tanggal_mulai` date DEFAULT NULL,
  `status` enum('aktif','nonaktif') NOT NULL DEFAULT 'aktif',
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `jenis_iuran`
--

INSERT INTO `jenis_iuran` (`id`, `kode_iuran`, `nama_iuran`, `deskripsi`, `nominal`, `sifat_iuran`, `periode`, `tanggal_mulai`, `status`, `created_at`, `updated_at`) VALUES
(1, 'IKL', 'Iuran Kebersihan Lingkungan', 'Biaya sampah', 15000.00, 'wajib', 'bulanan', '2026-10-01', 'aktif', '2026-09-17 05:51:37', '2026-09-17 05:51:37');

-- --------------------------------------------------------

--
-- Table structure for table `kartu_keluarga`
--

CREATE TABLE `kartu_keluarga` (
  `id` int(10) UNSIGNED NOT NULL,
  `no_kk` varchar(16) NOT NULL,
  `kepala_keluarga` varchar(150) NOT NULL,
  `kode_wilayah` varchar(50) DEFAULT NULL,
  `no_hp` varchar(20) DEFAULT NULL,
  `lampiran_kk` varchar(255) DEFAULT NULL,
  `alamat` text DEFAULT NULL,
  `status` enum('aktif','nonaktif') NOT NULL DEFAULT 'aktif',
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `kartu_keluarga`
--

INSERT INTO `kartu_keluarga` (`id`, `no_kk`, `kepala_keluarga`, `kode_wilayah`, `no_hp`, `lampiran_kk`, `alamat`, `status`, `created_at`, `updated_at`) VALUES
(1, '3216021502160007', 'WIDODO', 'AD8', '088212085663', NULL, 'Vila Gading Harapan Blok AD8 Rt007 Rw023 No 16 , Kel.Kebalen, Kec .Babelan, Kab, Bekasi , Jawa Barat Kode Pos 17610', 'aktif', '2026-09-17 03:53:35', '2026-09-18 08:55:29');

-- --------------------------------------------------------

--
-- Table structure for table `master_wilayah`
--

CREATE TABLE `master_wilayah` (
  `id` int(10) UNSIGNED NOT NULL,
  `kode` varchar(50) NOT NULL,
  `nama` varchar(150) NOT NULL,
  `jenis` enum('PROVINSI','KABUPATEN','KECAMATAN','KELURAHAN','RW','RT') NOT NULL,
  `kode_parent` varchar(50) DEFAULT NULL,
  `alamat` text DEFAULT NULL,
  `status` enum('aktif','nonaktif') NOT NULL DEFAULT 'aktif',
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `metode_pembayaran`
--

CREATE TABLE `metode_pembayaran` (
  `id` int(10) UNSIGNED NOT NULL,
  `kode` varchar(30) NOT NULL,
  `nama` varchar(100) NOT NULL,
  `status` enum('aktif','nonaktif') NOT NULL DEFAULT 'aktif',
  `keterangan` varchar(255) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `metode_pembayaran`
--

INSERT INTO `metode_pembayaran` (`id`, `kode`, `nama`, `status`, `keterangan`, `created_at`, `updated_at`) VALUES
(1, 'CASH', 'Tunai', 'aktif', NULL, '2026-09-18 07:47:07', '2026-09-18 07:47:07'),
(2, 'TRANSFER_BANK', 'Transfer Bank', 'aktif', NULL, '2026-09-18 07:47:07', '2026-09-18 07:47:07'),
(3, 'QRIS', 'QRIS', 'aktif', NULL, '2026-09-18 07:47:07', '2026-09-18 07:47:07'),
(4, 'LAINNYA', 'Lainnya', 'aktif', NULL, '2026-09-18 07:47:07', '2026-09-18 07:47:07');

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

CREATE TABLE `migrations` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `version` varchar(255) NOT NULL,
  `class` varchar(255) NOT NULL,
  `group` varchar(255) NOT NULL,
  `namespace` varchar(255) NOT NULL,
  `time` int(11) NOT NULL,
  `batch` int(11) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`id`, `version`, `class`, `group`, `namespace`, `time`, `batch`) VALUES
(16, '2026-08-12-052041', 'App\\Database\\Migrations\\CreateUsersTable', 'default', 'App', 1788949471, 1),
(17, '2026-08-12-053704', 'App\\Database\\Migrations\\CreateRolesTable', 'default', 'App', 1788949471, 1),
(18, '2026-08-12-054728', 'App\\Database\\Migrations\\CreatePermissionsTable', 'default', 'App', 1788949472, 1),
(19, '2026-08-12-055220', 'App\\Database\\Migrations\\CreateUserRolesTable', 'default', 'App', 1788949472, 1),
(20, '2026-08-12-060224', 'App\\Database\\Migrations\\CreateRolePermissionsTable', 'default', 'App', 1788949472, 1),
(21, '2026-08-27-092556', 'App\\Database\\Migrations\\CreateMasterWilayahTable', 'default', 'App', 1788949473, 1),
(22, '2026-08-31-053852', 'App\\Database\\Migrations\\CreateKartuKeluargaTable', 'default', 'App', 1788949473, 1),
(23, '2026-08-31-061833', 'App\\Database\\Migrations\\CreateWargaTable', 'default', 'App', 1788949475, 1),
(24, '2026-09-02-075622', 'App\\Database\\Migrations\\AddContactAndAttachmentsToWargaAndKartuKeluarga', 'default', 'App', 1788949694, 2),
(25, '2026-09-02-101642', 'App\\Database\\Migrations\\AddStatusPerkawinanToWarga', 'default', 'App', 1788949694, 2),
(26, '2026-09-08-092752', 'App\\Database\\Migrations\\CreateJenisIuran', 'default', 'App', 1788949694, 2),
(27, '2026-09-09-000001', 'App\\Database\\Migrations\\CreateTagihanIuran', 'default', 'App', 1788949696, 2),
(28, '2026-09-18-120000', 'App\\Database\\Migrations\\CreateIuranPengeluaranCore', 'default', 'App', 1789717651, 3),
(29, '2026-09-18-130000', 'App\\Database\\Migrations\\ConfigureFinalRolesAndSystemBackup', 'default', 'App', 1789717660, 3),
(30, '2026-09-18-140000', 'App\\Database\\Migrations\\FinalizeRbacMenuAndAccess', 'default', 'App', 1789722493, 4);

-- --------------------------------------------------------

--
-- Table structure for table `pembatalan_pembayaran_iuran`
--

CREATE TABLE `pembatalan_pembayaran_iuran` (
  `id` int(10) UNSIGNED NOT NULL,
  `pembayaran_id` int(10) UNSIGNED NOT NULL,
  `alasan` text NOT NULL,
  `dibatalkan_oleh` int(10) UNSIGNED NOT NULL,
  `dibatalkan_pada` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `pembatalan_tagihan_iuran`
--

CREATE TABLE `pembatalan_tagihan_iuran` (
  `id` int(10) UNSIGNED NOT NULL,
  `tagihan_iuran_id` int(10) UNSIGNED NOT NULL,
  `alasan` text NOT NULL,
  `dibatalkan_oleh` int(10) UNSIGNED NOT NULL,
  `dibatalkan_pada` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `pembayaran_iuran`
--

CREATE TABLE `pembayaran_iuran` (
  `id` int(10) UNSIGNED NOT NULL,
  `nomor_pembayaran` varchar(40) NOT NULL,
  `no_kk` varchar(16) NOT NULL,
  `tanggal_pembayaran` date NOT NULL,
  `total_bayar` decimal(15,2) NOT NULL DEFAULT 0.00,
  `metode_pembayaran_id` int(10) UNSIGNED NOT NULL,
  `nomor_referensi` varchar(100) DEFAULT NULL,
  `status` enum('valid','dibatalkan') NOT NULL DEFAULT 'valid',
  `keterangan` varchar(255) DEFAULT NULL,
  `created_by` int(10) UNSIGNED NOT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `pembayaran_iuran_detail`
--

CREATE TABLE `pembayaran_iuran_detail` (
  `id` int(10) UNSIGNED NOT NULL,
  `pembayaran_id` int(10) UNSIGNED NOT NULL,
  `tagihan_iuran_id` int(10) UNSIGNED NOT NULL,
  `jumlah_dialokasikan` decimal(15,2) NOT NULL DEFAULT 0.00,
  `created_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `pembayaran_iuran_lampiran`
--

CREATE TABLE `pembayaran_iuran_lampiran` (
  `id` int(10) UNSIGNED NOT NULL,
  `pembayaran_id` int(10) UNSIGNED NOT NULL,
  `nama_file` varchar(255) NOT NULL,
  `path_file` varchar(500) NOT NULL,
  `jenis_file` varchar(100) DEFAULT NULL,
  `ukuran_file` int(10) UNSIGNED DEFAULT NULL,
  `uploaded_by` int(10) UNSIGNED NOT NULL,
  `created_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `pemulihan_tagihan_iuran`
--

CREATE TABLE `pemulihan_tagihan_iuran` (
  `id` int(10) UNSIGNED NOT NULL,
  `tagihan_iuran_id` int(10) UNSIGNED NOT NULL,
  `alasan` text NOT NULL,
  `dipulihkan_oleh` int(10) UNSIGNED NOT NULL,
  `dipulihkan_pada` datetime NOT NULL,
  `konteks` enum('normal','masalah_sistem') NOT NULL DEFAULT 'normal'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `pengeluaran`
--

CREATE TABLE `pengeluaran` (
  `id` int(10) UNSIGNED NOT NULL,
  `nomor_bukti` varchar(40) NOT NULL,
  `tanggal_transaksi` date NOT NULL,
  `kategori_id` int(10) UNSIGNED NOT NULL,
  `penerima_id` int(10) UNSIGNED NOT NULL,
  `sumber_dana_id` int(10) UNSIGNED NOT NULL,
  `nominal` decimal(15,2) NOT NULL DEFAULT 0.00,
  `uraian` text NOT NULL,
  `catatan` text DEFAULT NULL,
  `status` enum('draft','menunggu_pemeriksaan','dikembalikan','menunggu_persetujuan','disetujui','ditolak') NOT NULL DEFAULT 'draft',
  `created_by` int(10) UNSIGNED NOT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `pengeluaran_kategori`
--

CREATE TABLE `pengeluaran_kategori` (
  `id` int(10) UNSIGNED NOT NULL,
  `kode` varchar(30) NOT NULL,
  `nama` varchar(100) NOT NULL,
  `status` enum('aktif','nonaktif') NOT NULL DEFAULT 'aktif',
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `pengeluaran_kategori`
--

INSERT INTO `pengeluaran_kategori` (`id`, `kode`, `nama`, `status`, `created_at`, `updated_at`) VALUES
(1, 'ADM', 'Administrasi RT', 'aktif', '2026-09-18 07:47:17', '2026-09-18 07:47:17'),
(2, 'KEB', 'Kebersihan', 'aktif', '2026-09-18 07:47:17', '2026-09-18 07:47:17'),
(3, 'KEA', 'Keamanan', 'aktif', '2026-09-18 07:47:17', '2026-09-18 07:47:17'),
(4, 'KEG', 'Kegiatan Warga', 'aktif', '2026-09-18 07:47:17', '2026-09-18 07:47:17'),
(5, 'SOS', 'Sosial', 'aktif', '2026-09-18 07:47:17', '2026-09-18 07:47:17'),
(6, 'PEM', 'Pemeliharaan Fasilitas', 'aktif', '2026-09-18 07:47:17', '2026-09-18 07:47:17'),
(7, 'RAP', 'Rapat', 'aktif', '2026-09-18 07:47:17', '2026-09-18 07:47:17'),
(8, 'OPS', 'Operasional', 'aktif', '2026-09-18 07:47:17', '2026-09-18 07:47:17'),
(9, 'LAIN', 'Lainnya', 'aktif', '2026-09-18 07:47:17', '2026-09-18 07:47:17');

-- --------------------------------------------------------

--
-- Table structure for table `pengeluaran_lampiran`
--

CREATE TABLE `pengeluaran_lampiran` (
  `id` int(10) UNSIGNED NOT NULL,
  `pengeluaran_id` int(10) UNSIGNED NOT NULL,
  `nama_file` varchar(255) NOT NULL,
  `path_file` varchar(500) NOT NULL,
  `jenis_file` varchar(100) DEFAULT NULL,
  `ukuran_file` int(10) UNSIGNED DEFAULT NULL,
  `uploaded_by` int(10) UNSIGNED NOT NULL,
  `created_at` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `pengeluaran_pemeriksaan`
--

CREATE TABLE `pengeluaran_pemeriksaan` (
  `id` int(10) UNSIGNED NOT NULL,
  `pengeluaran_id` int(10) UNSIGNED NOT NULL,
  `hasil` enum('lolos','dikembalikan') NOT NULL,
  `catatan` text DEFAULT NULL,
  `diperiksa_oleh` int(10) UNSIGNED NOT NULL,
  `diperiksa_pada` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `pengeluaran_penerima`
--

CREATE TABLE `pengeluaran_penerima` (
  `id` int(10) UNSIGNED NOT NULL,
  `nama` varchar(150) NOT NULL,
  `kontak` varchar(100) DEFAULT NULL,
  `status` enum('aktif','nonaktif') NOT NULL DEFAULT 'aktif',
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `pengeluaran_persetujuan`
--

CREATE TABLE `pengeluaran_persetujuan` (
  `id` int(10) UNSIGNED NOT NULL,
  `pengeluaran_id` int(10) UNSIGNED NOT NULL,
  `keputusan` enum('disetujui','ditolak') NOT NULL,
  `catatan` text DEFAULT NULL,
  `disetujui_oleh` int(10) UNSIGNED NOT NULL,
  `diputuskan_pada` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `permissions`
--

CREATE TABLE `permissions` (
  `id` int(10) UNSIGNED NOT NULL,
  `kode` varchar(100) NOT NULL,
  `nama` varchar(150) NOT NULL,
  `modul` varchar(100) NOT NULL,
  `aksi` varchar(50) NOT NULL,
  `deskripsi` text DEFAULT NULL,
  `status` enum('aktif','nonaktif') NOT NULL DEFAULT 'aktif',
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `permissions`
--

INSERT INTO `permissions` (`id`, `kode`, `nama`, `modul`, `aksi`, `deskripsi`, `status`, `created_at`, `updated_at`) VALUES
(1, 'tagihan_iuran.view', 'Lihat Tagihan Iuran', 'tagihan_iuran', 'view', 'Melihat daftar tagihan', 'aktif', '2026-09-18 07:47:28', '2026-09-18 07:47:28'),
(2, 'tagihan_iuran.create', 'Generate/Buat Tagihan Iuran', 'tagihan_iuran', 'create', 'Membuat tagihan', 'aktif', '2026-09-18 07:47:28', '2026-09-18 07:47:28'),
(3, 'tagihan_iuran.edit', 'Edit Tagihan Iuran', 'tagihan_iuran', 'edit', 'Mengubah tagihan yang belum dibayar', 'aktif', '2026-09-18 07:47:28', '2026-09-18 07:47:28'),
(4, 'tagihan_iuran.cancel', 'Batalkan Tagihan Iuran', 'tagihan_iuran', 'cancel', 'Membatalkan kewajiban tanpa menghapus histori', 'aktif', '2026-09-18 07:47:28', '2026-09-18 07:47:28'),
(5, 'tagihan_iuran.restore', 'Pulihkan Tagihan Iuran', 'tagihan_iuran', 'restore', 'Memulihkan tagihan yang dibatalkan', 'aktif', '2026-09-18 07:47:28', '2026-09-18 07:47:28'),
(6, 'pembayaran_iuran.create', 'Catat Pembayaran Iuran', 'pembayaran_iuran', 'create', 'Mencatat pembayaran langsung valid', 'aktif', '2026-09-18 07:47:28', '2026-09-18 07:47:28'),
(7, 'pembayaran_iuran.cancel', 'Batalkan Pembayaran Iuran', 'pembayaran_iuran', 'cancel', 'Membatalkan pembayaran dan menghitung ulang tagihan', 'aktif', '2026-09-18 07:47:28', '2026-09-18 07:47:28'),
(8, 'pengeluaran.view', 'Lihat Pengeluaran', 'pengeluaran', 'view', 'Melihat pengeluaran', 'aktif', '2026-09-18 07:47:28', '2026-09-18 07:47:28'),
(9, 'pengeluaran.create', 'Buat Pengeluaran', 'pengeluaran', 'create', 'Membuat draft pengeluaran', 'aktif', '2026-09-18 07:47:28', '2026-09-18 07:47:28'),
(10, 'pengeluaran.edit', 'Edit Pengeluaran', 'pengeluaran', 'edit', 'Mengubah pengeluaran', 'aktif', '2026-09-18 07:47:28', '2026-09-18 07:47:28'),
(11, 'pengeluaran.submit', 'Kirim Pengeluaran', 'pengeluaran', 'submit', 'Mengirim pengeluaran untuk pemeriksaan', 'aktif', '2026-09-18 07:47:28', '2026-09-18 07:47:28'),
(12, 'pengeluaran.check', 'Periksa Pengeluaran', 'pengeluaran', 'check', 'Memeriksa pengeluaran sebagai Sekretaris', 'aktif', '2026-09-18 07:47:28', '2026-09-18 07:47:28'),
(13, 'pengeluaran.approve', 'Setujui Pengeluaran', 'pengeluaran', 'approve', 'Memberi keputusan akhir', 'aktif', '2026-09-18 07:47:28', '2026-09-18 07:47:28'),
(14, 'pengeluaran.delete', 'Hapus Permanen Pengeluaran', 'pengeluaran', 'delete', 'Menghapus transaksi secara permanen dengan audit trail', 'aktif', '2026-09-18 07:47:28', '2026-09-18 07:47:28'),
(15, 'pengeluaran.master.manage', 'Kelola Master Pengeluaran', 'pengeluaran', 'master', 'Mengelola kategori, penerima dan sumber dana', 'aktif', '2026-09-18 07:47:28', '2026-09-18 07:47:28'),
(16, 'keuangan.opening_balance.manage', 'Kelola Saldo Awal', 'keuangan', 'opening_balance', 'Menetapkan saldo awal pembukuan', 'aktif', '2026-09-18 07:47:28', '2026-09-18 07:47:28'),
(17, 'system.backup', 'Backup Sistem', 'Sistem', 'backup', 'Membuat backup database/source', 'aktif', '2026-09-18 07:47:32', '2026-09-18 07:47:32'),
(18, 'system.backup.download', 'Download Backup Sistem', 'Sistem', 'backup_download', 'Mengunduh file backup', 'aktif', '2026-09-18 07:47:32', '2026-09-18 07:47:32'),
(19, 'system.restore', 'Restore Sistem', 'Sistem', 'restore', 'Melakukan restore database/source', 'aktif', '2026-09-18 07:47:32', '2026-09-18 07:47:32'),
(20, 'system.backup.history', 'Riwayat Backup Sistem', 'Sistem', 'history', 'Melihat riwayat backup', 'aktif', '2026-09-18 07:47:32', '2026-09-18 07:47:32'),
(21, 'dashboard.view', 'Lihat Dashboard', 'Dashboard', 'view', 'Melihat dashboard', 'aktif', '2026-09-18 07:47:32', '2026-09-18 07:47:32'),
(22, 'warga.view', 'Lihat Data Warga', 'Warga', 'view', 'Melihat data warga', 'aktif', '2026-09-18 07:47:32', '2026-09-18 07:47:32'),
(23, 'kk.view', 'Lihat Data Kartu Keluarga', 'Kartu Keluarga', 'view', 'Melihat data KK', 'aktif', '2026-09-18 07:47:32', '2026-09-18 07:47:32'),
(24, 'pembayaran_iuran.view', 'Lihat Pembayaran Iuran', 'Pembayaran Iuran', 'view', 'Melihat pembayaran', 'aktif', '2026-09-18 07:47:32', '2026-09-18 07:47:32'),
(25, 'laporan.view', 'Lihat Laporan', 'Laporan', 'view', 'Melihat laporan', 'aktif', '2026-09-18 07:47:32', '2026-09-18 07:47:32'),
(26, 'rbac.manage', 'Kelola User, Role & Permission', 'RBAC', 'manage', 'Mengelola akun user dan permission role', 'aktif', '2026-09-18 09:08:09', '2026-09-18 09:08:09'),
(27, 'warga.create', 'Tambah Warga', 'Warga', 'create', 'Menambah data warga', 'aktif', '2026-09-18 09:08:09', '2026-09-18 09:08:09'),
(28, 'warga.edit', 'Edit Warga', 'Warga', 'edit', 'Mengubah data warga', 'aktif', '2026-09-18 09:08:09', '2026-09-18 09:08:09'),
(29, 'warga.delete', 'Nonaktifkan Warga', 'Warga', 'delete', 'Menonaktifkan data warga', 'aktif', '2026-09-18 09:08:09', '2026-09-18 09:08:09'),
(30, 'kk.create', 'Tambah Kartu Keluarga', 'Kartu Keluarga', 'create', 'Menambah KK', 'aktif', '2026-09-18 09:08:09', '2026-09-18 09:08:09'),
(31, 'kk.edit', 'Edit Kartu Keluarga', 'Kartu Keluarga', 'edit', 'Mengubah KK', 'aktif', '2026-09-18 09:08:09', '2026-09-18 09:08:09'),
(32, 'kk.delete', 'Nonaktifkan Kartu Keluarga', 'Kartu Keluarga', 'delete', 'Menonaktifkan KK', 'aktif', '2026-09-18 09:08:09', '2026-09-18 09:08:09'),
(33, 'jenis_iuran.view', 'Lihat Jenis Iuran', 'Jenis Iuran', 'view', 'Melihat master jenis iuran', 'aktif', '2026-09-18 09:08:09', '2026-09-18 09:08:09'),
(34, 'jenis_iuran.create', 'Tambah Jenis Iuran', 'Jenis Iuran', 'create', 'Menambah jenis iuran', 'aktif', '2026-09-18 09:08:09', '2026-09-18 09:08:09'),
(35, 'jenis_iuran.edit', 'Edit Jenis Iuran', 'Jenis Iuran', 'edit', 'Mengubah master jenis iuran', 'aktif', '2026-09-18 09:08:09', '2026-09-18 09:08:09'),
(36, 'jenis_iuran.delete', 'Nonaktifkan Jenis Iuran', 'Jenis Iuran', 'delete', 'Menonaktifkan jenis iuran', 'aktif', '2026-09-18 09:08:09', '2026-09-18 09:08:09'),
(37, 'keuangan.view', 'Lihat Keuangan RT', 'Keuangan', 'view', 'Melihat ringkasan keuangan RT', 'aktif', '2026-09-18 09:08:09', '2026-09-18 09:08:09'),
(38, 'master_wilayah.view', 'Lihat Master Wilayah', 'Master Wilayah', 'view', 'Melihat master wilayah', 'aktif', '2026-09-18 09:08:09', '2026-09-18 09:08:09');

-- --------------------------------------------------------

--
-- Table structure for table `roles`
--

CREATE TABLE `roles` (
  `id` int(10) UNSIGNED NOT NULL,
  `kode` varchar(50) NOT NULL,
  `nama` varchar(100) NOT NULL,
  `deskripsi` text DEFAULT NULL,
  `status` enum('aktif','nonaktif') NOT NULL DEFAULT 'aktif',
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `roles`
--

INSERT INTO `roles` (`id`, `kode`, `nama`, `deskripsi`, `status`, `created_at`, `updated_at`) VALUES
(2, 'ADMINISTRATOR', 'Administrator', 'Pengelolaan sistem dan kewenangan administratif tingkat tertinggi. Tidak otomatis memiliki kewenangan bisnis Ketua RT.', 'aktif', '2026-09-18 07:47:32', '2026-09-18 07:47:32'),
(3, 'KETUA_RT', 'Ketua RT', 'Pimpinan operasional RT dan pemberi persetujuan akhir sesuai kewenangan.', 'aktif', '2026-09-18 07:47:32', '2026-09-18 07:47:32'),
(4, 'BENDAHARA', 'Bendahara', 'Pengelolaan iuran dan transaksi keuangan sesuai permission.', 'aktif', '2026-09-18 07:47:32', '2026-09-18 07:47:32'),
(5, 'SEKRETARIS', 'Sekretaris', 'Administrasi dan pemeriksaan pengeluaran sesuai permission.', 'aktif', '2026-09-18 07:47:32', '2026-09-18 07:47:32'),
(6, 'WARGA', 'Warga', 'Akses read-only terhadap informasi yang memang menjadi hak warga.', 'aktif', '2026-09-18 07:47:32', '2026-09-18 07:47:32');

-- --------------------------------------------------------

--
-- Table structure for table `role_permissions`
--

CREATE TABLE `role_permissions` (
  `id` int(10) UNSIGNED NOT NULL,
  `role_id` int(10) UNSIGNED NOT NULL,
  `permission_id` int(10) UNSIGNED NOT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `role_permissions`
--

INSERT INTO `role_permissions` (`id`, `role_id`, `permission_id`, `created_at`, `updated_at`) VALUES
(73, 4, 21, '2026-09-18 09:08:09', '2026-09-18 09:08:09'),
(74, 4, 33, '2026-09-18 09:08:09', '2026-09-18 09:08:09'),
(75, 4, 34, '2026-09-18 09:08:09', '2026-09-18 09:08:09'),
(76, 4, 35, '2026-09-18 09:08:09', '2026-09-18 09:08:09'),
(77, 4, 36, '2026-09-18 09:08:09', '2026-09-18 09:08:09'),
(78, 4, 1, '2026-09-18 09:08:09', '2026-09-18 09:08:09'),
(79, 4, 2, '2026-09-18 09:08:09', '2026-09-18 09:08:09'),
(80, 4, 3, '2026-09-18 09:08:09', '2026-09-18 09:08:09'),
(81, 4, 24, '2026-09-18 09:08:09', '2026-09-18 09:08:09'),
(82, 4, 6, '2026-09-18 09:08:09', '2026-09-18 09:08:09'),
(83, 4, 7, '2026-09-18 09:08:09', '2026-09-18 09:08:09'),
(84, 4, 4, '2026-09-18 09:08:09', '2026-09-18 09:08:09'),
(85, 4, 8, '2026-09-18 09:08:09', '2026-09-18 09:08:09'),
(86, 4, 9, '2026-09-18 09:08:09', '2026-09-18 09:08:09'),
(87, 4, 10, '2026-09-18 09:08:09', '2026-09-18 09:08:09'),
(88, 4, 11, '2026-09-18 09:08:09', '2026-09-18 09:08:09'),
(89, 4, 15, '2026-09-18 09:08:09', '2026-09-18 09:08:09'),
(90, 4, 37, '2026-09-18 09:08:09', '2026-09-18 09:08:09'),
(91, 4, 16, '2026-09-18 09:08:09', '2026-09-18 09:08:09'),
(92, 4, 25, '2026-09-18 09:08:09', '2026-09-18 09:08:09'),
(93, 5, 21, '2026-09-18 09:08:09', '2026-09-18 09:08:09'),
(94, 5, 22, '2026-09-18 09:08:09', '2026-09-18 09:08:09'),
(95, 5, 27, '2026-09-18 09:08:09', '2026-09-18 09:08:09'),
(96, 5, 28, '2026-09-18 09:08:09', '2026-09-18 09:08:09'),
(97, 5, 29, '2026-09-18 09:08:09', '2026-09-18 09:08:09'),
(98, 5, 23, '2026-09-18 09:08:09', '2026-09-18 09:08:09'),
(99, 5, 30, '2026-09-18 09:08:09', '2026-09-18 09:08:09'),
(100, 5, 31, '2026-09-18 09:08:09', '2026-09-18 09:08:09'),
(101, 5, 32, '2026-09-18 09:08:09', '2026-09-18 09:08:09'),
(102, 5, 1, '2026-09-18 09:08:09', '2026-09-18 09:08:09'),
(103, 5, 24, '2026-09-18 09:08:09', '2026-09-18 09:08:09'),
(104, 5, 8, '2026-09-18 09:08:09', '2026-09-18 09:08:09'),
(105, 5, 12, '2026-09-18 09:08:09', '2026-09-18 09:08:09'),
(106, 5, 25, '2026-09-18 09:08:09', '2026-09-18 09:08:09'),
(107, 6, 21, '2026-09-18 09:08:09', '2026-09-18 09:08:09'),
(108, 6, 1, '2026-09-18 09:08:09', '2026-09-18 09:08:09'),
(109, 3, 21, '2026-09-18 09:54:02', '2026-09-18 09:54:02'),
(110, 3, 23, '2026-09-18 09:54:02', '2026-09-18 09:54:02'),
(111, 3, 25, '2026-09-18 09:54:02', '2026-09-18 09:54:02'),
(112, 3, 24, '2026-09-18 09:54:02', '2026-09-18 09:54:02'),
(113, 3, 8, '2026-09-18 09:54:02', '2026-09-18 09:54:02'),
(114, 3, 1, '2026-09-18 09:54:02', '2026-09-18 09:54:02'),
(115, 3, 28, '2026-09-18 09:54:02', '2026-09-18 09:54:02'),
(116, 3, 22, '2026-09-18 09:54:02', '2026-09-18 09:54:02'),
(117, 3, 29, '2026-09-18 09:54:02', '2026-09-18 09:54:02'),
(118, 3, 27, '2026-09-18 09:54:02', '2026-09-18 09:54:02'),
(119, 3, 5, '2026-09-18 09:54:02', '2026-09-18 09:54:02'),
(120, 3, 4, '2026-09-18 09:54:02', '2026-09-18 09:54:02'),
(121, 3, 13, '2026-09-18 09:54:02', '2026-09-18 09:54:02'),
(122, 2, 21, '2026-09-18 09:54:03', '2026-09-18 09:54:03'),
(123, 2, 33, '2026-09-18 09:54:03', '2026-09-18 09:54:03'),
(124, 2, 23, '2026-09-18 09:54:03', '2026-09-18 09:54:03'),
(125, 2, 25, '2026-09-18 09:54:03', '2026-09-18 09:54:03'),
(126, 2, 38, '2026-09-18 09:54:03', '2026-09-18 09:54:03'),
(127, 2, 24, '2026-09-18 09:54:03', '2026-09-18 09:54:03'),
(128, 2, 1, '2026-09-18 09:54:03', '2026-09-18 09:54:03'),
(129, 2, 28, '2026-09-18 09:54:03', '2026-09-18 09:54:03'),
(130, 2, 22, '2026-09-18 09:54:03', '2026-09-18 09:54:03'),
(131, 2, 29, '2026-09-18 09:54:03', '2026-09-18 09:54:03'),
(132, 2, 27, '2026-09-18 09:54:03', '2026-09-18 09:54:03'),
(133, 2, 17, '2026-09-18 09:54:03', '2026-09-18 09:54:03'),
(134, 2, 18, '2026-09-18 09:54:03', '2026-09-18 09:54:03'),
(135, 2, 20, '2026-09-18 09:54:03', '2026-09-18 09:54:03'),
(136, 2, 19, '2026-09-18 09:54:03', '2026-09-18 09:54:03'),
(137, 2, 26, '2026-09-18 09:54:03', '2026-09-18 09:54:03'),
(138, 2, 5, '2026-09-18 09:54:03', '2026-09-18 09:54:03'),
(139, 2, 4, '2026-09-18 09:54:03', '2026-09-18 09:54:03');

-- --------------------------------------------------------

--
-- Table structure for table `saldo_awal_keuangan`
--

CREATE TABLE `saldo_awal_keuangan` (
  `id` int(10) UNSIGNED NOT NULL,
  `tanggal_mulai` date NOT NULL,
  `nominal` decimal(15,2) NOT NULL DEFAULT 0.00,
  `status` enum('aktif','dikoreksi') NOT NULL DEFAULT 'aktif',
  `keterangan` text DEFAULT NULL,
  `ditetapkan_oleh` int(10) UNSIGNED NOT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `sumber_dana`
--

CREATE TABLE `sumber_dana` (
  `id` int(10) UNSIGNED NOT NULL,
  `kode` varchar(30) NOT NULL,
  `nama` varchar(100) NOT NULL,
  `status` enum('aktif','nonaktif') NOT NULL DEFAULT 'aktif',
  `keterangan` varchar(255) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `sumber_dana`
--

INSERT INTO `sumber_dana` (`id`, `kode`, `nama`, `status`, `keterangan`, `created_at`, `updated_at`) VALUES
(1, 'TOTAL', 'TOTAL SUMBER DANA', 'aktif', NULL, '2026-09-18 07:47:19', '2026-09-18 07:47:19'),
(2, 'KAS_RT', 'Kas RT', 'aktif', NULL, '2026-09-18 07:47:19', '2026-09-18 07:47:19'),
(3, 'BANK_RT', 'Bank RT', 'aktif', NULL, '2026-09-18 07:47:19', '2026-09-18 07:47:19'),
(4, 'QRIS_RT', 'QRIS RT', 'aktif', NULL, '2026-09-18 07:47:19', '2026-09-18 07:47:19');

-- --------------------------------------------------------

--
-- Table structure for table `tagihan_iuran`
--

CREATE TABLE `tagihan_iuran` (
  `id` int(10) UNSIGNED NOT NULL,
  `jenis_iuran_id` int(10) UNSIGNED NOT NULL,
  `no_kk` varchar(16) NOT NULL,
  `periode` varchar(20) NOT NULL,
  `tahun` year(4) NOT NULL,
  `bulan` tinyint(2) DEFAULT NULL,
  `nominal` decimal(15,2) NOT NULL DEFAULT 0.00,
  `tanggal_tagihan` date DEFAULT NULL,
  `tanggal_jatuh_tempo` date DEFAULT NULL,
  `tanggal_bayar` date DEFAULT NULL,
  `status` enum('belum_bayar','sebagian','lunas','dibatalkan') NOT NULL DEFAULT 'belum_bayar',
  `keterangan` varchar(255) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `bulan_key` tinyint(4) GENERATED ALWAYS AS (coalesce(`bulan`,0)) STORED
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tagihan_iuran`
--

INSERT INTO `tagihan_iuran` (`id`, `jenis_iuran_id`, `no_kk`, `periode`, `tahun`, `bulan`, `nominal`, `tanggal_tagihan`, `tanggal_jatuh_tempo`, `tanggal_bayar`, `status`, `keterangan`, `created_at`, `updated_at`) VALUES
(1, 1, '3216021502160007', 'bulanan', '2026', 10, 15000.00, '2026-09-17', '2026-10-30', '2026-10-01', 'lunas', NULL, '2026-09-17 05:52:52', '2026-09-17 05:52:52');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(10) UNSIGNED NOT NULL,
  `username` varchar(100) NOT NULL,
  `password` varchar(255) NOT NULL,
  `nama_lengkap` varchar(150) NOT NULL,
  `email` varchar(150) DEFAULT NULL,
  `no_kk` varchar(16) DEFAULT NULL,
  `foto` varchar(255) DEFAULT NULL,
  `status` enum('aktif','nonaktif') NOT NULL DEFAULT 'aktif',
  `last_login` datetime DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `password`, `nama_lengkap`, `email`, `no_kk`, `foto`, `status`, `last_login`, `created_at`, `updated_at`) VALUES
(1, 'admin', '$2y$12$pBswgXONfqkxPfOnwZVW.OyVNOPG.IheCvdun2NOmT2UlcUYFRXye', 'Administrator', 'admin@simwarga.local', NULL, NULL, 'aktif', '2026-09-29 09:29:27', '2026-09-10 12:48:00', '2026-09-29 09:29:27'),
(2, 'casmun', '$2y$10$yB/0F8NQ0QaX9ISUTNnhzuStEJ7.TXDnAalpgcldDNzQ6mT4Ca2pO', 'Casmun', 'aplwidodo1@gmail.com', NULL, NULL, 'aktif', '2026-09-18 10:28:22', '2026-09-18 09:24:00', '2026-09-18 10:28:22');

-- --------------------------------------------------------

--
-- Table structure for table `user_roles`
--

CREATE TABLE `user_roles` (
  `id` int(10) UNSIGNED NOT NULL,
  `user_id` int(10) UNSIGNED NOT NULL,
  `role_id` int(10) UNSIGNED NOT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `user_roles`
--

INSERT INTO `user_roles` (`id`, `user_id`, `role_id`, `created_at`, `updated_at`) VALUES
(1, 1, 2, '2026-09-10 13:05:47', '2026-09-18 07:47:32'),
(2, 2, 3, '2026-09-18 09:24:00', '2026-09-18 09:24:00');

-- --------------------------------------------------------

--
-- Table structure for table `warga`
--

CREATE TABLE `warga` (
  `id` int(10) UNSIGNED NOT NULL,
  `nik` varchar(16) NOT NULL,
  `no_kk` varchar(16) NOT NULL,
  `nama_lengkap` varchar(150) NOT NULL,
  `jenis_kelamin` enum('L','P') NOT NULL,
  `tempat_lahir` varchar(100) DEFAULT NULL,
  `tanggal_lahir` date DEFAULT NULL,
  `agama` varchar(30) DEFAULT NULL,
  `pendidikan` varchar(100) DEFAULT NULL,
  `pekerjaan` varchar(100) DEFAULT NULL,
  `no_hp` varchar(20) DEFAULT NULL,
  `lampiran_ktp` varchar(255) DEFAULT NULL,
  `hubungan_keluarga` enum('KEPALA_KELUARGA','ISTRI','ANAK','ORANG_TUA','FAMILI_LAIN','LAINNYA') NOT NULL,
  `status_perkawinan` enum('KAWIN','BELUM_KAWIN','JANDA','DUDA','MENINGGAL','LAIN_LAIN') NOT NULL DEFAULT 'BELUM_KAWIN',
  `status` enum('aktif','nonaktif') NOT NULL DEFAULT 'aktif',
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `warga`
--

INSERT INTO `warga` (`id`, `nik`, `no_kk`, `nama_lengkap`, `jenis_kelamin`, `tempat_lahir`, `tanggal_lahir`, `agama`, `pendidikan`, `pekerjaan`, `no_hp`, `lampiran_ktp`, `hubungan_keluarga`, `status_perkawinan`, `status`, `created_at`, `updated_at`) VALUES
(6, '3175070104830006', '3216021502160007', 'WIDODO', 'L', 'JAKARTA', '1983-04-01', 'ISLAM', 'S1', 'Wiraswasta1', '088212085663', '1789721698_715883b1159204d50d96.jpeg', 'KEPALA_KELUARGA', 'KAWIN', 'aktif', '2026-09-17 03:53:35', '2026-09-18 08:55:29'),
(7, '3275036003850015', '3216021502160007', 'HENI YULITA', 'P', 'JAKARTA', '1985-03-20', 'ISLAM', 'S1', 'GURU', '088212085663', '1789721665_a052020556274e0ff500.jpeg', 'ISTRI', 'KAWIN', 'aktif', '2026-09-17 03:56:06', '2026-09-18 08:54:25');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `audit_log`
--
ALTER TABLE `audit_log`
  ADD PRIMARY KEY (`id`),
  ADD KEY `modul_aksi` (`modul`,`aksi`);

--
-- Indexes for table `iuran_generation_log`
--
ALTER TABLE `iuran_generation_log`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `jenis_iuran`
--
ALTER TABLE `jenis_iuran`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `kode_iuran` (`kode_iuran`);

--
-- Indexes for table `kartu_keluarga`
--
ALTER TABLE `kartu_keluarga`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `no_kk` (`no_kk`),
  ADD KEY `kode_wilayah` (`kode_wilayah`),
  ADD KEY `status` (`status`);

--
-- Indexes for table `master_wilayah`
--
ALTER TABLE `master_wilayah`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `kode` (`kode`),
  ADD KEY `jenis` (`jenis`),
  ADD KEY `kode_parent` (`kode_parent`);

--
-- Indexes for table `metode_pembayaran`
--
ALTER TABLE `metode_pembayaran`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `kode` (`kode`);

--
-- Indexes for table `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `pembatalan_pembayaran_iuran`
--
ALTER TABLE `pembatalan_pembayaran_iuran`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `pembayaran_id` (`pembayaran_id`);

--
-- Indexes for table `pembatalan_tagihan_iuran`
--
ALTER TABLE `pembatalan_tagihan_iuran`
  ADD PRIMARY KEY (`id`),
  ADD KEY `tagihan_iuran_id` (`tagihan_iuran_id`);

--
-- Indexes for table `pembayaran_iuran`
--
ALTER TABLE `pembayaran_iuran`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `nomor_pembayaran` (`nomor_pembayaran`),
  ADD KEY `no_kk` (`no_kk`),
  ADD KEY `status` (`status`),
  ADD KEY `fk_pembayaran_metode` (`metode_pembayaran_id`);

--
-- Indexes for table `pembayaran_iuran_detail`
--
ALTER TABLE `pembayaran_iuran_detail`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `pembayaran_id_tagihan_iuran_id` (`pembayaran_id`,`tagihan_iuran_id`),
  ADD KEY `tagihan_iuran_id` (`tagihan_iuran_id`);

--
-- Indexes for table `pembayaran_iuran_lampiran`
--
ALTER TABLE `pembayaran_iuran_lampiran`
  ADD PRIMARY KEY (`id`),
  ADD KEY `pembayaran_id` (`pembayaran_id`);

--
-- Indexes for table `pemulihan_tagihan_iuran`
--
ALTER TABLE `pemulihan_tagihan_iuran`
  ADD PRIMARY KEY (`id`),
  ADD KEY `tagihan_iuran_id` (`tagihan_iuran_id`);

--
-- Indexes for table `pengeluaran`
--
ALTER TABLE `pengeluaran`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `nomor_bukti` (`nomor_bukti`),
  ADD KEY `status_tanggal_transaksi` (`status`,`tanggal_transaksi`),
  ADD KEY `fk_pengeluaran_kategori` (`kategori_id`),
  ADD KEY `fk_pengeluaran_penerima` (`penerima_id`),
  ADD KEY `fk_pengeluaran_sumber` (`sumber_dana_id`);

--
-- Indexes for table `pengeluaran_kategori`
--
ALTER TABLE `pengeluaran_kategori`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `kode` (`kode`);

--
-- Indexes for table `pengeluaran_lampiran`
--
ALTER TABLE `pengeluaran_lampiran`
  ADD PRIMARY KEY (`id`),
  ADD KEY `pengeluaran_id` (`pengeluaran_id`);

--
-- Indexes for table `pengeluaran_pemeriksaan`
--
ALTER TABLE `pengeluaran_pemeriksaan`
  ADD PRIMARY KEY (`id`),
  ADD KEY `pengeluaran_id` (`pengeluaran_id`);

--
-- Indexes for table `pengeluaran_penerima`
--
ALTER TABLE `pengeluaran_penerima`
  ADD PRIMARY KEY (`id`),
  ADD KEY `status` (`status`);

--
-- Indexes for table `pengeluaran_persetujuan`
--
ALTER TABLE `pengeluaran_persetujuan`
  ADD PRIMARY KEY (`id`),
  ADD KEY `pengeluaran_id` (`pengeluaran_id`);

--
-- Indexes for table `permissions`
--
ALTER TABLE `permissions`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `kode` (`kode`),
  ADD KEY `modul` (`modul`);

--
-- Indexes for table `roles`
--
ALTER TABLE `roles`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `kode` (`kode`);

--
-- Indexes for table `role_permissions`
--
ALTER TABLE `role_permissions`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `role_id_permission_id` (`role_id`,`permission_id`),
  ADD KEY `role_permissions_permission_id_foreign` (`permission_id`);

--
-- Indexes for table `saldo_awal_keuangan`
--
ALTER TABLE `saldo_awal_keuangan`
  ADD PRIMARY KEY (`id`),
  ADD KEY `status` (`status`);

--
-- Indexes for table `sumber_dana`
--
ALTER TABLE `sumber_dana`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `kode` (`kode`);

--
-- Indexes for table `tagihan_iuran`
--
ALTER TABLE `tagihan_iuran`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `uq_tagihan_kk_jenis_periode` (`no_kk`,`jenis_iuran_id`,`periode`,`tahun`,`bulan_key`),
  ADD KEY `jenis_iuran_id` (`jenis_iuran_id`),
  ADD KEY `no_kk` (`no_kk`),
  ADD KEY `status` (`status`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`),
  ADD KEY `idx_users_no_kk` (`no_kk`);

--
-- Indexes for table `user_roles`
--
ALTER TABLE `user_roles`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `user_id_role_id` (`user_id`,`role_id`),
  ADD KEY `user_roles_role_id_foreign` (`role_id`);

--
-- Indexes for table `warga`
--
ALTER TABLE `warga`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `nik` (`nik`),
  ADD KEY `no_kk` (`no_kk`),
  ADD KEY `nama_lengkap` (`nama_lengkap`),
  ADD KEY `jenis_kelamin` (`jenis_kelamin`),
  ADD KEY `status` (`status`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `audit_log`
--
ALTER TABLE `audit_log`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `iuran_generation_log`
--
ALTER TABLE `iuran_generation_log`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `jenis_iuran`
--
ALTER TABLE `jenis_iuran`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `kartu_keluarga`
--
ALTER TABLE `kartu_keluarga`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `master_wilayah`
--
ALTER TABLE `master_wilayah`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `metode_pembayaran`
--
ALTER TABLE `metode_pembayaran`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=31;

--
-- AUTO_INCREMENT for table `pembatalan_pembayaran_iuran`
--
ALTER TABLE `pembatalan_pembayaran_iuran`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `pembatalan_tagihan_iuran`
--
ALTER TABLE `pembatalan_tagihan_iuran`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `pembayaran_iuran`
--
ALTER TABLE `pembayaran_iuran`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `pembayaran_iuran_detail`
--
ALTER TABLE `pembayaran_iuran_detail`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `pembayaran_iuran_lampiran`
--
ALTER TABLE `pembayaran_iuran_lampiran`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `pemulihan_tagihan_iuran`
--
ALTER TABLE `pemulihan_tagihan_iuran`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `pengeluaran`
--
ALTER TABLE `pengeluaran`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `pengeluaran_kategori`
--
ALTER TABLE `pengeluaran_kategori`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `pengeluaran_lampiran`
--
ALTER TABLE `pengeluaran_lampiran`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `pengeluaran_pemeriksaan`
--
ALTER TABLE `pengeluaran_pemeriksaan`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `pengeluaran_penerima`
--
ALTER TABLE `pengeluaran_penerima`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `pengeluaran_persetujuan`
--
ALTER TABLE `pengeluaran_persetujuan`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `permissions`
--
ALTER TABLE `permissions`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=39;

--
-- AUTO_INCREMENT for table `roles`
--
ALTER TABLE `roles`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `role_permissions`
--
ALTER TABLE `role_permissions`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=140;

--
-- AUTO_INCREMENT for table `saldo_awal_keuangan`
--
ALTER TABLE `saldo_awal_keuangan`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `sumber_dana`
--
ALTER TABLE `sumber_dana`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `tagihan_iuran`
--
ALTER TABLE `tagihan_iuran`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `user_roles`
--
ALTER TABLE `user_roles`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `warga`
--
ALTER TABLE `warga`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `pembatalan_tagihan_iuran`
--
ALTER TABLE `pembatalan_tagihan_iuran`
  ADD CONSTRAINT `fk_batal_tagihan` FOREIGN KEY (`tagihan_iuran_id`) REFERENCES `tagihan_iuran` (`id`) ON UPDATE CASCADE;

--
-- Constraints for table `pembayaran_iuran`
--
ALTER TABLE `pembayaran_iuran`
  ADD CONSTRAINT `fk_pembayaran_metode` FOREIGN KEY (`metode_pembayaran_id`) REFERENCES `metode_pembayaran` (`id`) ON UPDATE CASCADE;

--
-- Constraints for table `pembayaran_iuran_detail`
--
ALTER TABLE `pembayaran_iuran_detail`
  ADD CONSTRAINT `fk_pembayaran_detail_payment` FOREIGN KEY (`pembayaran_id`) REFERENCES `pembayaran_iuran` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_pembayaran_detail_tagihan` FOREIGN KEY (`tagihan_iuran_id`) REFERENCES `tagihan_iuran` (`id`) ON UPDATE CASCADE;

--
-- Constraints for table `pembayaran_iuran_lampiran`
--
ALTER TABLE `pembayaran_iuran_lampiran`
  ADD CONSTRAINT `fk_pembayaran_lampiran` FOREIGN KEY (`pembayaran_id`) REFERENCES `pembayaran_iuran` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `pemulihan_tagihan_iuran`
--
ALTER TABLE `pemulihan_tagihan_iuran`
  ADD CONSTRAINT `fk_restore_tagihan` FOREIGN KEY (`tagihan_iuran_id`) REFERENCES `tagihan_iuran` (`id`) ON UPDATE CASCADE;

--
-- Constraints for table `pengeluaran`
--
ALTER TABLE `pengeluaran`
  ADD CONSTRAINT `fk_pengeluaran_kategori` FOREIGN KEY (`kategori_id`) REFERENCES `pengeluaran_kategori` (`id`) ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_pengeluaran_penerima` FOREIGN KEY (`penerima_id`) REFERENCES `pengeluaran_penerima` (`id`) ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_pengeluaran_sumber` FOREIGN KEY (`sumber_dana_id`) REFERENCES `sumber_dana` (`id`) ON UPDATE CASCADE;

--
-- Constraints for table `pengeluaran_lampiran`
--
ALTER TABLE `pengeluaran_lampiran`
  ADD CONSTRAINT `fk_pengeluaran_lampiran` FOREIGN KEY (`pengeluaran_id`) REFERENCES `pengeluaran` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `pengeluaran_pemeriksaan`
--
ALTER TABLE `pengeluaran_pemeriksaan`
  ADD CONSTRAINT `fk_pemeriksaan_pengeluaran` FOREIGN KEY (`pengeluaran_id`) REFERENCES `pengeluaran` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `pengeluaran_persetujuan`
--
ALTER TABLE `pengeluaran_persetujuan`
  ADD CONSTRAINT `fk_persetujuan_pengeluaran` FOREIGN KEY (`pengeluaran_id`) REFERENCES `pengeluaran` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `role_permissions`
--
ALTER TABLE `role_permissions`
  ADD CONSTRAINT `role_permissions_permission_id_foreign` FOREIGN KEY (`permission_id`) REFERENCES `permissions` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `role_permissions_role_id_foreign` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `tagihan_iuran`
--
ALTER TABLE `tagihan_iuran`
  ADD CONSTRAINT `fk_tagihan_iuran_jenis` FOREIGN KEY (`jenis_iuran_id`) REFERENCES `jenis_iuran` (`id`) ON UPDATE CASCADE;

--
-- Constraints for table `users`
--
ALTER TABLE `users`
  ADD CONSTRAINT `fk_users_no_kk` FOREIGN KEY (`no_kk`) REFERENCES `kartu_keluarga` (`no_kk`) ON DELETE SET NULL ON UPDATE CASCADE;

--
-- Constraints for table `user_roles`
--
ALTER TABLE `user_roles`
  ADD CONSTRAINT `user_roles_role_id_foreign` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `user_roles_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
