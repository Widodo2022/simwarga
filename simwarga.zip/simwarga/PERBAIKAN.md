# SIMWARGA - Perbaikan

Perbaikan ini mempertahankan nama tabel, kolom, route utama, dan struktur menu yang sudah ada.

## Perbaikan utama
- Kartu Keluarga: validasi KK, validasi NIK, cek duplikasi, transaksi database, dan sinkronisasi kepala keluarga.
- Warga: upload KTP dibuat lebih aman terhadap folder upload yang belum tersedia.
- Status perkawinan diselaraskan dengan enum database: `KAWIN`, `BELUM_KAWIN`, `JANDA`, `DUDA`, `MENINGGAL`, `LAIN_LAIN`.
- Tagihan Iuran: model dilengkapi seluruh method yang dipanggil controller.
- Tagihan Iuran: tambah, edit, detail, tandai lunas, batalkan, dan status.
- Routes Tagihan dilengkapi endpoint yang sebelumnya belum tersedia.
- Sidebar diperbaiki dari markup HTML yang rusak dan link yang tidak bekerja.
- Mobile sidebar/offcanvas diperbaiki.
- Footer diperbaiki agar tidak memiliki tag `<script>` yang rusak dan Bootstrap JS dimuat dengan benar.
- Redirect controller menggunakan `site_url()` agar benar ketika aplikasi berada di subfolder.
- `baseURL` diperbaiki dari nilai yang memiliki spasi di akhir.
- Dashboard menampilkan statistik database nyata.
- Menu Keuangan RT dan Laporan dibuat menjadi halaman ringkasan tanpa menambah tabel database.
- Migration dibuat lebih aman untuk database yang sudah memiliki kolom/tabel tertentu; tidak perlu `migrate:refresh`.

## Setelah menyalin project

Jalankan:

```bash
cd /opt/lampp/htdocs/simwarga

php spark cache:clear
php spark migrate:status
php spark migrate
```

**Jangan gunakan `php spark migrate:refresh` pada database yang berisi data penting.**

Jika memakai database hasil export SQL yang disertakan terpisah, import SQL tersebut melalui phpMyAdmin terlebih dahulu.

Pastikan `app/Config/App.php` memiliki `baseURL` yang sesuai alamat server. Pada paket ini sudah disesuaikan dengan alamat server yang terlihat pada project.
