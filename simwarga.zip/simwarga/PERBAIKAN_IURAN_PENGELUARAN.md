# SIMWARGA - Implementasi Iuran & Pengeluaran

Build ini dibuat dari baseline `simwarga_fixed.zip` dan **belum dipasang ke server produksi**.

## Prinsip Iuran yang dikunci
- Satu tagihan = satu kewajiban.
- Satu pembayaran = satu transaksi penerimaan uang.
- Satu pembayaran dapat memiliki banyak alokasi ke banyak tagihan.
- Cara pembayaran: Per Tagihan, Semua Jenis Iuran, Semua Tagihan sampai Periode Tertentu.
- Pembayaran cash/transfer/QRIS tetap wajib memiliki minimal 1 bukti.
- Tidak ada denda.
- Pembayaran yang sudah valid tidak diedit langsung; pembatalan memakai mekanisme khusus.
- Tagihan yang sudah memiliki pembayaran valid tidak boleh dibatalkan langsung.
- Tagihan dibatalkan menjadi DIBATALKAN, tidak dihapus.
- Restore tagihan: Ketua RT; Administrator hanya untuk masalah sistem.
- Tagihan yang pernah dibatalkan tidak boleh dibuat ulang dengan kombinasi KK + jenis + periode + tahun + bulan yang sama.
- Nominal tagihan adalah snapshot saat tagihan dibuat.

## Prinsip Pengeluaran yang dikunci
- Nomor bukti otomatis `BK-YYYY-NNNN` dan nomor tidak dipakai ulang setelah penghapusan.
- Workflow: DRAFT -> MENUNGGU PEMERIKSAAN -> MENUNGGU PERSETUJUAN -> DISETUJUI.
- Sekretaris memeriksa; Ketua RT memberi keputusan akhir.
- Pembuat transaksi tidak boleh menyetujui transaksi sendiri.
- DIKEMBALIKAN dapat diperbaiki dan dikirim kembali.
- DITOLAK tidak dapat dikirim kembali.
- Pengeluaran yang sudah disetujui jika diedit kembali ke pemeriksaan.
- Bukti transaksi minimal 1 dan dapat lebih dari satu.
- Kategori, penerima, dan sumber dana adalah master.
- `TOTAL SUMBER DANA` adalah sumber agregat dan tidak otomatis mengurangi saldo sumber tertentu.
- Saldo awal adalah satu saldo awal seluruh pembukuan dan ditetapkan sekali.
- Tidak ada fitur transfer dana antar sumber.
- Penghapusan pengeluaran permanen, tetapi audit trail tetap disimpan.

## Permission yang disiapkan
Permission baru dimasukkan sebagai master, tetapi **belum otomatis diberikan ke role**.

- tagihan_iuran.view
- tagihan_iuran.create
- tagihan_iuran.edit
- tagihan_iuran.cancel
- tagihan_iuran.restore
- pembayaran_iuran.create
- pembayaran_iuran.cancel
- pengeluaran.view
- pengeluaran.create
- pengeluaran.edit
- pengeluaran.submit
- pengeluaran.check
- pengeluaran.approve
- pengeluaran.delete
- pengeluaran.master.manage
- keuangan.opening_balance.manage

Pemberian permission ke role dilakukan pada tahap RBAC setelah modul bisnis dinyatakan stabil.

## File utama
- `app/Database/Migrations/2026-09-18-120000_CreateIuranPengeluaranCore.php`
- `app/Controllers/TagihanIuran.php`
- `app/Controllers/Pengeluaran.php`
- `app/Controllers/PengeluaranMaster.php`
- `app/Controllers/Keuangan.php`
- `app/Models/TagihanIuranModel.php`
- `app/Models/PembayaranIuranModel.php`
- `app/Models/PembayaranIuranDetailModel.php`
- `app/Models/PengeluaranModel.php`
- `app/Models/SaldoAwalKeuanganModel.php`
- `app/Models/AuditLogModel.php`

## Instalasi ke server
1. Backup source dan database terlebih dahulu.
2. Jangan menjalankan `migrate:refresh`.
3. Salin build ke server secara terkontrol.
4. Pastikan database masih `simwarga_rt007`.
5. Jalankan hanya migration baru:
   `/opt/lampp/bin/php spark migrate`
6. Periksa `migrate:status`.
7. Login dan uji menu Iuran/Pengeluaran.
8. Setelah stabil, baru lanjutkan pengaturan RBAC role/permission.

## Catatan validasi
Semua file PHP pada `app/` telah diperiksa dengan `php -l` pada lingkungan build.
Pengujian `spark` penuh tidak dapat dilakukan di container build karena PHP CLI container tidak memiliki ekstensi `mbstring` yang dibutuhkan vendor CodeIgniter. Di server SIMWARGA gunakan `/opt/lampp/bin/php` XAMPP.
