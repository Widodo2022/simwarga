<?php

namespace App\Models;

use CodeIgniter\Model;

class RolePermissionModel extends Model
{
    protected $table            = 'role_permissions';
    protected $primaryKey       = 'id';
    protected $useAutoIncrement = true;
    protected $returnType       = 'array';

    protected $allowedFields = [
        'role_id',
        'permission_id',
    ];

    protected $useTimestamps = true;

    protected $createdField = 'created_at';
    protected $updatedField = 'updated_at';

    /**
     * Ambil seluruh permission milik role.
     */
    public function getPermissionsByRole(int $roleId): array
    {
        return $this->select('permissions.*')
            ->join(
                'permissions',
                'permissions.id = role_permissions.permission_id'
            )
            ->where('role_permissions.role_id', $roleId)
            ->where('permissions.status', 'aktif')
            ->findAll();
    }

    /**
     * Cek apakah role mempunyai permission tertentu.
     */
    public function hasPermission(
        int $roleId,
        string $permissionCode
    ): bool {
        return $this->join(
                'permissions',
                'permissions.id = role_permissions.permission_id'
            )
            ->where('role_permissions.role_id', $roleId)
            ->where('permissions.kode', $permissionCode)
            ->where('permissions.status', 'aktif')
            ->countAllResults() > 0;
    }
}