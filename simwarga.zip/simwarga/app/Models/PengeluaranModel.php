<?php
namespace App\Models;
use CodeIgniter\Model;
class PengeluaranModel extends Model
{
    protected $table='pengeluaran'; protected $returnType='array'; protected $allowedFields=['nomor_bukti','tanggal_transaksi','kategori_id','penerima_id','sumber_dana_id','nominal','uraian','catatan','status','created_by']; protected $useTimestamps=true;
    public function generateNumber(): string { $year=date('Y'); $row=$this->select('nomor_bukti')->like('nomor_bukti','BK-'.$year.'-','after')->orderBy('id','DESC')->first(); $n=$row?(int)substr($row['nomor_bukti'],-4):0; return sprintf('BK-%s-%04d',$year,$n+1); }
    public function totalApproved(): float { $r=$this->where('status','disetujui')->selectSum('nominal')->get()->getRow('nominal'); return (float)($r??0); }
    public function getList(): array { return $this->select('pengeluaran.*, pengeluaran_kategori.nama kategori_nama, pengeluaran_penerima.nama penerima_nama, sumber_dana.nama sumber_nama')->join('pengeluaran_kategori','pengeluaran_kategori.id=pengeluaran.kategori_id','left')->join('pengeluaran_penerima','pengeluaran_penerima.id=pengeluaran.penerima_id','left')->join('sumber_dana','sumber_dana.id=pengeluaran.sumber_dana_id','left')->orderBy('tanggal_transaksi','DESC')->orderBy('id','DESC')->findAll(); }
    public function getOne(int $id): ?array { return $this->select('pengeluaran.*, pengeluaran_kategori.nama kategori_nama, pengeluaran_penerima.nama penerima_nama, sumber_dana.nama sumber_nama')->join('pengeluaran_kategori','pengeluaran_kategori.id=pengeluaran.kategori_id','left')->join('pengeluaran_penerima','pengeluaran_penerima.id=pengeluaran.penerima_id','left')->join('sumber_dana','sumber_dana.id=pengeluaran.sumber_dana_id','left')->where('pengeluaran.id',$id)->first(); }
}
