<?php
namespace App\Models;
use CodeIgniter\Model;
class AuditLogModel extends Model
{
    protected $table='audit_log'; protected $primaryKey='id'; protected $returnType='array'; protected $useTimestamps=false;
    protected $allowedFields=['user_id','aksi','modul','referensi_id','ringkasan','data_lama','data_baru','created_at'];
    public function log(string $aksi,string $modul,?string $ref,?string $ringkasan,?array $lama=null,?array $baru=null): void
    {
        $this->insert(['user_id'=>session()->get('user_id'),'aksi'=>$aksi,'modul'=>$modul,'referensi_id'=>$ref,'ringkasan'=>$ringkasan,'data_lama'=>$lama?json_encode($lama,JSON_UNESCAPED_UNICODE):null,'data_baru'=>$baru?json_encode($baru,JSON_UNESCAPED_UNICODE):null,'created_at'=>date('Y-m-d H:i:s')]);
    }
}
