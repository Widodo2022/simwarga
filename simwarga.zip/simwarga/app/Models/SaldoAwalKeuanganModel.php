<?php
namespace App\Models; use CodeIgniter\Model;
class SaldoAwalKeuanganModel extends Model { protected $table='saldo_awal_keuangan'; protected $returnType='array'; protected $allowedFields=['tanggal_mulai','nominal','status','keterangan','ditetapkan_oleh']; protected $useTimestamps=true; }
