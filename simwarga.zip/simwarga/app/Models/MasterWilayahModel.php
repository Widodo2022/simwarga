<?php

namespace App\Models;

use CodeIgniter\Model;

class MasterWilayahModel extends Model
{
    protected $table            = 'master_wilayah';
    protected $primaryKey       = 'id';
    protected $useAutoIncrement = true;
    protected $returnType       = 'array';
    protected $useSoftDeletes   = false;
    protected $protectFields    = true;

    protected $allowedFields = [
        'kode',
        'nama',
        'jenis',
        'kode_parent',
        'alamat',
        'status',
    ];

    protected $useTimestamps = true;
    protected $dateFormat    = 'datetime';
    protected $createdField  = 'created_at';
    protected $updatedField  = 'updated_at';

    protected $validationRules = [
        'kode'   => 'required|max_length[50]',
        'nama'   => 'required|max_length[150]',
        'jenis'  => 'required|in_list[PROVINSI,KABUPATEN,KECAMATAN,KELURAHAN,RW,RT]',
        'status' => 'required|in_list[aktif,nonaktif]',
    ];

    protected $validationMessages = [];

    protected $skipValidation = false;

    protected $allowCallbacks = true;
}