<?php
namespace App\Models; use CodeIgniter\Model;
class PengeluaranLampiranModel extends Model { protected $table='pengeluaran_lampiran'; protected $returnType='array'; protected $allowedFields=['pengeluaran_id','nama_file','path_file','jenis_file','ukuran_file','uploaded_by']; protected $useTimestamps=false; }
