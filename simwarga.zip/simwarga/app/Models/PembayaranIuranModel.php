<?php
namespace App\Models;
use CodeIgniter\Model;
class PembayaranIuranModel extends Model
{
    protected $table='pembayaran_iuran'; protected $returnType='array'; protected $allowedFields=['nomor_pembayaran','no_kk','tanggal_pembayaran','total_bayar','metode_pembayaran_id','nomor_referensi','status','keterangan','created_by']; protected $useTimestamps=true;
    public function generateNumber(): string { $year=date('Y'); $row=$this->select('nomor_pembayaran')->like('nomor_pembayaran','PAY-'.$year.'-','after')->orderBy('id','DESC')->first(); $n=$row?(int)substr($row['nomor_pembayaran'],-4):0; return sprintf('PAY-%s-%04d',$year,$n+1); }
    public function totalValid(): float { $r=$this->where('status','valid')->selectSum('total_bayar')->get()->getRow('total_bayar'); return (float)($r??0); }
    public function getList(): array { return $this->select('pembayaran_iuran.*, metode_pembayaran.nama metode_nama')->join('metode_pembayaran','metode_pembayaran.id=pembayaran_iuran.metode_pembayaran_id','left')->orderBy('tanggal_pembayaran','DESC')->orderBy('id','DESC')->findAll(); }
}
