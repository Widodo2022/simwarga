<?php
namespace App\Models; use CodeIgniter\Model;
class PengeluaranPenerimaModel extends Model { protected $table='pengeluaran_penerima'; protected $returnType='array'; protected $allowedFields=['nama','kontak','status']; protected $useTimestamps=true; }
