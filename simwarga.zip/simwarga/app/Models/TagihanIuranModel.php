<?php
namespace App\Models;
use CodeIgniter\Model;

class TagihanIuranModel extends Model
{
    protected $table='tagihan_iuran'; protected $primaryKey='id'; protected $returnType='array'; protected $allowedFields=['jenis_iuran_id','no_kk','periode','tahun','bulan','nominal','tanggal_tagihan','tanggal_jatuh_tempo','tanggal_bayar','status','keterangan']; protected $useTimestamps=true;
    protected $validationRules=['jenis_iuran_id'=>'required|is_natural_no_zero','no_kk'=>'required|exact_length[16]|numeric','periode'=>'required|in_list[bulanan,tahunan,sekali]','tahun'=>'required|numeric','bulan'=>'permit_empty|is_natural|greater_than_equal_to[1]|less_than_equal_to[12]','nominal'=>'required|numeric|greater_than_equal_to[0]','tanggal_tagihan'=>'permit_empty|valid_date[Y-m-d]','tanggal_jatuh_tempo'=>'permit_empty|valid_date[Y-m-d]','status'=>'required|in_list[belum_bayar,sebagian,lunas,dibatalkan]','keterangan'=>'permit_empty|max_length[255]'];
    public function getTagihanLengkap(?string $noKK=null): array { if ($noKK !== null) $this->where('tagihan_iuran.no_kk', $noKK); return $this->select('tagihan_iuran.*, jenis_iuran.kode_iuran, jenis_iuran.nama_iuran, kartu_keluarga.kepala_keluarga')->join('jenis_iuran','jenis_iuran.id=tagihan_iuran.jenis_iuran_id','left')->join('kartu_keluarga','kartu_keluarga.no_kk=tagihan_iuran.no_kk','left')->orderBy('tahun','DESC')->orderBy('bulan','DESC')->orderBy('id','DESC')->findAll(); }
    public function getTagihanLengkapById(int $id, ?string $noKK=null): ?array { if ($noKK !== null) $this->where('tagihan_iuran.no_kk', $noKK); return $this->select('tagihan_iuran.*, jenis_iuran.kode_iuran, jenis_iuran.nama_iuran, kartu_keluarga.kepala_keluarga')->join('jenis_iuran','jenis_iuran.id=tagihan_iuran.jenis_iuran_id','left')->join('kartu_keluarga','kartu_keluarga.no_kk=tagihan_iuran.no_kk','left')->where('tagihan_iuran.id',$id)->first(); }
    public function getByNoKK(string $noKK): array { return $this->where('no_kk',$noKK)->orderBy('tahun','ASC')->orderBy('bulan','ASC')->orderBy('id','ASC')->findAll(); }
    public function findByNaturalKey(int $jenis,string $kk,string $periode,int $tahun,?int $bulan): ?array { $q=$this->where(['jenis_iuran_id'=>$jenis,'no_kk'=>$kk,'periode'=>$periode,'tahun'=>$tahun]); if($bulan===null)$q->where('bulan IS NULL',null,false); else $q->where('bulan',$bulan); return $q->first(); }
    public function getOutstandingForKK(string $kk, ?int $untilYear=null, ?int $untilMonth=null): array
    {
        $builder=$this->db->table('tagihan_iuran t')->select('t.*, j.nama_iuran, j.kode_iuran, COALESCE(SUM(CASE WHEN p.status="valid" THEN d.jumlah_dialokasikan ELSE 0 END),0) paid_amount',false)->join('jenis_iuran j','j.id=t.jenis_iuran_id','left')->join('pembayaran_iuran_detail d','d.tagihan_iuran_id=t.id','left')->join('pembayaran_iuran p','p.id=d.pembayaran_id','left')->where('t.no_kk',$kk)->where('t.status !=','dibatalkan')->groupBy('t.id')->orderBy('t.tahun','ASC')->orderBy('t.bulan','ASC')->orderBy('t.id','ASC');
        if($untilYear!==null){$builder->groupStart()->where('t.tahun <',$untilYear)->orGroupStart()->where('t.tahun',$untilYear)->where('t.bulan <=',$untilMonth??12)->groupEnd()->groupEnd();}
        $rows=$builder->get()->getResultArray(); foreach($rows as &$r){$r['paid_amount']=(float)$r['paid_amount'];$r['outstanding']=max(0,(float)$r['nominal']-$r['paid_amount']);} unset($r); return array_values(array_filter($rows,fn($r)=>$r['outstanding']>0));
    }
    public function getPaidAmount(int $id): float { $row=$this->db->table('pembayaran_iuran_detail d')->selectSum('jumlah_dialokasikan','total')->join('pembayaran_iuran p','p.id=d.pembayaran_id')->where('d.tagihan_iuran_id',$id)->where('p.status','valid')->get()->getRowArray(); return (float)($row['total']??0); }
    public function refreshStatus(int $id): void { $t=$this->find($id); if(!$t || $t['status']==='dibatalkan')return; $paid=$this->getPaidAmount($id); $status=$paid<=0?'belum_bayar':($paid<(float)$t['nominal']?'sebagian':'lunas'); $this->update($id,['status'=>$status,'tanggal_bayar'=>$status==='lunas'?date('Y-m-d'):null]); }
    public function getTotalTagihan(): int { return $this->countAllResults(); }
    public function getTotalNominal(): float { $r=$this->selectSum('nominal')->get()->getRow('nominal'); return (float)($r??0); }
    public function getTotalNominalLunas(): float { $r=$this->where('status','lunas')->selectSum('nominal')->get()->getRow('nominal'); return (float)($r??0); }
    public function getTotalNominalBelumBayar(): float { $r=$this->whereIn('status',['belum_bayar','sebagian'])->selectSum('nominal')->get()->getRow('nominal'); return (float)($r??0); }
    public function getTotalBelumBayar(): int { return $this->where('status','belum_bayar')->countAllResults(); }
    public function getTotalSebagian(): int { return $this->where('status','sebagian')->countAllResults(); }
    public function getTotalLunas(): int { return $this->where('status','lunas')->countAllResults(); }
    public function getStats(?string $noKK=null): array { $base=$this->db->table('tagihan_iuran')->where('status !=','dibatalkan'); if ($noKK !== null) $base->where('no_kk',$noKK); $rows=$base->get()->getResultArray(); $total=0;$paid=0;$out=0;$unpaid=0;$partial=0;$lunas=0; foreach($rows as $r){$p=$this->getPaidAmount((int)$r['id']);$total+=(float)$r['nominal'];$paid+=min($p,(float)$r['nominal']);$out+=max(0,(float)$r['nominal']-$p);if($p<=0)$unpaid++;elseif($p<(float)$r['nominal'])$partial++;else$lunas++;} return compact('total','paid','out','unpaid','partial','lunas'); }
}
