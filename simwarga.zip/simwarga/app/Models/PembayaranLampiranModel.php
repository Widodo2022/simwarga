<?php
namespace App\Models; use CodeIgniter\Model;
class PembayaranLampiranModel extends Model { protected $table='pembayaran_iuran_lampiran'; protected $returnType='array'; protected $allowedFields=['pembayaran_id','nama_file','path_file','jenis_file','ukuran_file','uploaded_by']; protected $useTimestamps=false; }
