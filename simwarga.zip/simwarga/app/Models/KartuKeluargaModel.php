<?php

namespace App\Models;

use CodeIgniter\Model;

class KartuKeluargaModel extends Model
{
    protected $table            = 'kartu_keluarga';
    protected $primaryKey       = 'id';
    protected $useAutoIncrement = true;
    protected $returnType       = 'array';
    protected $useSoftDeletes   = false;
    protected $protectFields    = true;

    protected $allowedFields = [
        'no_kk',
        'kepala_keluarga',
        'kode_wilayah',
        'no_hp',
        'lampiran_kk',
        'alamat',
        'status',
    ];

    protected $useTimestamps = true;
    protected $dateFormat    = 'datetime';
    protected $createdField  = 'created_at';
    protected $updatedField  = 'updated_at';

    protected $validationRules = [
        'no_kk'           => 'required|exact_length[16]|numeric',
        'kepala_keluarga' => 'required|max_length[150]',
        'kode_wilayah'    => 'permit_empty|max_length[50]',
        'no_hp'           => 'permit_empty|max_length[20]',
        'alamat'          => 'permit_empty',
        'status'          => 'required|in_list[aktif,nonaktif]',
    ];

    protected $validationMessages = [
        'no_kk' => [
            'required'     => 'Nomor KK wajib diisi.',
            'exact_length' => 'Nomor KK harus terdiri dari 16 digit.',
            'numeric'      => 'Nomor KK hanya boleh berisi angka.',
        ],
        'kepala_keluarga' => [
            'required'   => 'Nama Kepala Keluarga wajib diisi.',
            'max_length' => 'Nama Kepala Keluarga maksimal 150 karakter.',
        ],
        'kode_wilayah' => [
            'max_length' => 'Kode wilayah maksimal 50 karakter.',
        ],
        'no_hp' => [
            'max_length' => 'Nomor HP maksimal 20 karakter.',
        ],
        'status' => [
            'required' => 'Status KK wajib dipilih.',
            'in_list'  => 'Status KK tidak valid.',
        ],
    ];

    protected $skipValidation = false;
    protected $allowCallbacks = true;

    public function getAktif(): array
    {
        return $this->where('status', 'aktif')
            ->orderBy('no_kk', 'ASC')
            ->findAll();
    }

    public function getByNoKK(string $noKK): ?array
    {
        return $this->where('no_kk', $noKK)->first();
    }
}
