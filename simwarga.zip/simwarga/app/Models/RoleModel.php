<?php

namespace App\Models;

use CodeIgniter\Model;

class RoleModel extends Model
{
    protected $table            = 'roles';
    protected $primaryKey       = 'id';
    protected $useAutoIncrement = true;
    protected $returnType       = 'array';

    protected $allowedFields = [
        'kode',
        'nama',
        'deskripsi',
        'status',
    ];

    protected $useTimestamps = true;

    protected $createdField = 'created_at';
    protected $updatedField = 'updated_at';

    /**
     * Cari role berdasarkan kode.
     */
    public function getByKode(string $kode): ?array
    {
        return $this->where('kode', $kode)
            ->where('status', 'aktif')
            ->first();
    }
}