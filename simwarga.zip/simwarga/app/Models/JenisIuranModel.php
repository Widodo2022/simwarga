<?php

namespace App\Models;

use CodeIgniter\Model;

class JenisIuranModel extends Model
{
    protected $table            = 'jenis_iuran';
    protected $primaryKey       = 'id';
    protected $useAutoIncrement = true;
    protected $returnType       = 'array';
    protected $useSoftDeletes   = false;
    protected $protectFields    = true;

    /**
     * Field yang boleh diisi melalui insert/update.
     */
    protected $allowedFields = [
        'kode_iuran',
        'nama_iuran',
        'deskripsi',
        'nominal',
        'sifat_iuran',
        'periode',
        'tanggal_mulai',
        'status',
    ];

    /**
     * Timestamps.
     */
    protected $useTimestamps = true;
    protected $dateFormat    = 'datetime';
    protected $createdField  = 'created_at';
    protected $updatedField  = 'updated_at';

    /**
     * Validasi data.
     */
    protected $validationRules = [
        'kode_iuran' => 'required|max_length[30]',
        'nama_iuran' => 'required|max_length[100]',
        'deskripsi' => 'permit_empty|max_length[255]',
        'nominal' => 'required|numeric',
        'sifat_iuran' => 'required|in_list[wajib,sukarela]',
        'periode' => 'required|in_list[bulanan,tahunan,sekali]',
        'tanggal_mulai' => 'permit_empty|valid_date[Y-m-d]',
        'status' => 'required|in_list[aktif,nonaktif]',
    ];

    /**
     * Pesan validasi.
     */
    protected $validationMessages = [
        'kode_iuran' => [
            'required' => 'Kode iuran wajib diisi.',
            'max_length' => 'Kode iuran maksimal 30 karakter.',
        ],

        'nama_iuran' => [
            'required' => 'Nama iuran wajib diisi.',
            'max_length' => 'Nama iuran maksimal 100 karakter.',
        ],

        'deskripsi' => [
            'max_length' => 'Deskripsi maksimal 255 karakter.',
        ],

        'nominal' => [
            'required' => 'Nominal iuran wajib diisi.',
            'numeric' => 'Nominal iuran harus berupa angka.',
        ],

        'sifat_iuran' => [
            'required' => 'Sifat iuran wajib dipilih.',
            'in_list' => 'Sifat iuran tidak valid.',
        ],

        'periode' => [
            'required' => 'Periode iuran wajib dipilih.',
            'in_list' => 'Periode iuran tidak valid.',
        ],

        'tanggal_mulai' => [
            'valid_date' => 'Format tanggal mulai tidak valid.',
        ],

        'status' => [
            'required' => 'Status wajib dipilih.',
            'in_list' => 'Status tidak valid.',
        ],
    ];

    /**
     * Validasi tetap aktif.
     */
    protected $skipValidation = false;

    /**
     * Callback Model.
     */
    protected $allowCallbacks = true;
}