<?php

namespace App\Models;

use CodeIgniter\Model;

class UserModel extends Model
{
    protected $table            = 'users';
    protected $primaryKey       = 'id';
    protected $useAutoIncrement = true;
    protected $returnType       = 'array';

    protected $allowedFields = [
        'username',
        'password',
        'nama_lengkap',
        'email',
        'foto',
        'status',
        'last_login',
        'no_kk',
    ];

    protected $useTimestamps = true;

    protected $createdField = 'created_at';
    protected $updatedField = 'updated_at';

    /**
     * Cari user berdasarkan username.
     */
    public function getByUsername(string $username): ?array
    {
        return $this->where('username', $username)
            ->where('status', 'aktif')
            ->first();
    }

    /**
     * Cari user berdasarkan email.
     */
    public function getByEmail(string $email): ?array
    {
        return $this->where('email', $email)
            ->where('status', 'aktif')
            ->first();
    }
}