<?php

namespace App\Models;

use CodeIgniter\Model;

class PermissionModel extends Model
{
    protected $table            = 'permissions';
    protected $primaryKey       = 'id';
    protected $useAutoIncrement = true;
    protected $returnType       = 'array';

    protected $allowedFields = [
        'kode',
        'nama',
        'modul',
        'aksi',
        'deskripsi',
        'status',
    ];

    protected $useTimestamps = true;

    protected $createdField = 'created_at';
    protected $updatedField = 'updated_at';

    /**
     * Cari permission berdasarkan kode.
     */
    public function getByKode(string $kode): ?array
    {
        return $this->where('kode', $kode)
            ->where('status', 'aktif')
            ->first();
    }

    /**
     * Ambil permission berdasarkan modul.
     */
    public function getByModul(string $modul): array
    {
        return $this->where('modul', $modul)
            ->where('status', 'aktif')
            ->orderBy('nama', 'ASC')
            ->findAll();
    }
}