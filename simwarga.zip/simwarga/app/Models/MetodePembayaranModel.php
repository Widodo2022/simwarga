<?php
namespace App\Models;
use CodeIgniter\Model;
class MetodePembayaranModel extends Model { protected $table='metode_pembayaran'; protected $returnType='array'; protected $allowedFields=['kode','nama','status','keterangan']; protected $useTimestamps=true; }
