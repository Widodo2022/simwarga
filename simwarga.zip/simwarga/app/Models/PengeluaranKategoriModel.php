<?php
namespace App\Models; use CodeIgniter\Model;
class PengeluaranKategoriModel extends Model { protected $table='pengeluaran_kategori'; protected $returnType='array'; protected $allowedFields=['kode','nama','status']; protected $useTimestamps=true; }
