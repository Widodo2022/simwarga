<?php

namespace App\Models;

use CodeIgniter\Model;

class WargaModel extends Model
{
    protected $table            = 'warga';
    protected $primaryKey       = 'id';
    protected $useAutoIncrement = true;
    protected $returnType       = 'array';
    protected $useSoftDeletes   = false;
    protected $protectFields    = true;

    protected $allowedFields = [
        'nik',
        'no_kk',
        'nama_lengkap',
        'jenis_kelamin',
        'tempat_lahir',
        'tanggal_lahir',
        'agama',
        'pendidikan',
        'pekerjaan',
        'no_hp',
        'lampiran_ktp',
        'hubungan_keluarga',
        'status_perkawinan',
        'status',
    ];

    protected $useTimestamps = true;
    protected $dateFormat    = 'datetime';
    protected $createdField  = 'created_at';
    protected $updatedField  = 'updated_at';

    protected $validationRules = [
        'nik' => 'required|exact_length[16]|numeric',
        'no_kk' => 'required|exact_length[16]|numeric',
        'nama_lengkap' => 'required|max_length[150]',
        'jenis_kelamin' => 'required|in_list[L,P]',
        'tanggal_lahir' => 'permit_empty|valid_date[Y-m-d]',
        'hubungan_keluarga' => 'required|in_list[KEPALA_KELUARGA,ISTRI,ANAK,ORANG_TUA,FAMILI_LAIN,LAINNYA]',
        'status_perkawinan' => 'required|in_list[KAWIN,BELUM_KAWIN,JANDA,DUDA,MENINGGAL,LAIN_LAIN]',
        'status' => 'required|in_list[aktif,nonaktif]',
    ];

    protected $validationMessages = [
        'nik' => [
            'required' => 'NIK wajib diisi.',
            'exact_length' => 'NIK harus terdiri dari 16 digit.',
            'numeric' => 'NIK hanya boleh berisi angka.',
        ],
        'no_kk' => [
            'required' => 'Nomor KK wajib diisi.',
            'exact_length' => 'Nomor KK harus terdiri dari 16 digit.',
            'numeric' => 'Nomor KK hanya boleh berisi angka.',
        ],
        'nama_lengkap' => [
            'required' => 'Nama lengkap wajib diisi.',
        ],
        'jenis_kelamin' => [
            'required' => 'Jenis kelamin wajib dipilih.',
            'in_list' => 'Jenis kelamin tidak valid.',
        ],
        'tanggal_lahir' => [
            'valid_date' => 'Format tanggal lahir tidak valid.',
        ],
        'hubungan_keluarga' => [
            'required' => 'Hubungan keluarga wajib dipilih.',
            'in_list' => 'Hubungan keluarga tidak valid.',
        ],
        'status' => [
            'required' => 'Status wajib dipilih.',
            'in_list' => 'Status tidak valid.',
        ],
        'status_perkawinan' => [
            'required' => 'Status perkawinan wajib dipilih.',
            'in_list' => 'Status perkawinan tidak valid.',
        ],
    ];

    protected $skipValidation = false;

    protected $allowCallbacks = true;

    /**
     * Ambil data warga beserta Kode Wilayah
     * dari tabel kartu_keluarga berdasarkan no_kk.
     */
    public function getWargaDenganKodeWilayah()
    {
        return $this->select('warga.*, kartu_keluarga.kode_wilayah')
            ->join(
                'kartu_keluarga',
                'kartu_keluarga.no_kk = warga.no_kk',
                'left'
            )
            ->orderBy('warga.nama_lengkap', 'ASC')
            ->findAll();
    }
}