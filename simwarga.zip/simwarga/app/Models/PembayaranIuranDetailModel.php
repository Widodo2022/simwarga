<?php
namespace App\Models;
use CodeIgniter\Model;
class PembayaranIuranDetailModel extends Model { protected $table='pembayaran_iuran_detail'; protected $returnType='array'; protected $allowedFields=['pembayaran_id','tagihan_iuran_id','jumlah_dialokasikan']; protected $useTimestamps=false; }
