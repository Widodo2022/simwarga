<?php
namespace App\Models; use CodeIgniter\Model;
class SumberDanaModel extends Model { protected $table='sumber_dana'; protected $returnType='array'; protected $allowedFields=['kode','nama','status','keterangan']; protected $useTimestamps=true; }
