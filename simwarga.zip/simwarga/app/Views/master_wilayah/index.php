<?= view('layouts/header', ['title' => $title ?? 'Master Wilayah']) ?>

<div class="container-fluid">
    <div class="row">
        <div class="col-lg-2 d-none d-lg-block p-0"><?= view('layouts/sidebar') ?></div>
        <div class="col-lg-10 content p-0">
            <?= view('layouts/navbar') ?>
            <main class="p-3 p-md-4">
                <div class="mb-4">
                    <h3 class="fw-bold mb-1"><i class="bi bi-geo-alt text-primary me-2"></i>Master Wilayah</h3>
                    <p class="text-muted mb-0">Data wilayah administrasi yang digunakan SIMWARGA.</p>
                </div>

                <div class="card border-0 shadow-sm overflow-hidden">
                    <div class="card-header bg-primary text-white py-3 fw-bold">
                        <i class="bi bi-diagram-3 me-2"></i>Daftar Wilayah
                    </div>
                    <div class="card-body table-responsive">
                        <?php if (empty($wilayah)): ?>
                            <div class="text-center text-muted py-5">
                                <i class="bi bi-inbox fs-1 d-block mb-2"></i>Belum ada data wilayah.
                            </div>
                        <?php else: ?>
                            <table class="table table-hover align-middle mb-0">
                                <thead class="table-light">
                                    <tr><th>No</th><th>Kode</th><th>Nama</th><th>Jenis</th><th>Kode Parent</th><th>Status</th></tr>
                                </thead>
                                <tbody>
                                <?php foreach ($wilayah as $i => $row): ?>
                                    <tr>
                                        <td><?= $i + 1 ?></td>
                                        <td class="font-monospace"><?= esc($row['kode']) ?></td>
                                        <td class="fw-semibold"><?= esc($row['nama']) ?></td>
                                        <td><span class="badge bg-light text-dark border"><?= esc($row['jenis']) ?></span></td>
                                        <td><?= esc($row['kode_parent'] ?? '-') ?></td>
                                        <td><span class="badge rounded-pill <?= ($row['status'] ?? '') === 'aktif' ? 'bg-success' : 'bg-secondary' ?>"><?= esc(ucfirst($row['status'] ?? '-')) ?></span></td>
                                    </tr>
                                <?php endforeach; ?>
                                </tbody>
                            </table>
                        <?php endif; ?>
                    </div>
                </div>
            </main>
            <?= view('layouts/footer') ?>
        </div>
    </div>
</div>
