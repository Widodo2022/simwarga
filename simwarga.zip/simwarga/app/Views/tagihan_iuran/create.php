<?= view('layouts/header', ['title' => $title ?? 'Tambah Tagihan Iuran']) ?>

<div class="container-fluid">
    <div class="row">
        <div class="col-lg-2 d-none d-lg-block p-0"><?= view('layouts/sidebar') ?></div>
        <div class="col-lg-10 content p-0">
            <?= view('layouts/navbar') ?>
            <main class="p-3 p-md-4">
                <div class="d-flex justify-content-between align-items-center flex-wrap gap-2 mb-4">
                    <div>
                        <a href="<?= site_url('tagihan-iuran') ?>" class="text-decoration-none">
                            <i class="bi bi-arrow-left me-1"></i>Kembali ke Tagihan
                        </a>
                        <h3 class="fw-bold mt-3 mb-1"><i class="bi bi-cash-stack text-primary me-2"></i>Tambah Tagihan Iuran</h3>
                        <p class="text-muted mb-0">Buat tagihan baru untuk Kartu Keluarga.</p>
                    </div>
                </div>

                <?php if ($errors = session()->getFlashdata('errors')): ?>
                    <div class="alert alert-danger shadow-sm">
                        <div class="fw-bold mb-2"><i class="bi bi-exclamation-triangle me-1"></i>Periksa data berikut:</div>
                        <ul class="mb-0">
                            <?php foreach ((array) $errors as $error): ?><li><?= esc($error) ?></li><?php endforeach; ?>
                        </ul>
                    </div>
                <?php endif; ?>

                <?php if ($error = session()->getFlashdata('error')): ?>
                    <div class="alert alert-danger shadow-sm"><?= esc($error) ?></div>
                <?php endif; ?>

                <div class="card border-0 shadow-sm">
                    <div class="card-header bg-primary text-white py-3">
                        <h5 class="mb-0 fw-bold"><i class="bi bi-receipt me-2"></i>Informasi Tagihan</h5>
                    </div>
                    <div class="card-body p-3 p-md-4">
                        <form action="<?= site_url('tagihan-iuran') ?>" method="post">
                            <?= csrf_field() ?>
                            <div class="row g-3">
                                <div class="col-md-6">
                                    <label for="jenis_iuran_id" class="form-label fw-semibold">Jenis Iuran <span class="text-danger">*</span></label>
                                    <select class="form-select" id="jenis_iuran_id" name="jenis_iuran_id" required>
                                        <option value="">-- Pilih Jenis Iuran --</option>
                                        <?php foreach ($jenisIuran as $jenis): ?>
                                            <option value="<?= (int) $jenis['id'] ?>"
                                                data-nominal="<?= esc($jenis['nominal']) ?>"
                                                data-periode="<?= esc($jenis['periode']) ?>"
                                                <?= (string) old('jenis_iuran_id', $tagihan['jenis_iuran_id'] ?? '') === (string) $jenis['id'] ? 'selected' : '' ?>>
                                                <?= esc($jenis['kode_iuran']) ?> - <?= esc($jenis['nama_iuran']) ?> (Rp <?= number_format((float) $jenis['nominal'], 0, ',', '.') ?>)
                                            </option>
                                        <?php endforeach; ?>
                                    </select>
                                </div>

                                <div class="col-md-6">
                                    <label for="no_kk" class="form-label fw-semibold">Nomor KK <span class="text-danger">*</span></label>
                                    <select class="form-select" id="no_kk" name="no_kk" required>
                                        <option value="">-- Pilih Kartu Keluarga --</option>
                                        <?php foreach ($kk as $row): ?>
                                            <option value="<?= esc($row['no_kk']) ?>"
                                                <?= old('no_kk', $tagihan['no_kk'] ?? '') === $row['no_kk'] ? 'selected' : '' ?>>
                                                <?= esc($row['no_kk']) ?> - <?= esc($row['kepala_keluarga']) ?>
                                            </option>
                                        <?php endforeach; ?>
                                    </select>
                                </div>

                                <div class="col-md-4">
                                    <label for="periode" class="form-label fw-semibold">Periode <span class="text-danger">*</span></label>
                                    <select class="form-select" id="periode" name="periode" required>
                                        <?php $selectedPeriode = old('periode', $tagihan['periode'] ?? 'bulanan'); ?>
                                        <option value="bulanan" <?= $selectedPeriode === 'bulanan' ? 'selected' : '' ?>>Bulanan</option>
                                        <option value="tahunan" <?= $selectedPeriode === 'tahunan' ? 'selected' : '' ?>>Tahunan</option>
                                        <option value="sekali" <?= $selectedPeriode === 'sekali' ? 'selected' : '' ?>>Sekali</option>
                                    </select>
                                </div>

                                <div class="col-md-4">
                                    <label for="tahun" class="form-label fw-semibold">Tahun <span class="text-danger">*</span></label>
                                    <input type="number" class="form-control" id="tahun" name="tahun" min="2000" max="2100"
                                           value="<?= esc(old('tahun', $tagihan['tahun'] ?? date('Y'))) ?>" required>
                                </div>

                                <div class="col-md-4" id="bulanWrapper">
                                    <label for="bulan" class="form-label fw-semibold">Bulan</label>
                                    <?php $selectedBulan = (string) old('bulan', $tagihan['bulan'] ?? ''); ?>
                                    <select class="form-select" id="bulan" name="bulan">
                                        <option value="">-- Pilih Bulan --</option>
                                        <?php
                                        $bulanList = [1=>'Januari',2=>'Februari',3=>'Maret',4=>'April',5=>'Mei',6=>'Juni',7=>'Juli',8=>'Agustus',9=>'September',10=>'Oktober',11=>'November',12=>'Desember'];
                                        foreach ($bulanList as $num => $label):
                                        ?>
                                            <option value="<?= $num ?>" <?= $selectedBulan === (string) $num ? 'selected' : '' ?>><?= $label ?></option>
                                        <?php endforeach; ?>
                                    </select>
                                </div>

                                <div class="col-md-6">
                                    <label for="nominal" class="form-label fw-semibold">Nominal <span class="text-danger">*</span></label>
                                    <div class="input-group">
                                        <span class="input-group-text">Rp</span>
                                        <input type="number" class="form-control" id="nominal" name="nominal" min="0" step="0.01"
                                               value="<?= esc(old('nominal', $tagihan['nominal'] ?? '0')) ?>" required>
                                    </div>
                                </div>

                                <div class="col-md-6">
                                    <label for="status" class="form-label fw-semibold">Status <span class="text-danger">*</span></label>
                                    <?php $selectedStatus = old('status', $tagihan['status'] ?? 'belum_bayar'); ?>
                                    <select class="form-select" id="status" name="status" required>
                                        <option value="belum_bayar" <?= $selectedStatus === 'belum_bayar' ? 'selected' : '' ?>>Belum Bayar</option>
                                        <option value="sebagian" <?= $selectedStatus === 'sebagian' ? 'selected' : '' ?>>Sebagian</option>
                                        <option value="lunas" <?= $selectedStatus === 'lunas' ? 'selected' : '' ?>>Lunas</option>
                                        <option value="dibatalkan" <?= $selectedStatus === 'dibatalkan' ? 'selected' : '' ?>>Dibatalkan</option>
                                    </select>
                                </div>

                                <div class="col-md-4">
                                    <label for="tanggal_tagihan" class="form-label fw-semibold">Tanggal Tagihan</label>
                                    <input type="date" class="form-control" id="tanggal_tagihan" name="tanggal_tagihan"
                                           value="<?= esc(old('tanggal_tagihan', $tagihan['tanggal_tagihan'] ?? date('Y-m-d'))) ?>">
                                </div>

                                <div class="col-md-4">
                                    <label for="tanggal_jatuh_tempo" class="form-label fw-semibold">Tanggal Jatuh Tempo</label>
                                    <input type="date" class="form-control" id="tanggal_jatuh_tempo" name="tanggal_jatuh_tempo"
                                           value="<?= esc(old('tanggal_jatuh_tempo', $tagihan['tanggal_jatuh_tempo'] ?? '')) ?>">
                                </div>

                                <div class="col-md-4">
                                    <label for="tanggal_bayar" class="form-label fw-semibold">Tanggal Bayar</label>
                                    <input type="date" class="form-control" id="tanggal_bayar" name="tanggal_bayar"
                                           value="<?= esc(old('tanggal_bayar', $tagihan['tanggal_bayar'] ?? '')) ?>">
                                </div>

                                <div class="col-12">
                                    <label for="keterangan" class="form-label fw-semibold">Keterangan</label>
                                    <textarea class="form-control" id="keterangan" name="keterangan" rows="3" maxlength="255"
                                              placeholder="Catatan tagihan (opsional)"><?= esc(old('keterangan', $tagihan['keterangan'] ?? '')) ?></textarea>
                                </div>
                            </div>

                            <div class="d-flex justify-content-end gap-2 mt-4">
                                <a href="<?= site_url('tagihan-iuran') ?>" class="btn btn-light border">Batal</a>
                                <button type="submit" class="btn btn-primary">
                                    <i class="bi bi-check2-circle me-1"></i>Simpan Tagihan
                                </button>
                            </div>
                        </form>
                    </div>
                </div>
            </main>
            <?= view('layouts/footer') ?>
        </div>
    </div>
</div>

<script>
document.addEventListener('DOMContentLoaded', function () {
    const jenis = document.getElementById('jenis_iuran_id');
    const nominal = document.getElementById('nominal');
    const periode = document.getElementById('periode');
    const bulan = document.getElementById('bulan');
    const bulanWrapper = document.getElementById('bulanWrapper');
    const tanggalTagihan = document.getElementById('tanggal_tagihan');
    const tanggalBayar = document.getElementById('tanggal_bayar');
    const status = document.getElementById('status');

    function syncBulan() {
        const monthly = periode.value === 'bulanan';
        bulanWrapper.style.display = monthly ? '' : 'none';
        bulan.required = monthly;
        if (!monthly) bulan.value = '';
    }

    function fillNominal() {
        const option = jenis.options[jenis.selectedIndex];
        if (option && option.dataset.nominal && (!nominal.value || nominal.dataset.auto === '1')) {
            nominal.value = option.dataset.nominal;
            nominal.dataset.auto = '1';
        }
        if (option && option.dataset.periode && !<?= false ?>) {
            periode.value = option.dataset.periode;
            syncBulan();
        }
    }

    nominal.addEventListener('input', function () { nominal.dataset.auto = '0'; });
    jenis.addEventListener('change', fillNominal);
    periode.addEventListener('change', syncBulan);

    status.addEventListener('change', function () {
        if (status.value === 'lunas' && !tanggalBayar.value) {
            tanggalBayar.value = new Date().toISOString().slice(0, 10);
        }
        if (status.value !== 'lunas') tanggalBayar.value = '';
    });

    syncBulan();
    if (!nominal.value || <?= true ?>) fillNominal();
});
</script>
