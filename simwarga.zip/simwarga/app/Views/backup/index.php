<?= view('layouts/header', [
    'title' => $title ?? 'Backup & Restore Sistem'
]) ?>

<div class="container-fluid">
    <div class="row">

        <!-- SIDEBAR -->
        <div class="col-lg-2 d-none d-lg-block p-0">
            <?= view('layouts/sidebar') ?>
        </div>

        <!-- CONTENT -->
        <div class="col-lg-10 content p-0">

            <?= view('layouts/navbar') ?>

            <main class="p-3 p-md-4">

                <!-- HEADER -->
                <div class="d-flex flex-wrap justify-content-between align-items-center mb-4">
                    <div>
                        <h3 class="fw-bold mb-1">
                            <i class="bi bi-shield-lock text-primary me-2"></i>
                            Backup & Restore Sistem
                        </h3>

                        <p class="text-muted mb-0">
                            Pengelolaan backup dan restore sistem SIMWARGA.
                        </p>
                    </div>
                </div>

                <!-- FLASH MESSAGE -->
                <?php if (session()->getFlashdata('success')): ?>
                    <div class="alert alert-success">
                        <?= esc(session()->getFlashdata('success')) ?>
                    </div>
                <?php endif; ?>

                <?php if (session()->getFlashdata('error')): ?>
                    <div class="alert alert-danger">
                        <?= esc(session()->getFlashdata('error')) ?>
                    </div>
                <?php endif; ?>

                <!-- BACKUP -->
                <div class="row g-3">

                    <div class="col-md-6">
                        <div class="card border-0 shadow-sm h-100">
                            <div class="card-body">

                                <h5 class="fw-bold">
                                    <i class="bi bi-database-check text-primary me-2"></i>
                                    Buat Backup
                                </h5>

                                <p class="small text-muted">
                                    Database dan source disimpan di area writable
                                    yang ditolak oleh web server.
                                </p>

                                <div class="d-flex flex-wrap gap-2">

                                    <form method="post"
                                          action="<?= site_url('backup/database') ?>">
                                        <button type="submit"
                                                class="btn btn-primary">
                                            <i class="bi bi-database me-1"></i>
                                            Backup Database
                                        </button>
                                    </form>

                                    <form method="post"
                                          action="<?= site_url('backup/source') ?>">
                                        <button type="submit"
                                                class="btn btn-outline-primary">
                                            <i class="bi bi-file-earmark-zip me-1"></i>
                                            Backup Source Aplikasi
                                        </button>
                                    </form>

                                </div>

                            </div>
                        </div>
                    </div>

                    <!-- RESTORE DATABASE -->
                    <div class="col-md-6">
                        <div class="card border-0 shadow-sm h-100">
                            <div class="card-body">

                                <h5 class="fw-bold">
                                    <i class="bi bi-database-up text-danger me-2"></i>
                                    Restore Database
                                </h5>

                                <p class="small text-danger">
                                    Emergency backup otomatis dibuat sebelum restore.
                                </p>

                                <form method="post"
                                      enctype="multipart/form-data"
                                      action="<?= site_url('backup/restore-database') ?>">

                                    <input class="form-control mb-2"
                                           type="file"
                                           name="backup_file"
                                           accept=".sql"
                                           required>

                                    <button type="submit"
                                            class="btn btn-danger"
                                            onclick="return confirm('Restore database akan mengganti isi database. Lanjutkan?')">
                                        <i class="bi bi-arrow-counterclockwise me-1"></i>
                                        Restore Database
                                    </button>

                                </form>

                            </div>
                        </div>
                    </div>

                    <!-- RESTORE SOURCE -->
                    <div class="col-12">
                        <div class="card border-0 shadow-sm">
                            <div class="card-body">

                                <h5 class="fw-bold">
                                    <i class="bi bi-archive text-warning me-2"></i>
                                    Restore Source Aplikasi
                                </h5>

                                <p class="small text-muted">
                                    Arsip source diamankan sebagai paket restore.
                                    File aplikasi aktif tidak ditimpa langsung dari web
                                    agar risiko aplikasi rusak di tengah proses dapat dihindari.
                                </p>

                                <form method="post"
                                      enctype="multipart/form-data"
                                      action="<?= site_url('backup/restore-source') ?>"
                                      class="row g-2">

                                    <div class="col-md-8">
                                        <input class="form-control"
                                               type="file"
                                               name="backup_file"
                                               accept=".tar,.gz,.tgz"
                                               required>
                                    </div>

                                    <div class="col-md-4">
                                        <button type="submit"
                                                class="btn btn-warning">
                                            <i class="bi bi-archive me-1"></i>
                                            Siapkan Paket Restore Source
                                        </button>
                                    </div>

                                </form>

                            </div>
                        </div>
                    </div>

                </div>

                <!-- RIWAYAT BACKUP -->
                <div class="card border-0 shadow-sm mt-4">

                    <div class="card-header bg-primary text-white py-3">
                        <h5 class="mb-0 fw-bold">
                            <i class="bi bi-clock-history me-2"></i>
                            Riwayat File Backup
                        </h5>
                    </div>

                    <div class="card-body">

                        <div class="table-responsive">

                            <table class="table table-hover align-middle">

                                <thead>
                                    <tr>
                                        <th>File</th>
                                        <th>Ukuran</th>
                                        <th>Dibuat</th>
                                        <th class="text-end">Aksi</th>
                                    </tr>
                                </thead>

                                <tbody>

                                    <?php foreach ($files as $file): ?>

                                        <tr>

                                            <td>
                                                <i class="bi bi-file-earmark-zip me-2"></i>
                                                <?= esc($file['name']) ?>
                                            </td>

                                            <td>
                                                <?= number_format(
                                                    $file['size'] / 1024 / 1024,
                                                    2,
                                                    ',',
                                                    '.'
                                                ) ?>
                                                MB
                                            </td>

                                            <td>
                                                <?= esc($file['date']) ?>
                                            </td>

                                            <td class="text-end">

                                                <a class="btn btn-sm btn-outline-secondary"
                                                   href="<?= site_url(
                                                       'backup/download/' .
                                                       rawurlencode($file['name'])
                                                   ) ?>">
                                                    <i class="bi bi-download me-1"></i>
                                                    Download
                                                </a>

                                            </td>

                                        </tr>

                                    <?php endforeach; ?>

                                    <?php if (empty($files)): ?>

                                        <tr>
                                            <td colspan="4"
                                                class="text-center text-muted py-4">
                                                <i class="bi bi-inbox fs-3 d-block mb-2"></i>
                                                Belum ada backup.
                                            </td>
                                        </tr>

                                    <?php endif; ?>

                                </tbody>

                            </table>

                        </div>

                    </div>

                </div>

            </main>

        </div>

    </div>
</div>

<?= view('layouts/footer') ?>
