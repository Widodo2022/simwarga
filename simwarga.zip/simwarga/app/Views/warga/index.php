<?= view('layouts/header', [
    'title' => $title ?? 'Data Warga'
]) ?>

<div class="container-fluid">
    <div class="row">

        <!-- =========================================================
             SIDEBAR
             ========================================================= -->
        <div class="col-lg-2 d-none d-lg-block p-0">
            <?= view('layouts/sidebar') ?>
        </div>

        <!-- =========================================================
             CONTENT
             ========================================================= -->
        <div class="col-lg-10 content p-0">

            <?= view('layouts/navbar') ?>

            <main class="p-3 p-md-4">

                <!-- =================================================
                     HEADER HALAMAN
                     ================================================= -->
                <div class="d-flex flex-wrap justify-content-between align-items-center mb-4">

                    <div>
                        <h3 class="fw-bold mb-1">
                            <i class="bi bi-people text-primary me-2"></i>
                            Data Warga
                        </h3>

                        <p class="text-muted mb-0">
                            Kelola data warga RT007 / RW023.
                        </p>
                    </div>

                    <div class="mt-3 mt-md-0">
                        <a href="<?= site_url('warga/create') ?>"
                           class="btn btn-primary shadow-sm">
                            <i class="bi bi-person-plus me-1"></i>
                            Tambah Warga
                        </a>
                    </div>

                </div>

                <!-- =================================================
                     STATISTIK
                     ================================================= -->
                <?php
                $totalWarga = count($warga);

                $wargaAktif = count(
                    array_filter(
                        $warga,
                        static fn ($item) =>
                            ($item['status'] ?? '') === 'aktif'
                    )
                );

                $wargaNonaktif = count(
                    array_filter(
                        $warga,
                        static fn ($item) =>
                            ($item['status'] ?? '') === 'nonaktif'
                    )
                );
                ?>

                <div class="row g-3 mb-4">

                    <!-- TOTAL WARGA -->
                    <div class="col-md-4">
                        <div class="card stat-card border-0 shadow-sm h-100">
                            <div class="card-body">

                                <div class="d-flex align-items-center">

                                    <div class="stat-icon bg-primary-subtle text-primary">
                                        <i class="bi bi-people"></i>
                                    </div>

                                    <div>
                                        <div class="text-muted small">
                                            Total Warga
                                        </div>

                                        <div class="fs-4 fw-bold">
                                            <?= $totalWarga ?>
                                        </div>
                                    </div>

                                </div>

                            </div>
                        </div>
                    </div>

                    <!-- WARGA AKTIF -->
                    <div class="col-md-4">
                        <div class="card stat-card border-0 shadow-sm h-100">
                            <div class="card-body">

                                <div class="d-flex align-items-center">

                                    <div class="stat-icon bg-success-subtle text-success">
                                        <i class="bi bi-check-circle"></i>
                                    </div>

                                    <div>
                                        <div class="text-muted small">
                                            Warga Aktif
                                        </div>

                                        <div class="fs-4 fw-bold">
                                            <?= $wargaAktif ?>
                                        </div>
                                    </div>

                                </div>

                            </div>
                        </div>
                    </div>

                    <!-- WARGA NONAKTIF -->
                    <div class="col-md-4">
                        <div class="card stat-card border-0 shadow-sm h-100">
                            <div class="card-body">

                                <div class="d-flex align-items-center">

                                    <div class="stat-icon bg-secondary-subtle text-secondary">
                                        <i class="bi bi-x-circle"></i>
                                    </div>

                                    <div>
                                        <div class="text-muted small">
                                            Warga Nonaktif
                                        </div>

                                        <div class="fs-4 fw-bold">
                                            <?= $wargaNonaktif ?>
                                        </div>
                                    </div>

                                </div>

                            </div>
                        </div>
                    </div>

                </div>

                <!-- =================================================
                     DATA TABLE CARD
                     ================================================= -->
                <div class="card border-0 shadow-sm table-card">

                    <!-- CARD HEADER -->
                    <div class="card-header bg-primary text-white py-3">

                        <div class="d-flex flex-wrap justify-content-between align-items-center">

                            <div>
                                <h5 class="mb-0 fw-bold">
                                    <i class="bi bi-table me-2"></i>
                                    Daftar Warga
                                </h5>

                                <small class="opacity-75">
                                    Data warga terdaftar dalam sistem
                                </small>
                            </div>

                            <span class="badge bg-white text-primary mt-2 mt-md-0">
                                <?= $totalWarga ?> Data
                            </span>

                        </div>

                    </div>

                    <!-- TABLE BODY -->
                    <div class="card-body">

                        <div class="table-responsive">

                            <table id="tableWarga"
                                   class="table table-hover align-middle w-100">

                                <thead>
                                    <tr>

                                        <th class="text-center col-no">
                                            No
                                        </th>

                                        <th class="text-center col-nik">
                                            NIK
                                        </th>

                                        <th class="text-center col-kk">
                                            No. KK
                                        </th>

                                        <!-- KODE WILAYAH -->
                                        <th class="text-center col-kode-wilayah">
                                            Kode Wilayah
                                        </th>

                                        <!-- ALAMAT -->
                                        <th class="col-alamat">
                                            Alamat
                                        </th>

                                        <th class="col-nama">
                                            Nama Lengkap
                                        </th>

                                        <th class="text-center col-jk">
                                            JK
                                        </th>

                                        <th class="col-tempat">
                                            Tempat Lahir
                                        </th>

                                        <th class="text-center col-tanggal">
                                            Tanggal Lahir
                                        </th>

                                        <th class="col-pekerjaan">
                                            Pekerjaan
                                        </th>

                                        <th class="text-center col-hp">
                                            No. HP
                                        </th>

                                        <th class="text-center col-hubungan">
                                            Hubungan
                                        </th>

                                        <th class="text-center col-status-perkawinan">
                                            Status
                                        </th>

                                        <th class="text-center col-status-data">
                                            Status Data
                                        </th>

                                        <th class="text-center col-ktp">
                                            KTP
                                        </th>

                                        <th class="text-center col-aksi">
                                            Aksi
                                        </th>

                                    </tr>
                                </thead>

                                <tbody>

                                    <?php foreach ($warga as $i => $item): ?>

                                        <tr>

                                            <!-- NOMOR -->
                                            <td class="text-center">
                                                <?= $i + 1 ?>
                                            </td>

                                            <!-- NIK -->
                                            <td class="text-center">
                                                <span class="nik-text">
                                                    <?= esc($item['nik']) ?>
                                                </span>
                                            </td>

                                            <!-- NO KK -->
                                            <td class="text-center">
                                                <span class="no-kk">
                                                    <?= esc($item['no_kk']) ?>
                                                </span>
                                            </td>

                                            <!-- KODE WILAYAH -->
                                            <td class="text-center">
                                                <?php if (! empty($item['kode_wilayah'])): ?>

                                                    <span class="kode-wilayah">
                                                        <?= esc($item['kode_wilayah']) ?>
                                                    </span>

                                                <?php else: ?>

                                                    <span class="text-muted">
                                                        -
                                                    </span>

                                                <?php endif; ?>
                                            </td>

                                            <!-- ALAMAT -->
                                            <td>

                                                <?php if (! empty($item['alamat'])): ?>

                                                    <span class="alamat-text">
                                                        <?= esc($item['alamat']) ?>
                                                    </span>

                                                <?php else: ?>

                                                    <span class="text-muted">
                                                        -
                                                    </span>

                                                <?php endif; ?>

                                            </td>

                                            <!-- NAMA -->
                                            <td>
                                                <div class="d-flex align-items-center">

                                                    <div class="avatar-icon">
                                                        <i class="bi bi-person"></i>
                                                    </div>

                                                    <span class="nama-warga">
                                                        <?= esc($item['nama_lengkap']) ?>
                                                    </span>

                                                </div>
                                            </td>

                                            <!-- JENIS KELAMIN -->
                                            <td class="text-center">

                                                <?php if (($item['jenis_kelamin'] ?? '') === 'L'): ?>

                                                    <span class="gender-badge gender-l">
                                                        <i class="bi bi-gender-male me-1"></i>
                                                        L
                                                    </span>

                                                <?php else: ?>

                                                    <span class="gender-badge gender-p">
                                                        <i class="bi bi-gender-female me-1"></i>
                                                        P
                                                    </span>

                                                <?php endif; ?>

                                            </td>

                                            <!-- TEMPAT LAHIR -->
                                            <td>

                                                <?php if (! empty($item['tempat_lahir'])): ?>

                                                    <span class="tempat-lahir">
                                                        <?= esc($item['tempat_lahir']) ?>
                                                    </span>

                                                <?php else: ?>

                                                    <span class="text-muted">
                                                        -
                                                    </span>

                                                <?php endif; ?>

                                            </td>

                                            <!-- TANGGAL LAHIR -->
                                            <td class="text-center">

                                                <?php if (! empty($item['tanggal_lahir'])): ?>

                                                    <?= date(
                                                        'd-m-Y',
                                                        strtotime($item['tanggal_lahir'])
                                                    ) ?>

                                                <?php else: ?>

                                                    <span class="text-muted">
                                                        -
                                                    </span>

                                                <?php endif; ?>

                                            </td>

                                            <!-- PEKERJAAN -->
                                            <td>

                                                <?php if (! empty($item['pekerjaan'])): ?>

                                                    <span class="pekerjaan-text">
                                                        <?= esc($item['pekerjaan']) ?>
                                                    </span>

                                                <?php else: ?>

                                                    <span class="text-muted">
                                                        -
                                                    </span>

                                                <?php endif; ?>

                                            </td>

                                            <!-- NO HP -->
                                            <td class="text-center">

                                                <?php if (! empty($item['no_hp'])): ?>

                                                    <span class="hp-text">
                                                        <i class="bi bi-telephone me-1"></i>
                                                        <?= esc($item['no_hp']) ?>
                                                    </span>

                                                <?php else: ?>

                                                    <span class="text-muted">
                                                        -
                                                    </span>

                                                <?php endif; ?>

                                            </td>

                                            <!-- HUBUNGAN KELUARGA -->
                                            <td class="text-center">

                                                <?php

                                                $hubungan = $item['hubungan_keluarga'] ?? '';

                                                $hubunganLabel = match ($hubungan) {
                                                    'KEPALA_KELUARGA' => 'Kepala Keluarga',
                                                    'ISTRI'           => 'Istri',
                                                    'ANAK'            => 'Anak',
                                                    'ORANG_TUA'       => 'Orang Tua',
                                                    'FAMILI_LAIN'     => 'Famili Lain',
                                                    'LAINNYA'         => 'Lainnya',
                                                    default           => '-',
                                                };

                                                ?>

                                                <?php if ($hubungan): ?>

                                                    <span class="hubungan-badge">
                                                        <?= esc($hubunganLabel) ?>
                                                    </span>

                                                <?php else: ?>

                                                    <span class="text-muted">
                                                        -
                                                    </span>

                                                <?php endif; ?>

                                            </td>

                                            <!-- STATUS PERKAWINAN -->
                                            <td class="text-center">

                                                <?php

                                                $statusPerkawinan = $item['status_perkawinan'] ?? '';

                                                $statusPerkawinanLabel = match ($statusPerkawinan) {
                                                    'KAWIN'        => 'Kawin',
                                                    'BELUM_KAWIN'  => 'Belum Kawin',
                                                    'JANDA'  => 'Janda',
                                                    'DUDA'   => 'Duda',
                                                    'MENINGGAL'    => 'Meninggal',
                                                    'LAIN_LAIN'    => 'Lain Lain',
                                                    default        => '-',
                                                };

                                                ?>

                                                <?php if ($statusPerkawinan): ?>

                                                    <span class="status-perkawinan-badge">
                                                        <?= esc($statusPerkawinanLabel) ?>
                                                    </span>

                                                <?php else: ?>

                                                    <span class="text-muted">
                                                        -
                                                    </span>

                                                <?php endif; ?>

                                            </td>

                                            <!-- STATUS DATA -->
                                            <td class="text-center">

                                                <?php if (($item['status'] ?? '') === 'aktif'): ?>

                                                    <span class="badge rounded-pill bg-success status-badge">
                                                        <i class="bi bi-check-circle me-1"></i>
                                                        Aktif
                                                    </span>

                                                <?php else: ?>

                                                    <span class="badge rounded-pill bg-secondary status-badge">
                                                        <i class="bi bi-x-circle me-1"></i>
                                                        Nonaktif
                                                    </span>

                                                <?php endif; ?>

                                            </td>

                                            <!-- LAMPIRAN KTP -->
                                            <td class="text-center">

                                                <?php if (!empty($item['lampiran_ktp'])): ?>

                                                    <a href="<?= site_url('warga/ktp/' . $item['id']) ?>"
                                                       target="_blank"
                                                       data-bs-toggle="tooltip"
                                                       data-bs-placement="top"
                                                       title="Lihat KTP">

                                                        <img
                                                            src="<?= site_url('warga/ktp/' . $item['id']) ?>"
                                                            alt="KTP <?= esc($item['nama_lengkap']) ?>"
                                                            class="ktp-thumbnail"
                                                        >

                                                    </a>

                                                <?php else: ?>

                                                    <span class="badge bg-light text-secondary border">
                                                        <i class="bi bi-file-earmark-x me-1"></i>
                                                        Tidak Ada
                                                    </span>

                                                <?php endif; ?>

                                            </td>

                                            <!-- AKSI -->
                                            <td class="text-center">

                                                <div class="btn-group"
                                                     role="group"
                                                     aria-label="Aksi Warga">

                                                    <!-- EDIT -->
                                                    <a href="<?= site_url('warga/edit/' . $item['id']) ?>"
                                                       class="btn btn-sm btn-outline-primary"
                                                       data-bs-toggle="tooltip"
                                                       data-bs-placement="top"
                                                       title="Edit Data">

                                                        <i class="bi bi-pencil"></i>

                                                    </a>

                                                    <!-- NONAKTIFKAN -->
                                                        <?php if (($item['status'] ?? '') === 'aktif'): ?>

                                                            <button type="button"
                                                                    class="btn btn-sm btn-outline-danger"
                                                                    data-bs-toggle="tooltip"
                                                                    data-bs-placement="top"
                                                                    title="Nonaktifkan"
                                                                    onclick="confirmDelete(
                                                                        <?= (int) $item['id'] ?>,
                                                                        <?= htmlspecialchars(
                                                                            json_encode($item['nama_lengkap']),
                                                                            ENT_QUOTES,
                                                                            'UTF-8'
                                                                        ) ?>
                                                                    )">

                                                                <i class="bi bi-x-circle"></i>

                                                            </button>

                                                        <?php endif; ?>

                                                <!-- FORM DELETE -->
                                                <form id="delete-form-<?= $item['id'] ?>"
                                                      action="<?= site_url('warga/delete/' . $item['id']) ?>"
                                                      method="post"
                                                      class="d-none">

                                                    <?= csrf_field() ?>

                                                </form>

                                            </td>

                                        </tr>

                                    <?php endforeach; ?>

                                </tbody>

                            </table>

                        </div>

                    </div>

                </div>

            </main>

            <?= view('layouts/footer') ?>

        </div>

    </div>
</div>

<!-- =========================================================
     DATATABLES CSS
     ========================================================= -->

<link rel="stylesheet"
      href="https://cdn.datatables.net/2.3.3/css/dataTables.bootstrap5.min.css">

<link rel="stylesheet"
      href="https://cdn.datatables.net/buttons/3.2.5/css/buttons.bootstrap5.min.css">

<link rel="stylesheet"
      href="https://cdn.datatables.net/responsive/3.0.5/css/responsive.bootstrap5.min.css">

<!-- =========================================================
     CUSTOM CSS
     ========================================================= -->

<style>

.table-card {
    border-radius: 12px;
    overflow: hidden;
}

.card {
    border-radius: 12px;
}

/* =========================================================
   STAT CARD
   ========================================================= */

.stat-card {
    transition: all 0.2s ease;
}

.stat-card:hover {
    transform: translateY(-2px);
}

.stat-icon {
    width: 52px;
    height: 52px;
    border-radius: 50%;

    display: flex;
    align-items: center;
    justify-content: center;

    font-size: 23px;
    margin-right: 15px;
}

/* =========================================================
   TABLE
   ========================================================= */

#tableWarga {
    width: 100% !important;
    border-collapse: collapse !important;
}

#tableWarga thead th {
    background-color: #f8f9fa !important;

    border-top: 1px solid #dee2e6 !important;
    border-bottom: 2px solid #adb5bd !important;

    border-left: 1px solid #dee2e6 !important;
    border-right: 1px solid #dee2e6 !important;

    font-weight: 600;
    white-space: nowrap;
    vertical-align: middle;
}

#tableWarga tbody td {
    border-left: 1px solid #dee2e6 !important;
    border-right: 1px solid #dee2e6 !important;
    border-bottom: 1px solid #dee2e6 !important;

    vertical-align: middle;
}

#tableWarga tbody tr {
    border-bottom: 1px solid #dee2e6 !important;
}

#tableWarga tbody tr:hover {
    background-color: #f8f9fa !important;
}

/* =========================================================
   LEBAR KOLOM
   ========================================================= */

#tableWarga .col-no {
    width: 55px !important;
    min-width: 55px !important;
}

#tableWarga .col-nik {
    width: 175px !important;
    min-width: 175px !important;
}

#tableWarga .col-kk {
    width: 175px !important;
    min-width: 175px !important;
}

/* KODE WILAYAH */
#tableWarga .col-kode-wilayah {
    width: 120px !important;
    min-width: 120px !important;
}

/* ALAMAT */
#tableWarga .col-alamat {
    width: 250px !important;
    min-width: 250px !important;
}

#tableWarga .col-nama {
    min-width: 220px !important;
}

#tableWarga .col-jk {
    width: 80px !important;
    min-width: 80px !important;
}

#tableWarga .col-tempat {
    min-width: 150px !important;
}

#tableWarga .col-tanggal {
    width: 120px !important;
    min-width: 120px !important;
}

#tableWarga .col-pekerjaan {
    min-width: 160px !important;
}

#tableWarga .col-hp {
    width: 145px !important;
    min-width: 145px !important;
}

#tableWarga .col-hubungan {
    width: 155px !important;
    min-width: 155px !important;
}

#tableWarga .col-status-perkawinan {
    width: 125px !important;
    min-width: 125px !important;
}

#tableWarga .col-status-data {
    width: 110px !important;
    min-width: 110px !important;
}

#tableWarga .col-ktp {
    width: 90px !important;
    min-width: 90px !important;
}

#tableWarga .col-aksi {
    width: 95px !important;
    min-width: 95px !important;
}

/* =========================================================
   NIK
   ========================================================= */

.nik-text {
    display: inline-block;
    font-weight: 600;
    white-space: nowrap;
}

/* =========================================================
   NO KK
   ========================================================= */

.no-kk {
    display: inline-block;
    font-weight: 600;
    white-space: nowrap;
    letter-spacing: 0.2px;
}

/* =========================================================
   KODE WILAYAH
   ========================================================= */

.kode-wilayah {
    display: inline-block;
    font-weight: 600;
    white-space: nowrap;
    letter-spacing: 0.2px;

    padding: 5px 9px;

    background-color: #f8f9fa;
    border: 1px solid #dee2e6;

    border-radius: 7px;

    font-size: 12px;
    color: #495057;
}

/* =========================================================
   ALAMAT
   ========================================================= */

.alamat-text {
    display: inline-block;
    max-width: 250px;

    white-space: normal;
    word-break: break-word;

    line-height: 1.4;
}

/* =========================================================
   AVATAR
   ========================================================= */

.avatar-icon {
    width: 38px;
    height: 38px;
    min-width: 38px;

    border-radius: 50%;

    background-color: rgba(13, 110, 253, 0.10);
    color: #0d6efd;

    display: flex;
    align-items: center;
    justify-content: center;

    margin-right: 10px;
}

.nama-warga {
    white-space: nowrap;
    font-weight: 500;
}

/* =========================================================
   JENIS KELAMIN
   ========================================================= */

.gender-badge {
    display: inline-flex;
    align-items: center;
    justify-content: center;

    min-width: 40px;
    padding: 5px 9px;

    border-radius: 7px;

    font-size: 12px;
    font-weight: 600;

    white-space: nowrap;
}

.gender-l {
    background-color: rgba(13, 110, 253, 0.10);
    color: #0d6efd;
}

.gender-p {
    background-color: rgba(214, 51, 132, 0.10);
    color: #d63384;
}

/* =========================================================
   TEMPAT LAHIR
   ========================================================= */

.tempat-lahir {
    display: inline-block;
    max-width: 160px;

    white-space: normal;
    word-break: break-word;
}

/* =========================================================
   PEKERJAAN
   ========================================================= */

.pekerjaan-text {
    display: inline-block;
    max-width: 180px;

    white-space: normal;
    word-break: break-word;
}

/* =========================================================
   NO HP
   ========================================================= */

.hp-text {
    display: inline-block;
    white-space: nowrap;
    font-size: 13px;
}

/* =========================================================
   HUBUNGAN KELUARGA
   ========================================================= */

.hubungan-badge {
    display: inline-block;

    padding: 5px 9px;

    background-color: #f8f9fa;
    border: 1px solid #dee2e6;

    border-radius: 7px;

    font-size: 12px;
    font-weight: 600;

    color: #495057;
    white-space: nowrap;
}

/* =========================================================
   STATUS PERKAWINAN
   ========================================================= */

.status-perkawinan-badge {
    display: inline-block;

    padding: 5px 9px;

    background-color: #eef5ff;
    border: 1px solid #cfe2ff;

    border-radius: 7px;

    font-size: 12px;
    font-weight: 600;

    color: #0d6efd;
    white-space: nowrap;
}

/* =========================================================
   STATUS DATA
   ========================================================= */

.status-badge {
    min-width: 75px;
    padding: 6px 10px;
    font-weight: 500;
}

/* =========================================================
   BUTTON AKSI
   ========================================================= */

#tableWarga .btn-group {
    display: inline-flex;
    vertical-align: middle;
}

#tableWarga .btn {
    border-radius: 0;
}

#tableWarga .btn:first-child {
    border-top-left-radius: 6px;
    border-bottom-left-radius: 6px;
}

#tableWarga .btn:last-child {
    border-top-right-radius: 6px;
    border-bottom-right-radius: 6px;
}

/* =========================================================
   DATATABLES CONTAINER
   ========================================================= */

.dt-container {
    width: 100%;
}

/* =========================================================
   SHOW ENTRIES
   ========================================================= */

.dt-length {
    display: flex;
    align-items: center;

    gap: 6px;
    margin-bottom: 10px;
}

.dt-length label {
    margin: 0;
    white-space: nowrap;
    font-size: 14px;
}

.dt-length select {
    min-width: 60px;
    height: 34px;

    padding: 3px 25px 3px 8px;

    border: 1px solid #ced4da;
    border-radius: 6px;

    background-color: #fff;
}

/* =========================================================
   SEARCH
   ========================================================= */

.dt-search {
    display: flex;
    align-items: center;
    justify-content: flex-end;

    gap: 7px;
    margin-bottom: 10px;
}

.dt-search label {
    margin: 0;
    white-space: nowrap;
    font-size: 14px;
}

.dt-search input {
    min-width: 215px;
    height: 34px;

    border: 1px solid #adb5bd;
    border-radius: 6px;

    padding: 5px 10px;
}

.dt-search input:focus {
    border-color: #86b7fe;

    box-shadow:
        0 0 0 0.2rem rgba(13, 110, 253, 0.15);

    outline: none;
}

/* =========================================================
   DATATABLE BUTTONS
   ========================================================= */

.dt-buttons {
    display: flex;
    flex-wrap: wrap;
    gap: 3px;
}

.dt-buttons .btn {
    margin: 0 !important;
    border-radius: 5px;
}

.dt-buttons .btn:hover {
    opacity: 0.9;
}

/* =========================================================
   PAGINATION
   ========================================================= */

.dt-paging {
    margin-top: 10px;
}

.dt-paging .pagination {
    margin-bottom: 0;
}

/* =========================================================
   INFO
   ========================================================= */

.dt-info {
    padding-top: 12px;

    font-size: 14px;
    color: #495057;
}

/* =========================================================
   TABLE RESPONSIVE
   ========================================================= */

.table-responsive {
    width: 100%;

    overflow-x: auto;
    -webkit-overflow-scrolling: touch;
}

/* =========================================================
   RESPONSIVE DATATABLE
   ========================================================= */

#tableWarga.dtr-inline.collapsed > tbody > tr > td.dtr-control,
#tableWarga.dtr-inline.collapsed > tbody > tr > th.dtr-control {
    position: relative;
    padding-left: 30px;
}

#tableWarga.dtr-inline.collapsed > tbody > tr > td.dtr-control:before,
#tableWarga.dtr-inline.collapsed > tbody > tr > th.dtr-control:before {
    top: 50%;
    left: 8px;

    transform: translateY(-50%);
}

/* =========================================================
   MOBILE
   ========================================================= */

@media (max-width: 768px) {

    main {
        padding: 15px !important;
    }

    .dt-search {
        justify-content: flex-start;

        width: 100%;
        margin-top: 8px;
    }

    .dt-search input {
        width: 100%;
        min-width: 0;
    }

    .dt-length {
        width: 100%;
    }

    .dt-buttons {
        width: 100%;
        margin-top: 8px;
    }

    .dt-buttons .btn {
        margin-bottom: 3px !important;
    }

    #tableWarga {
        min-width: 1900px !important;
    }

    .card-header {
        padding: 14px !important;
    }

    .stat-icon {
        width: 45px;
        height: 45px;
        font-size: 19px;
    }

}

/* =========================================================
   VERY SMALL SCREEN
   ========================================================= */

@media (max-width: 480px) {

    .dt-length {
        justify-content: flex-start;
    }

    .dt-search {
        display: block;
    }

    .dt-search label {
        display: inline-block;
        margin-bottom: 5px;
    }

    .dt-search input {
        display: block;
        width: 100%;
    }

}

</style>

<!-- =========================================================
     DATATABLES JAVASCRIPT
     ========================================================= -->

<script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>

<script src="https://cdn.datatables.net/2.3.3/js/dataTables.min.js"></script>

<script src="https://cdn.datatables.net/2.3.3/js/dataTables.bootstrap5.min.js"></script>

<script src="https://cdn.datatables.net/buttons/3.2.5/js/dataTables.buttons.min.js"></script>

<script src="https://cdn.datatables.net/buttons/3.2.5/js/buttons.bootstrap5.min.js"></script>

<script src="https://cdn.datatables.net/responsive/3.0.5/js/dataTables.responsive.min.js"></script>

<script src="https://cdn.datatables.net/responsive/3.0.5/js/responsive.bootstrap5.min.js"></script>

<script src="https://cdnjs.cloudflare.com/ajax/libs/jszip/3.10.1/jszip.min.js"></script>

<script src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.2.20/pdfmake.min.js"></script>

<script src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.2.20/vfs_fonts.js"></script>

<script src="https://cdn.datatables.net/buttons/3.2.5/js/buttons.html5.min.js"></script>

<script src="https://cdn.datatables.net/buttons/3.2.5/js/buttons.print.min.js"></script>

<script src="https://cdn.datatables.net/buttons/3.2.5/js/buttons.colVis.min.js"></script>

<!-- =========================================================
     SWEETALERT
     ========================================================= -->

<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

<script>

document.addEventListener('DOMContentLoaded', function () {

    /* =====================================================
       DATATABLE
       ===================================================== */

    new DataTable('#tableWarga', {

        responsive: true,

        pageLength: 10,

        lengthMenu: [
            [10, 25, 50, 100, -1],
            [10, 25, 50, 100, 'Semua']
        ],

        /*
         * Urutkan berdasarkan Nama Lengkap
         *
         * Setelah kolom Alamat ditambahkan,
         * Nama Lengkap sekarang tetap = index 5.
         */
        order: [
            [5, 'asc']
        ],

        layout: {

            /* =================================================
               BARIS ATAS KIRI
               ================================================= */

            topStart: {
                pageLength: {
                    menu: [10, 25, 50, 100, -1]
                }
            },

            /* =================================================
               BARIS ATAS KANAN
               ================================================= */

            topEnd: {
                search: {
                    placeholder: 'Cari data warga...'
                }
            },

            /* =================================================
               BAWAH - EXPORT
               ================================================= */

            bottomStart: {

                buttons: [

                    /* COPY */
                    {
                        extend: 'copy',
                        text: '<i class="bi bi-copy me-1"></i> Copy',
                        className: 'btn btn-secondary btn-sm'
                    },

                    /* CSV */
                    {
                        extend: 'csv',
                        text: '<i class="bi bi-filetype-csv me-1"></i> CSV',
                        className: 'btn btn-secondary btn-sm'
                    },

                    /* EXCEL */
                    {
                        extend: 'excel',
                        text: '<i class="bi bi-file-earmark-excel me-1"></i> Excel',
                        className: 'btn btn-success btn-sm'
                    },

                    /* PDF */
                    {
                        extend: 'pdf',
                        text: '<i class="bi bi-file-earmark-pdf me-1"></i> PDF',

                        className: 'btn btn-danger btn-sm',

                        title: 'Data Warga',

                        filename: 'data-warga',

                        orientation: 'landscape',

                        pageSize: 'A4'
                    },

                    /* PRINT */
                    {
                        extend: 'print',
                        text: '<i class="bi bi-printer me-1"></i> Print',
                        className: 'btn btn-secondary btn-sm'
                    },

                    /* COLUMN VISIBILITY */
                    {
                        extend: 'colvis',
                        text: '<i class="bi bi-layout-three-columns me-1"></i> Kolom',
                        className: 'btn btn-secondary btn-sm'
                    }

                ]

            },

            /* =================================================
               PAGINATION
               ================================================= */

            bottomEnd: 'paging'

        },

        /* =====================================================
           BAHASA
           ===================================================== */

        language: {

            processing: 'Memproses...',

            search: 'Cari:',

            lengthMenu: 'Show _MENU_ entries',

            info: 'Menampilkan _START_ sampai _END_ dari _TOTAL_ data',

            infoEmpty: 'Tidak ada data',

            infoFiltered: '(disaring dari _MAX_ total data)',

            zeroRecords: 'Data tidak ditemukan',

            emptyTable: 'Belum ada data warga',

            paginate: {
                first: 'Pertama',
                last: 'Terakhir',
                next: '>',
                previous: '<'
            },

            buttons: {
                copy: 'Copy',
                colvis: 'Visibilitas Kolom'
            }

        },

        /* =====================================================
           COLUMN SETTINGS
           ===================================================== */

        columnDefs: [

            /* No */
            {
                targets: 0,
                searchable: false,
                orderable: false
            },

            /*
             * Aksi
             *
             * Setelah kolom Alamat ditambahkan,
             * Aksi sekarang menjadi index 15.
             */
            {
                targets: 15,
                searchable: false,
                orderable: false
            }

        ]

    });

    /* =====================================================
       BOOTSTRAP TOOLTIP
       ===================================================== */

    const tooltipTriggerList =
        document.querySelectorAll(
            '[data-bs-toggle="tooltip"]'
        );

    [...tooltipTriggerList].map(
        tooltipTriggerEl =>
            new bootstrap.Tooltip(tooltipTriggerEl)
    );

    /* =====================================================
       SWEETALERT SUCCESS
       ===================================================== */

    <?php if (session()->getFlashdata('success')): ?>

        Swal.fire({

            icon: 'success',

            title: 'Berhasil',

            text:
                <?= json_encode(
                    session()->getFlashdata('success')
                ) ?>,

            confirmButtonText: 'OK',

            timer: 2500,

            timerProgressBar: true

        });

    <?php endif; ?>

    /* =====================================================
       SWEETALERT ERROR
       ===================================================== */

    <?php if (session()->getFlashdata('error')): ?>

        Swal.fire({

            icon: 'error',

            title: 'Gagal',

            text:
                <?= json_encode(
                    session()->getFlashdata('error')
                ) ?>,

            confirmButtonText: 'OK'

        });

    <?php endif; ?>

});

/* =========================================================
   KONFIRMASI NONAKTIFKAN WARGA
   ========================================================= */

function confirmDelete(id, nama)
{

    Swal.fire({

        title: 'Nonaktifkan Warga?',

        html:
            'Data warga<br>' +
            '<strong>' +
            nama +
            '</strong>' +
            '<br><br>' +
            'Data tidak akan dihapus secara permanen.',

        icon: 'warning',

        showCancelButton: true,

        confirmButtonColor: '#dc3545',

        cancelButtonColor: '#6c757d',

        confirmButtonText:
            '<i class="bi bi-x-circle"></i> Ya, Nonaktifkan',

        cancelButtonText: 'Batal'

    }).then((result) => {

        if (result.isConfirmed) {

            const form =
                document.getElementById(
                    'delete-form-' + id
                );

            if (form) {
                form.submit();
            }

        }

    });

}

</script>       