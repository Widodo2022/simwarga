<?= view('layouts/header', [
    'title' => $title ?? 'Edit Warga'
]) ?>

<div class="container-fluid">
    <div class="row">

        <!-- =========================================================
             SIDEBAR
             ========================================================= -->
        <div class="col-lg-2 d-none d-lg-block p-0">
            <?= view('layouts/sidebar') ?>
        </div>


        <!-- =========================================================
             CONTENT
             ========================================================= -->
        <div class="col-lg-10 content p-0">

            <?= view('layouts/navbar') ?>

            <main class="p-3 p-md-4">

                <!-- =================================================
                     HEADER
                     ================================================= -->
                <div class="d-flex flex-wrap justify-content-between align-items-center mb-4">

                    <div>
                        <h3 class="fw-bold mb-1">
                            <i class="bi bi-person-gear text-primary me-2"></i>
                            Edit Data Warga
                        </h3>

                        <p class="text-muted mb-0">
                            Perbarui data warga dan lampiran KTP.
                        </p>
                    </div>

                    <div class="mt-3 mt-md-0">
                        <a href="<?= site_url('warga') ?>"
                           class="btn btn-outline-secondary">
                            <i class="bi bi-arrow-left me-1"></i>
                            Kembali
                        </a>
                    </div>

                </div>


                <!-- =================================================
                     FORM CARD
                     ================================================= -->
                <div class="card border-0 shadow-sm edit-card">

                    <div class="card-header bg-primary text-white py-3">

                        <div class="d-flex align-items-center">

                            <div class="header-icon">
                                <i class="bi bi-person-vcard"></i>
                            </div>

                            <div>
                                <h5 class="mb-0 fw-bold">
                                    Form Edit Warga
                                </h5>

                                <small class="opacity-75">
                                    Periksa kembali data sebelum menyimpan perubahan.
                                </small>
                            </div>

                        </div>

                    </div>


                    <div class="card-body p-3 p-md-4">

                        <!-- =================================================
                             ERROR VALIDATION
                             ================================================= -->
                        <?php if (session()->getFlashdata('errors')): ?>

                            <div class="alert alert-danger border-0 shadow-sm">

                                <div class="fw-bold mb-2">
                                    <i class="bi bi-exclamation-triangle me-1"></i>
                                    Terdapat kesalahan:
                                </div>

                                <ul class="mb-0">

                                    <?php foreach (
                                        session()->getFlashdata('errors')
                                        as $error
                                    ): ?>

                                        <li>
                                            <?= esc($error) ?>
                                        </li>

                                    <?php endforeach; ?>

                                </ul>

                            </div>

                        <?php endif; ?>


                        <!-- =================================================
                             FORM
                             ================================================= -->
                        <form
                            action="<?= site_url('warga/update/' . $warga['id']) ?>"
                            method="post"
                            enctype="multipart/form-data"
                            id="formEditWarga"
                        >

                            <?= csrf_field() ?>


                            <!-- =================================================
                                 IDENTITAS
                                 ================================================= -->
                            <div class="section-title">

                                <i class="bi bi-person-badge"></i>

                                <span>
                                    Identitas Warga
                                </span>

                            </div>


                            <div class="row g-3">

                                <!-- NIK -->
                                <div class="col-md-6">

                                    <label for="nik" class="form-label">
                                        NIK
                                        <span class="text-danger">*</span>
                                    </label>

                                    <input
                                        type="text"
                                        class="form-control"
                                        id="nik"
                                        name="nik"
                                        value="<?= old('nik', $warga['nik'] ?? '') ?>"
                                        maxlength="16"
                                        required
                                    >

                                    <div class="form-text">
                                        Masukkan 16 digit NIK.
                                    </div>

                                </div>


                                <!-- NO KK -->
                                <div class="col-md-6">

                                    <label for="no_kk" class="form-label">
                                        No. KK
                                        <span class="text-danger">*</span>
                                    </label>

                                    <select
                                        class="form-select"
                                        id="no_kk"
                                        name="no_kk"
                                        required
                                    >

                                        <option value="">
                                            -- Pilih No. KK --
                                        </option>

                                        <?php foreach ($kk as $item): ?>

                                            <option
                                                value="<?= esc($item['no_kk']) ?>"
                                                <?= old(
                                                    'no_kk',
                                                    $warga['no_kk'] ?? ''
                                                ) === $item['no_kk']
                                                    ? 'selected'
                                                    : ''
                                                ?>
                                            >
                                                <?= esc($item['no_kk']) ?>
                                                -
                                                <?= esc($item['kepala_keluarga']) ?>
                                            </option>

                                        <?php endforeach; ?>

                                    </select>

                                </div>


                                <!-- NAMA -->
                                <div class="col-12">

                                    <label for="nama_lengkap" class="form-label">
                                        Nama Lengkap
                                        <span class="text-danger">*</span>
                                    </label>

                                    <input
                                        type="text"
                                        class="form-control"
                                        id="nama_lengkap"
                                        name="nama_lengkap"
                                        value="<?= old(
                                            'nama_lengkap',
                                            $warga['nama_lengkap'] ?? ''
                                        ) ?>"
                                        maxlength="150"
                                        required
                                    >

                                </div>


                                <!-- JENIS KELAMIN -->
                                <div class="col-md-4">

                                    <label for="jenis_kelamin" class="form-label">
                                        Jenis Kelamin
                                        <span class="text-danger">*</span>
                                    </label>

                                    <select
                                        class="form-select"
                                        id="jenis_kelamin"
                                        name="jenis_kelamin"
                                        required
                                    >

                                        <option value="">
                                            -- Pilih --
                                        </option>

                                        <option
                                            value="L"
                                            <?= old(
                                                'jenis_kelamin',
                                                $warga['jenis_kelamin'] ?? ''
                                            ) === 'L'
                                                ? 'selected'
                                                : ''
                                            ?>
                                        >
                                            Laki-laki
                                        </option>

                                        <option
                                            value="P"
                                            <?= old(
                                                'jenis_kelamin',
                                                $warga['jenis_kelamin'] ?? ''
                                            ) === 'P'
                                                ? 'selected'
                                                : ''
                                            ?>
                                        >
                                            Perempuan
                                        </option>

                                    </select>

                                </div>


                                <!-- TEMPAT LAHIR -->
                                <div class="col-md-4">

                                    <label for="tempat_lahir" class="form-label">
                                        Tempat Lahir
                                    </label>

                                    <input
                                        type="text"
                                        class="form-control"
                                        id="tempat_lahir"
                                        name="tempat_lahir"
                                        value="<?= old(
                                            'tempat_lahir',
                                            $warga['tempat_lahir'] ?? ''
                                        ) ?>"
                                        maxlength="100"
                                    >

                                </div>


                                <!-- TANGGAL LAHIR -->
                                <div class="col-md-4">

                                    <label for="tanggal_lahir" class="form-label">
                                        Tanggal Lahir
                                    </label>

                                    <input
                                        type="date"
                                        class="form-control"
                                        id="tanggal_lahir"
                                        name="tanggal_lahir"
                                        value="<?= old(
                                            'tanggal_lahir',
                                            $warga['tanggal_lahir'] ?? ''
                                        ) ?>"
                                    >

                                </div>

                            </div>


                            <!-- =================================================
                                 DATA SOSIAL
                                 ================================================= -->
                            <div class="section-title mt-4">

                                <i class="bi bi-people"></i>

                                <span>
                                    Data Sosial & Keluarga
                                </span>

                            </div>


                            <div class="row g-3">

                                <!-- AGAMA -->
                                <div class="col-md-4">

                                    <label for="agama" class="form-label">
                                        Agama
                                    </label>

                                    <select
                                        class="form-select"
                                        id="agama"
                                        name="agama"
                                    >

                                        <?php
                                        $agama = old(
                                            'agama',
                                            $warga['agama'] ?? ''
                                        );
                                        ?>

                                        <option value="">
                                            -- Pilih Agama --
                                        </option>

                                        <option value="ISLAM"
                                            <?= $agama === 'ISLAM' ? 'selected' : '' ?>>
                                            Islam
                                        </option>

                                        <option value="KRISTEN"
                                            <?= $agama === 'KRISTEN' ? 'selected' : '' ?>>
                                            Kristen
                                        </option>

                                        <option value="KATOLIK"
                                            <?= $agama === 'KATOLIK' ? 'selected' : '' ?>>
                                            Katolik
                                        </option>

                                        <option value="HINDU"
                                            <?= $agama === 'HINDU' ? 'selected' : '' ?>>
                                            Hindu
                                        </option>

                                        <option value="BUDDHA"
                                            <?= $agama === 'BUDDHA' ? 'selected' : '' ?>>
                                            Buddha
                                        </option>

                                        <option value="KONGHUCU"
                                            <?= $agama === 'KONGHUCU' ? 'selected' : '' ?>>
                                            Konghucu
                                        </option>

                                    </select>

                                </div>


                                <!-- PENDIDIKAN -->
                                <div class="col-md-4">

                                    <label for="pendidikan" class="form-label">
                                        Pendidikan
                                    </label>

                                    <input
                                        type="text"
                                        class="form-control"
                                        id="pendidikan"
                                        name="pendidikan"
                                        value="<?= old(
                                            'pendidikan',
                                            $warga['pendidikan'] ?? ''
                                        ) ?>"
                                        maxlength="100"
                                    >

                                </div>


                                <!-- PEKERJAAN -->
                                <div class="col-md-4">

                                    <label for="pekerjaan" class="form-label">
                                        Pekerjaan
                                    </label>

                                    <input
                                        type="text"
                                        class="form-control"
                                        id="pekerjaan"
                                        name="pekerjaan"
                                        value="<?= old(
                                            'pekerjaan',
                                            $warga['pekerjaan'] ?? ''
                                        ) ?>"
                                        maxlength="100"
                                    >

                                </div>


                                <!-- NO HP -->
                                <div class="col-md-4">

                                    <label for="no_hp" class="form-label">
                                        Nomor HP
                                    </label>

                                    <div class="input-group">

                                        <span class="input-group-text">
                                            <i class="bi bi-telephone"></i>
                                        </span>

                                        <input
                                            type="text"
                                            class="form-control"
                                            id="no_hp"
                                            name="no_hp"
                                            value="<?= old(
                                                'no_hp',
                                                $warga['no_hp'] ?? ''
                                            ) ?>"
                                            maxlength="20"
                                            placeholder="08xxxxxxxxxx"
                                        >

                                    </div>

                                </div>


                                <!-- HUBUNGAN -->
                                <div class="col-md-4">

                                    <label for="hubungan_keluarga" class="form-label">
                                        Hubungan Keluarga
                                        <span class="text-danger">*</span>
                                    </label>

                                    <?php
                                    $hubungan = old(
                                        'hubungan_keluarga',
                                        $warga['hubungan_keluarga'] ?? ''
                                    );
                                    ?>

                                    <select
                                        class="form-select"
                                        id="hubungan_keluarga"
                                        name="hubungan_keluarga"
                                        required
                                    >

                                        <option value="">
                                            -- Pilih Hubungan --
                                        </option>

                                        <option value="KEPALA_KELUARGA"
                                            <?= $hubungan === 'KEPALA_KELUARGA' ? 'selected' : '' ?>>
                                            Kepala Keluarga
                                        </option>

                                        <option value="ISTRI"
                                            <?= $hubungan === 'ISTRI' ? 'selected' : '' ?>>
                                            Istri
                                        </option>

                                        <option value="ANAK"
                                            <?= $hubungan === 'ANAK' ? 'selected' : '' ?>>
                                            Anak
                                        </option>

                                        <option value="ORANG_TUA"
                                            <?= $hubungan === 'ORANG_TUA' ? 'selected' : '' ?>>
                                            Orang Tua
                                        </option>

                                        <option value="FAMILI_LAIN"
                                            <?= $hubungan === 'FAMILI_LAIN' ? 'selected' : '' ?>>
                                            Famili Lain
                                        </option>

                                        <option value="LAINNYA"
                                            <?= $hubungan === 'LAINNYA' ? 'selected' : '' ?>>
                                            Lainnya
                                        </option>

                                    </select>

                                </div>


                                <!-- STATUS PERKAWINAN -->
                                <div class="col-md-4">

                                    <label for="status_perkawinan" class="form-label">
                                        Status
                                        <span class="text-danger">*</span>
                                    </label>

                                    <?php
                                    $statusPerkawinan = old(
                                        'status_perkawinan',
                                        $warga['status_perkawinan'] ?? ''
                                    );
                                    ?>

                                    <select
                                        class="form-select"
                                        id="status_perkawinan"
                                        name="status_perkawinan"
                                        required
                                    >

                                        <option value="">
                                            -- Pilih Status --
                                        </option>

                                        <option value="KAWIN"
                                            <?= $statusPerkawinan === 'KAWIN' ? 'selected' : '' ?>>
                                            Kawin
                                        </option>

                                        <option value="BELUM_KAWIN"
                                            <?= $statusPerkawinan === 'BELUM_KAWIN' ? 'selected' : '' ?>>
                                            Belum Kawin
                                        </option>

                                        <option value="JANDA"
                                            <?= $statusPerkawinan === 'JANDA' ? 'selected' : '' ?>>
                                            Janda
                                        </option>

                                        <option value="DUDA"
                                            <?= $statusPerkawinan === 'DUDA' ? 'selected' : '' ?>>
                                            Cerai MAti
                                        </option>

                                        <option value="MENINGGAL"
                                            <?= $statusPerkawinan === 'MENINGGAL' ? 'selected' : '' ?>>
                                            Meninggal
                                        </option>

                                        <option value="LAIN_LAIN"
                                            <?= $statusPerkawinan === 'LAIN_LAIN' ? 'selected' : '' ?>>
                                            Lain Lain
                                        </option>

                                    </select>

                                </div>


                                <!-- STATUS DATA -->
                                <div class="col-md-4">

                                    <label for="status" class="form-label">
                                        Status Data
                                        <span class="text-danger">*</span>
                                    </label>

                                    <?php
                                    $statusData = old(
                                        'status',
                                        $warga['status'] ?? 'aktif'
                                    );
                                    ?>

                                    <select
                                        class="form-select"
                                        id="status"
                                        name="status"
                                        required
                                    >

                                        <option value="aktif"
                                            <?= $statusData === 'aktif' ? 'selected' : '' ?>>
                                            Aktif
                                        </option>

                                        <option value="nonaktif"
                                            <?= $statusData === 'nonaktif' ? 'selected' : '' ?>>
                                            Nonaktif
                                        </option>

                                    </select>

                                </div>

                            </div>


                            <!-- =================================================
                                 LAMPIRAN KTP
                                 ================================================= -->
                            <div class="section-title mt-4">

                                <i class="bi bi-file-earmark-image"></i>

                                <span>
                                    Lampiran KTP
                                </span>

                            </div>


                            <div class="row g-3 align-items-start">

                                <div class="col-md-6">

                                    <label for="lampiran_ktp" class="form-label">
                                        Ganti Lampiran KTP
                                    </label>

                                    <input
                                        type="file"
                                        class="form-control"
                                        id="lampiran_ktp"
                                        name="lampiran_ktp"
                                        accept="image/jpeg,image/png,image/webp,pdf"
                                    >

                                    <div class="form-text">
                                        Kosongkan jika tidak ingin mengganti KTP.
                                        Format JPG, PNG,pdf atau WEBP.
                                    </div>

                                </div>


                                <!-- PREVIEW KTP -->
                                <div class="col-md-6">

                                <label class="form-label">
                                    KTP Saat Ini
                                </label>

                                <div class="ktp-preview" id="ktpPreviewContainer">

                                    <?php if (!empty($warga['lampiran_ktp'])): ?>

                                        <a
                                            id="ktpPreviewLink"
                                            href="<?= site_url('warga/ktp/' . $warga['id']) ?>"
                                            target="_blank"
                                            data-bs-toggle="tooltip"
                                            title="Lihat KTP ukuran penuh"
                                        >

                                            <img
                                                id="previewKtp"
                                                src="<?= site_url('warga/ktp/' . $warga['id']) ?>"
                                                alt="KTP <?= esc($warga['nama_lengkap']) ?>"
                                            >

                                        </a>

                                    <?php else: ?>

                                        <div
                                            id="ktpPlaceholder"
                                            class="ktp-placeholder"
                                        >

                                            <i class="bi bi-file-earmark-image"></i>

                                            <span>
                                                Belum ada lampiran KTP
                                            </span>

                                        </div>

                                    <?php endif; ?>

                                </div>

                            </div>

                            </div>


                            <!-- =================================================
                                 BUTTON
                                 ================================================= -->
                            <div class="form-actions mt-4 pt-3">

                                <a
                                    href="<?= site_url('warga') ?>"
                                    class="btn btn-light border"
                                >
                                    <i class="bi bi-x-circle me-1"></i>
                                    Batal
                                </a>

                                <button
                                    type="submit"
                                    class="btn btn-primary"
                                >
                                    <i class="bi bi-save me-1"></i>
                                    Simpan Perubahan
                                </button>

                            </div>

                        </form>

                    </div>

                </div>

            </main>


            <?= view('layouts/footer') ?>

        </div>

    </div>
</div>


<!-- =========================================================
     SWEETALERT
     ========================================================= -->

<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>


<!-- =========================================================
     CUSTOM CSS
     ========================================================= -->

<style>

.edit-card {
    border-radius: 14px;
    overflow: hidden;
}

.card {
    border-radius: 14px;
}


/* =========================================================
   HEADER
   ========================================================= */

.header-icon {
    width: 44px;
    height: 44px;

    border-radius: 10px;

    background: rgba(255, 255, 255, 0.15);

    display: flex;
    align-items: center;
    justify-content: center;

    font-size: 20px;

    margin-right: 12px;
}


/* =========================================================
   SECTION TITLE
   ========================================================= */

.section-title {
    display: flex;
    align-items: center;

    gap: 9px;

    padding-bottom: 10px;

    margin-bottom: 15px;

    border-bottom: 1px solid #e9ecef;

    color: #495057;

    font-size: 15px;
    font-weight: 700;
}

.section-title i {
    color: #0d6efd;
    font-size: 18px;
}


/* =========================================================
   FORM
   ========================================================= */

.form-label {
    font-weight: 600;
    font-size: 14px;

    margin-bottom: 6px;
}

.form-control,
.form-select {
    min-height: 42px;

    border-radius: 8px;

    border-color: #ced4da;
}

.form-control:focus,
.form-select:focus {

    border-color: #86b7fe;

    box-shadow:
        0 0 0 0.2rem rgba(13, 110, 253, 0.12);
}

.input-group-text {
    border-radius: 8px 0 0 8px;
    background-color: #f8f9fa;
}


/* =========================================================
   KTP PREVIEW
   ========================================================= */

.ktp-preview {

    min-height: 180px;

    border: 1px dashed #ced4da;

    border-radius: 10px;

    background-color: #f8f9fa;

    display: flex;

    align-items: center;

    justify-content: center;

    padding: 10px;

}

.ktp-preview img {

    display: block;

    max-width: 100%;

    width: 300px;

    max-height: 180px;

    object-fit: contain;

    border-radius: 8px;

    border: 1px solid #dee2e6;

    background: #fff;

    transition: transform 0.2s ease;

}

.ktp-preview img:hover {
    transform: scale(1.02);
}

.ktp-placeholder {

    display: flex;

    flex-direction: column;

    align-items: center;

    justify-content: center;

    gap: 8px;

    color: #6c757d;

    font-size: 14px;

    text-align: center;

}

.ktp-placeholder i {
    font-size: 40px;
}


/* =========================================================
   FORM ACTION
   ========================================================= */

.form-actions {

    display: flex;

    justify-content: flex-end;

    gap: 8px;

    border-top: 1px solid #e9ecef;
}

.form-actions .btn {

    min-width: 130px;

    border-radius: 8px;

}


/* =========================================================
   RESPONSIVE
   ========================================================= */

@media (max-width: 768px) {

    main {
        padding: 15px !important;
    }

    .form-actions {

        flex-direction: column-reverse;

    }

    .form-actions .btn {

        width: 100%;

    }

    .ktp-preview {

        min-height: 160px;

    }

}

</style>


<!-- =========================================================
     PREVIEW KTP BARU
     ========================================================= -->

<script>

document.addEventListener('DOMContentLoaded', function () {

    const inputKtp = document.getElementById('lampiran_ktp');

    const previewKtp = document.getElementById('previewKtp');

    if (inputKtp) {

        inputKtp.addEventListener('change', function (event) {

            const file = event.target.files[0];

            if (!file) {
                return;
            }

            if (!file.type.startsWith('image/')) {

                Swal.fire({
                    icon: 'error',
                    title: 'File tidak valid',
                    text: 'Lampiran KTP harus berupa gambar.'
                });

                inputKtp.value = '';

                return;
            }

            const reader = new FileReader();

            reader.onload = function (e) {

                if (previewKtp) {

                    previewKtp.src = e.target.result;

                } else {

                    const placeholder =
                        document.getElementById('ktpPlaceholder');

                    if (placeholder) {

                        placeholder.innerHTML = '';

                        const img =
                            document.createElement('img');

                        img.id = 'previewKtp';

                        img.src = e.target.result;

                        img.alt = 'Preview KTP';

                        placeholder.replaceWith(img);

                    }

                }

            };

            reader.readAsDataURL(file);

        });

    }


    /* =====================================================
       SWEETALERT SUCCESS
       ===================================================== */

    <?php if (session()->getFlashdata('success')): ?>

        Swal.fire({

            icon: 'success',

            title: 'Berhasil',

            text:
                <?= json_encode(
                    session()->getFlashdata('success')
                ) ?>,

            confirmButtonText: 'OK',

            timer: 2500,

            timerProgressBar: true

        });

    <?php endif; ?>


    /* =====================================================
       SWEETALERT ERROR
       ===================================================== */

    <?php if (session()->getFlashdata('error')): ?>

        Swal.fire({

            icon: 'error',

            title: 'Gagal',

            text:
                <?= json_encode(
                    session()->getFlashdata('error')
                ) ?>,

            confirmButtonText: 'OK'

        });

    <?php endif; ?>


    /* =====================================================
       TOOLTIP
       ===================================================== */

    const tooltipTriggerList =
        document.querySelectorAll(
            '[data-bs-toggle="tooltip"]'
        );

    if (typeof bootstrap !== 'undefined') {

        [...tooltipTriggerList].map(
            tooltipTriggerEl =>
                new bootstrap.Tooltip(tooltipTriggerEl)
        );

    }

});

</script>