<?= view('layouts/header', [
    'title' => $title ?? 'Tambah Warga'
]) ?>

<div class="container-fluid">
    <div class="row">

        <!-- SIDEBAR -->
        <div class="col-lg-2 d-none d-lg-block p-0">
            <?= view('layouts/sidebar') ?>
        </div>

        <!-- CONTENT -->
        <div class="col-lg-10 content p-0">

            <?= view('layouts/navbar') ?>

            <main class="p-4">

                <!-- JUDUL -->
                <div class="d-flex justify-content-between align-items-center mb-4">
                    <div>
                        <h4 class="mb-1">
                            <i class="bi bi-person-plus me-2"></i>
                            Tambah Warga
                        </h4>
                        <p class="text-muted mb-0">
                            Tambahkan data anggota keluarga baru.
                        </p>
                    </div>

                    <a href="<?= site_url('warga') ?>" class="btn btn-secondary">
                        <i class="bi bi-arrow-left me-1"></i>
                        Kembali
                    </a>
                </div>

                <!-- PESAN ERROR -->
                <?php if (session()->getFlashdata('errors')): ?>
                    <div class="alert alert-danger">
                        <strong>Terjadi kesalahan:</strong>

                        <ul class="mb-0 mt-2">
                            <?php foreach (session()->getFlashdata('errors') as $error): ?>
                                <li><?= esc($error) ?></li>
                            <?php endforeach; ?>
                        </ul>
                    </div>
                <?php endif; ?>

                <!-- FORM -->
                <div class="card shadow-sm border-0">
                    <div class="card-body">

                        <form
                            action="<?= site_url('warga') ?>"
                            method="post"
                            enctype="multipart/form-data"
                        >

                            <?= csrf_field() ?>
                        
                            <div class="row g-3">

                                <!-- NIK -->
                                <div class="col-md-6">
                                    <label for="nik" class="form-label">
                                        NIK <span class="text-danger">*</span>
                                    </label>

                                    <input
                                        type="text"
                                        class="form-control"
                                        id="nik"
                                        name="nik"
                                        value="<?= old('nik') ?>"
                                        maxlength="16"
                                        required
                                    >

                                    <div class="form-text">
                                        Masukkan 16 digit NIK.
                                    </div>
                                </div>

                                <!-- NO KK -->
                                <div class="col-md-6">

    <label for="no_kk" class="form-label">
        No. KK
        <span class="text-danger">*</span>
    </label>

    <?php
    $selectedKk = old(
        'no_kk',
        $no_kk ?? ''
    );
    ?>

    <select
        class="form-select"
        id="no_kk"
        name="no_kk"
        required
    >

        <option value="">
            -- Pilih Kartu Keluarga --
        </option>

        <?php foreach ($kk as $item): ?>

            <option
                value="<?= esc($item['no_kk']) ?>"
                <?= $selectedKk === $item['no_kk'] ? 'selected' : '' ?>
            >
                <?= esc($item['no_kk']) ?>
                -
                <?= esc($item['kepala_keluarga']) ?>
            </option>

        <?php endforeach; ?>

    </select>

</div>

                                <!-- NAMA -->
                                <div class="col-md-6">
                                    <label for="nama_lengkap" class="form-label">
                                        Nama Lengkap <span class="text-danger">*</span>
                                    </label>

                                    <input
                                        type="text"
                                        class="form-control"
                                        id="nama_lengkap"
                                        name="nama_lengkap"
                                        value="<?= old('nama_lengkap') ?>"
                                        maxlength="150"
                                        required
                                    >
                                </div>

                                <!-- JENIS KELAMIN -->
                                <div class="col-md-6">
                                    <label for="jenis_kelamin" class="form-label">
                                        Jenis Kelamin <span class="text-danger">*</span>
                                    </label>

                                    <select
                                        class="form-select"
                                        id="jenis_kelamin"
                                        name="jenis_kelamin"
                                        required
                                    >
                                        <option value="">-- Pilih --</option>
                                        <option
                                            value="L"
                                            <?= old('jenis_kelamin') === 'L' ? 'selected' : '' ?>
                                        >
                                            Laki-laki
                                        </option>
                                        <option
                                            value="P"
                                            <?= old('jenis_kelamin') === 'P' ? 'selected' : '' ?>
                                        >
                                            Perempuan
                                        </option>
                                    </select>
                                </div>

                                <!-- TEMPAT LAHIR -->
                                <div class="col-md-6">
                                    <label for="tempat_lahir" class="form-label">
                                        Tempat Lahir
                                    </label>

                                    <input
                                        type="text"
                                        class="form-control"
                                        id="tempat_lahir"
                                        name="tempat_lahir"
                                        value="<?= old('tempat_lahir') ?>"
                                        maxlength="100"
                                    >
                                </div>

                                <!-- TANGGAL LAHIR -->
                                <div class="col-md-6">
                                    <label for="tanggal_lahir" class="form-label">
                                        Tanggal Lahir
                                    </label>

                                    <input
                                        type="date"
                                        class="form-control"
                                        id="tanggal_lahir"
                                        name="tanggal_lahir"
                                        value="<?= old('tanggal_lahir') ?>"
                                    >
                                </div>

                               <!-- AGAMA -->
                                    <div class="col-md-6">
                                        <label for="agama" class="form-label">
                                            Agama
                                        </label>

                                        <select
                                            class="form-select"
                                            id="agama"
                                            name="agama"
                                        >
                                            <option value="">
                                                -- Pilih Agama --
                                            </option>

                                            <option value="ISLAM"
                                                <?= old('agama', $warga['agama'] ?? '') === 'ISLAM' ? 'selected' : '' ?>>
                                                Islam
                                            </option>

                                            <option value="KRISTEN"
                                                <?= old('agama', $warga['agama'] ?? '') === 'KRISTEN' ? 'selected' : '' ?>>
                                                Kristen
                                            </option>

                                            <option value="KATOLIK"
                                                <?= old('agama', $warga['agama'] ?? '') === 'KATOLIK' ? 'selected' : '' ?>>
                                                Katolik
                                            </option>

                                            <option value="HINDU"
                                                <?= old('agama', $warga['agama'] ?? '') === 'HINDU' ? 'selected' : '' ?>>
                                                Hindu
                                            </option>

                                            <option value="BUDDHA"
                                                <?= old('agama', $warga['agama'] ?? '') === 'BUDDHA' ? 'selected' : '' ?>>
                                                Buddha
                                            </option>

                                            <option value="KONGHUCU"
                                                <?= old('agama', $warga['agama'] ?? '') === 'KONGHUCU' ? 'selected' : '' ?>>
                                                Konghucu
                                            </option>
                                        </select>
                                    </div>

                                <!-- PENDIDIKAN -->
                                <div class="col-md-6">
                                    <label for="pendidikan" class="form-label">
                                        Pendidikan
                                    </label>

                                    <input
                                        type="text"
                                        class="form-control"
                                        id="pendidikan"
                                        name="pendidikan"
                                        value="<?= old('pendidikan') ?>"
                                        maxlength="100"
                                    >
                                </div>

                                <!-- PEKERJAAN -->
                                <div class="col-md-6">
                                    <label for="pekerjaan" class="form-label">
                                        Pekerjaan
                                    </label>

                                    <input
                                        type="text"
                                        class="form-control"
                                        id="pekerjaan"
                                        name="pekerjaan"
                                        value="<?= old('pekerjaan') ?>"
                                        maxlength="100"
                                    >
                                </div>

                                <!-- NO HP -->
                                <div class="col-md-6">
                                    <label for="no_hp" class="form-label">
                                        No. HP
                                    </label>

                                    <input
                                        type="text"
                                        class="form-control"
                                        id="no_hp"
                                        name="no_hp"
                                        value="<?= old('no_hp') ?>"
                                        maxlength="20"
                                        placeholder="Contoh: 081234567890"
                                    >
                                </div>

                                <!-- HUBUNGAN KELUARGA -->
                                <div class="col-md-6">
                                    <label for="hubungan_keluarga" class="form-label">
                                        Hubungan Keluarga <span class="text-danger">*</span>
                                    </label>

                                    <select
                                        class="form-select"
                                        id="hubungan_keluarga"
                                        name="hubungan_keluarga"
                                        required
                                    >
                                        <option value="">-- Pilih --</option>

                                        <option
                                            value="KEPALA_KELUARGA"
                                            <?= old('hubungan_keluarga') === 'KEPALA_KELUARGA' ? 'selected' : '' ?>
                                        >
                                            Kepala Keluarga
                                        </option>

                                        <option
                                            value="ISTRI"
                                            <?= old('hubungan_keluarga') === 'ISTRI' ? 'selected' : '' ?>
                                        >
                                            Istri
                                        </option>

                                        <option
                                            value="ANAK"
                                            <?= old('hubungan_keluarga') === 'ANAK' ? 'selected' : '' ?>
                                        >
                                            Anak
                                        </option>

                                        <option
                                            value="ORANG_TUA"
                                            <?= old('hubungan_keluarga') === 'ORANG_TUA' ? 'selected' : '' ?>
                                        >
                                            Orang Tua
                                        </option>

                                        <option
                                            value="FAMILI_LAIN"
                                            <?= old('hubungan_keluarga') === 'FAMILI_LAIN' ? 'selected' : '' ?>
                                        >
                                            Famili Lain
                                        </option>

                                        <option
                                            value="LAINNYA"
                                            <?= old('hubungan_keluarga') === 'LAINNYA' ? 'selected' : '' ?>
                                        >
                                            Lainnya
                                        </option>
                                    </select>
                                </div>

                                <!-- STATUS DATA -->
                                <div class="col-md-6">
                                    <label for="status" class="form-label">
                                        Status Data<span class="text-danger">*</span>
                                    </label>

                                    <select
                                        class="form-select"
                                        id="status"
                                        name="status"
                                        required
                                    >
                                        <option
                                            value="aktif"
                                            <?= old('status', 'aktif') === 'aktif' ? 'selected' : '' ?>
                                        >
                                            Aktif
                                        </option>

                                        <option
                                            value="nonaktif"
                                            <?= old('status') === 'nonaktif' ? 'selected' : '' ?>
                                        >
                                            Nonaktif
                                        </option>
                                    </select>
                                </div>


                                <!-- STATUS PERKAWINAN -->
                                <div class="col-md-6">
                                    <label for="status_perkawinan" class="form-label">
                                        Status Perkawinan <span class="text-danger">*</span>
                                    </label>

                                    <select
                                        class="form-select"
                                        id="status_perkawinan"
                                        name="status_perkawinan"
                                        required
                                    >
                                        <option value="">-- Pilih Status --</option>

                                        <option
                                            value="KAWIN"
                                            <?= old('status_perkawinan', 'BELUM_KAWIN') === 'KAWIN' ? 'selected' : '' ?>
                                        >
                                            Kawin
                                        </option>

                                        <option
                                            value="BELUM_KAWIN"
                                            <?= old('status_perkawinan', 'BELUM_KAWIN') === 'BELUM_KAWIN' ? 'selected' : '' ?>
                                        >
                                            Belum Kawin
                                        </option>

                                        <option
                                            value="JANDA"
                                            <?= old('status_perkawinan') === 'JANDA' ? 'selected' : '' ?>
                                        >
                                            Janda
                                        </option>

                                        <option
                                            value="DUDA"
                                            <?= old('status_perkawinan') === 'DUDA' ? 'selected' : '' ?>
                                        >
                                            Duda
                                        </option>

                                        <option
                                            value="MENINGGAL"
                                            <?= old('status_perkawinan') === 'MENINGGAL' ? 'selected' : '' ?>
                                        >
                                            Meninggal
                                        </option>

                                        <option
                                            value="LAIN_LAIN"
                                            <?= old('status_perkawinan') === 'LAIN_LAIN' ? 'selected' : '' ?>
                                        >
                                            Lain Lain
                                        </option>
                                    </select>
                                </div>

                                <!-- LAMPIRAN KTP -->
                                <div class="col-md-6">
                                    <label for="lampiran_ktp" class="form-label">
                                        Lampiran KTP
                                    </label>

                                    <input
                                        type="file"
                                        class="form-control"
                                        id="lampiran_ktp"
                                        name="lampiran_ktp"
                                        accept=".jpg,.jpeg,.png,.pdf"
                                    >

                                    <div class="form-text">
                                        Format: JPG, JPEG, PNG, atau PDF.
                                        Maksimal 5 MB.
                                    </div>
                                </div>

                            </div>

                            <!-- BUTTON -->
                            <div class="d-flex justify-content-end gap-2 mt-4">

                                <a
                                    href="<?= site_url('warga') ?>"
                                    class="btn btn-light border"
                                >
                                    Batal
                                </a>

                                <button
                                    type="submit"
                                    class="btn btn-primary"
                                >
                                    <i class="bi bi-save me-1"></i>
                                    Simpan Data Warga
                                </button>

                            </div>

                        </form>

                    </div>
                </div>

            </main>

        </div>
    </div>
</div>

<?= view('layouts/footer') ?>