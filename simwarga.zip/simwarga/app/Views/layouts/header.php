<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="<?= csrf_hash() ?>">

    <title><?= esc($title ?? 'SIMWARGA') ?> - RT007/RW023</title>

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css" rel="stylesheet">

    <style>
        :root {
            --sim-primary: #0d6efd;
            --sim-bg: #f4f6f9;
        }

        body {
            background: var(--sim-bg);
            color: #212529;
        }

        .sidebar {
            min-height: 100vh;
            background: #212529;
        }

        .sidebar .brand {
            font-size: 1.1rem;
            font-weight: 700;
        }

        .sidebar a {
            color: rgba(255,255,255,.75);
            text-decoration: none;
            display: block;
            padding: 10px 12px;
            border-radius: 8px;
            margin-bottom: 3px;
            transition: .15s ease;
        }

        .sidebar a:hover,
        .sidebar a.active {
            color: #fff;
            background: rgba(255,255,255,.12);
        }

        .content {
            min-height: 100vh;
        }

        .card,
        .stat-card {
            border-radius: 12px;
        }

        .navbar {
            min-height: 58px;
        }

        .form-control:focus,
        .form-select:focus {
            border-color: #86b7fe;
            box-shadow: 0 0 0 .2rem rgba(13,110,253,.12);
        }
    </style>
</head>

<body>
