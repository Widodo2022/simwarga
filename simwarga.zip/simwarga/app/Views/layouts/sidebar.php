<div class="sidebar p-3">
    <div class="brand text-white mb-4">
        <i class="bi bi-buildings me-1"></i> SIMWARGA
        <div class="small text-secondary">RT007 / RW023</div>
    </div>
    <nav aria-label="Navigasi utama">
        <?php if (canAccess('dashboard.view')): ?>
        <a href="<?= site_url('dashboard') ?>"><i class="bi bi-speedometer2 me-2"></i>Dashboard</a>
        <?php endif; ?>

        <?php if (canAccess('kk.view') || canAccess('warga.view')): ?>
        <div class="text-secondary small mt-4 mb-2">DATA UTAMA</div>
        <?php if (canAccess('kk.view')): ?><a href="<?= site_url('kartu-keluarga') ?>"><i class="bi bi-house-door me-2"></i>Data Kartu Keluarga</a><?php endif; ?>
        <?php if (canAccess('warga.view')): ?><a href="<?= site_url('warga') ?>"><i class="bi bi-people me-2"></i>Data Warga</a><?php endif; ?>
        <?php endif; ?>

        <?php if (canAccess('jenis_iuran.view') || canAccess('tagihan_iuran.view') || canAccess('pembayaran_iuran.view') || canAccess('pengeluaran.view') || canAccess('keuangan.view')): ?>
        <div class="text-secondary small mt-4 mb-2">KEUANGAN</div>
        <?php if (canAccess('jenis_iuran.view')): ?><a href="<?= site_url('jenis-iuran') ?>"><i class="bi bi-receipt me-2"></i>Jenis Iuran</a><?php endif; ?>
        <?php if (canAccess('tagihan_iuran.view')): ?><a href="<?= site_url('tagihan-iuran') ?>"><i class="bi bi-cash-stack me-2"></i>Tagihan Iuran</a><?php endif; ?>
        <?php if (canAccess('pembayaran_iuran.view')): ?><a href="<?= site_url('tagihan-iuran/pembayaran') ?>"><i class="bi bi-wallet2 me-2"></i>Pembayaran Iuran</a><?php endif; ?>
        <?php if (canAccess('pengeluaran.view')): ?><a href="<?= site_url('pengeluaran') ?>"><i class="bi bi-arrow-up-right-square me-2"></i>Pengeluaran RT</a><?php endif; ?>
        <?php if (canAccess('keuangan.view')): ?><a href="<?= site_url('keuangan') ?>"><i class="bi bi-journal-text me-2"></i>Keuangan RT</a><?php endif; ?>
        <?php endif; ?>

        <?php if (canAccess('rbac.manage') || canAccess('system.backup.history')): ?>
        <div class="text-secondary small mt-4 mb-2">SISTEM</div>
        <?php if (canAccess('rbac.manage')): ?><a href="<?= site_url('akses') ?>"><i class="bi bi-person-gear me-2"></i>Manajemen Akses & RBAC</a><?php endif; ?>
        <?php if (canAccess('system.backup.history')): ?><a href="<?= site_url('backup') ?>"><i class="bi bi-shield-lock me-2"></i>Backup & Restore Sistem</a><?php endif; ?>
        <?php endif; ?>

        <?php if (canAccess('laporan.view')): ?>
        <div class="text-secondary small mt-4 mb-2">LAPORAN</div>
        <a href="<?= site_url('laporan') ?>"><i class="bi bi-bar-chart me-2"></i>Laporan</a>
        <?php endif; ?>

        <div class="mt-4 pt-2 border-top border-secondary"><a href="<?= site_url('logout') ?>"><i class="bi bi-box-arrow-right me-2"></i>Logout</a></div>
    </nav>
</div>
