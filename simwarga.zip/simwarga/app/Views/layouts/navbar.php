<nav class="navbar navbar-expand-lg bg-white border-bottom shadow-sm">
    <div class="container-fluid">
        <button
            class="btn btn-outline-secondary d-lg-none"
            type="button"
            data-bs-toggle="offcanvas"
            data-bs-target="#mobileSidebar"
            aria-controls="mobileSidebar"
            aria-label="Buka menu">
            <i class="bi bi-list"></i>
        </button>

        <span class="navbar-brand ms-2 mb-0 fw-semibold">
            <?= esc($title ?? 'SIMWARGA') ?>
        </span>

        <div class="ms-auto d-flex align-items-center gap-2">
            <span class="d-none d-md-inline text-muted">
                <i class="bi bi-person-circle me-1"></i>
                <?= esc(session()->get('nama_lengkap') ?? 'Pengguna') ?>
            </span>

            <?php if (canAccess('system.backup.history')): ?>
            <a href="<?= site_url('backup') ?>" class="btn btn-outline-secondary btn-sm">Backup</a>
            <?php endif; ?>

            <a href="<?= site_url('logout') ?>" class="btn btn-outline-danger btn-sm">
                <i class="bi bi-box-arrow-right me-1"></i>Logout
            </a>
        </div>
    </div>
</nav>

<div class="offcanvas offcanvas-start text-bg-dark" tabindex="-1" id="mobileSidebar" aria-labelledby="mobileSidebarLabel">
    <div class="offcanvas-header">
        <div><div class="fw-bold" id="mobileSidebarLabel"><i class="bi bi-buildings me-1"></i>SIMWARGA</div><small class="text-white-50">RT007 / RW023</small></div>
        <button type="button" class="btn-close btn-close-white" data-bs-dismiss="offcanvas" aria-label="Tutup"></button>
    </div>
    <div class="offcanvas-body p-3"><nav>
        <?php if (canAccess('dashboard.view')): ?><a class="text-white text-decoration-none d-block py-2" href="<?= site_url('dashboard') ?>"><i class="bi bi-speedometer2 me-2"></i>Dashboard</a><?php endif; ?>
        <?php if (canAccess('kk.view') || canAccess('warga.view')): ?><div class="text-white-50 small mt-3 mb-1">DATA UTAMA</div><?php endif; ?>
        <?php if (canAccess('kk.view')): ?><a class="text-white text-decoration-none d-block py-2" href="<?= site_url('kartu-keluarga') ?>"><i class="bi bi-house-door me-2"></i>Data Kartu Keluarga</a><?php endif; ?>
        <?php if (canAccess('warga.view')): ?><a class="text-white text-decoration-none d-block py-2" href="<?= site_url('warga') ?>"><i class="bi bi-people me-2"></i>Data Warga</a><?php endif; ?>
        <?php if (canAccess('jenis_iuran.view') || canAccess('tagihan_iuran.view') || canAccess('pembayaran_iuran.view') || canAccess('pengeluaran.view') || canAccess('keuangan.view')): ?><div class="text-white-50 small mt-3 mb-1">KEUANGAN</div><?php endif; ?>
        <?php if (canAccess('jenis_iuran.view')): ?><a class="text-white text-decoration-none d-block py-2" href="<?= site_url('jenis-iuran') ?>"><i class="bi bi-receipt me-2"></i>Jenis Iuran</a><?php endif; ?>
        <?php if (canAccess('tagihan_iuran.view')): ?><a class="text-white text-decoration-none d-block py-2" href="<?= site_url('tagihan-iuran') ?>"><i class="bi bi-cash-stack me-2"></i>Tagihan Iuran</a><?php endif; ?>
        <?php if (canAccess('pembayaran_iuran.view')): ?><a class="text-white text-decoration-none d-block py-2" href="<?= site_url('tagihan-iuran/pembayaran') ?>"><i class="bi bi-wallet2 me-2"></i>Pembayaran Iuran</a><?php endif; ?>
        <?php if (canAccess('pengeluaran.view')): ?><a class="text-white text-decoration-none d-block py-2" href="<?= site_url('pengeluaran') ?>"><i class="bi bi-arrow-up-right-square me-2"></i>Pengeluaran RT</a><?php endif; ?>
        <?php if (canAccess('keuangan.view')): ?><a class="text-white text-decoration-none d-block py-2" href="<?= site_url('keuangan') ?>"><i class="bi bi-journal-text me-2"></i>Keuangan RT</a><?php endif; ?>
        <?php if (canAccess('rbac.manage') || canAccess('system.backup.history')): ?><div class="text-white-50 small mt-3 mb-1">SISTEM</div><?php endif; ?>
        <?php if (canAccess('rbac.manage')): ?><a class="text-white text-decoration-none d-block py-2" href="<?= site_url('akses') ?>"><i class="bi bi-person-gear me-2"></i>Manajemen Akses & RBAC</a><?php endif; ?>
        <?php if (canAccess('system.backup.history')): ?><a class="text-white text-decoration-none d-block py-2" href="<?= site_url('backup') ?>"><i class="bi bi-shield-lock me-2"></i>Backup & Restore Sistem</a><?php endif; ?>
        <?php if (canAccess('laporan.view')): ?><div class="text-white-50 small mt-3 mb-1">LAPORAN</div><a class="text-white text-decoration-none d-block py-2" href="<?= site_url('laporan') ?>"><i class="bi bi-bar-chart me-2"></i>Laporan</a><?php endif; ?>
        <hr class="border-secondary"><a class="text-white text-decoration-none d-block py-2" href="<?= site_url('logout') ?>"><i class="bi bi-box-arrow-right me-2"></i>Logout</a>
    </nav></div>
</div>
