<footer class="border-top bg-white mt-4 py-3">
    <div class="container-fluid text-center text-muted small">
        SIMWARGA RT007 / RW023 &copy; <?= date('Y') ?>
    </div>
</footer>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
