<?= view('layouts/header', [
    'title' => $title ?? 'Jenis Iuran'
]) ?>

<div class="container-fluid">
    <div class="row">

        <!-- =========================================================
             SIDEBAR
             ========================================================= -->
        <div class="col-lg-2 d-none d-lg-block p-0">
            <?= view('layouts/sidebar') ?>
        </div>

        <!-- =========================================================
             CONTENT
             ========================================================= -->
        <div class="col-lg-10 content p-0">

            <?= view('layouts/navbar') ?>

            <main class="p-3 p-md-4">

                <!-- =================================================
                     HEADER HALAMAN
                     ================================================= -->
                <div class="d-flex flex-wrap justify-content-between align-items-center mb-4">

                    <div>
                        <h3 class="fw-bold mb-1">
                            <i class="bi bi-receipt text-primary me-2"></i>
                            Jenis Iuran
                        </h3>

                        <p class="text-muted mb-0">
                            Kelola jenis iuran RT007 / RW023.
                        </p>
                    </div>

                    <div class="mt-3 mt-md-0">
                        <a href="<?= site_url('jenis-iuran/create') ?>"
                           class="btn btn-primary shadow-sm">

                            <i class="bi bi-plus-circle me-1"></i>
                            Tambah Jenis Iuran

                        </a>
                    </div>

                </div>


                <!-- =================================================
                     STATISTIK
                     ================================================= -->
                <?php

                $totalIuran = count($jenisIuran);

                $iuranAktif = count(
                    array_filter(
                        $jenisIuran,
                        static fn ($item) =>
                            ($item['status'] ?? '') === 'aktif'
                    )
                );

                $iuranNonaktif = count(
                    array_filter(
                        $jenisIuran,
                        static fn ($item) =>
                            ($item['status'] ?? '') === 'nonaktif'
                    )
                );

                ?>

                <div class="row g-3 mb-4">

                    <!-- TOTAL -->
                    <div class="col-md-4">
                        <div class="card stat-card border-0 shadow-sm h-100">

                            <div class="card-body">

                                <div class="d-flex align-items-center">

                                    <div class="stat-icon bg-primary-subtle text-primary">
                                        <i class="bi bi-receipt"></i>
                                    </div>

                                    <div>
                                        <div class="text-muted small">
                                            Total Jenis Iuran
                                        </div>

                                        <div class="fs-4 fw-bold">
                                            <?= $totalIuran ?>
                                        </div>
                                    </div>

                                </div>

                            </div>

                        </div>
                    </div>


                    <!-- AKTIF -->
                    <div class="col-md-4">
                        <div class="card stat-card border-0 shadow-sm h-100">

                            <div class="card-body">

                                <div class="d-flex align-items-center">

                                    <div class="stat-icon bg-success-subtle text-success">
                                        <i class="bi bi-check-circle"></i>
                                    </div>

                                    <div>
                                        <div class="text-muted small">
                                            Iuran Aktif
                                        </div>

                                        <div class="fs-4 fw-bold">
                                            <?= $iuranAktif ?>
                                        </div>
                                    </div>

                                </div>

                            </div>

                        </div>
                    </div>


                    <!-- NONAKTIF -->
                    <div class="col-md-4">
                        <div class="card stat-card border-0 shadow-sm h-100">

                            <div class="card-body">

                                <div class="d-flex align-items-center">

                                    <div class="stat-icon bg-secondary-subtle text-secondary">
                                        <i class="bi bi-x-circle"></i>
                                    </div>

                                    <div>
                                        <div class="text-muted small">
                                            Iuran Nonaktif
                                        </div>

                                        <div class="fs-4 fw-bold">
                                            <?= $iuranNonaktif ?>
                                        </div>
                                    </div>

                                </div>

                            </div>

                        </div>
                    </div>

                </div>


                <!-- =================================================
                     DATA TABLE CARD
                     ================================================= -->
                <div class="card border-0 shadow-sm table-card">

                    <!-- CARD HEADER -->
                    <div class="card-header bg-primary text-white py-3">

                        <div class="d-flex flex-wrap justify-content-between align-items-center">

                            <div>
                                <h5 class="mb-0 fw-bold">
                                    <i class="bi bi-table me-2"></i>
                                    Daftar Jenis Iuran
                                </h5>

                                <small class="opacity-75">
                                    Data jenis iuran yang terdaftar dalam sistem
                                </small>
                            </div>

                            <span class="badge bg-white text-primary mt-2 mt-md-0">
                                <?= $totalIuran ?> Data
                            </span>

                        </div>

                    </div>


                    <!-- TABLE BODY -->
                    <div class="card-body">

                        <div class="table-responsive">

                            <table id="tableJenisIuran"
                                   class="table table-hover align-middle w-100">

                                <thead>

                                    <tr>

                                        <th class="text-center col-no">
                                            No
                                        </th>

                                        <th class="text-center col-kode">
                                            Kode Iuran
                                        </th>

                                        <th class="col-nama">
                                            Nama Iuran
                                        </th>

                                        <th class="col-deskripsi">
                                            Deskripsi
                                        </th>

                                        <th class="text-end col-nominal">
                                            Nominal
                                        </th>

                                        <th class="text-center col-sifat">
                                            Sifat
                                        </th>

                                        <th class="text-center col-periode">
                                            Periode
                                        </th>

                                        <th class="text-center col-tanggal">
                                            Tanggal Mulai
                                        </th>

                                        <th class="text-center col-status">
                                            Status
                                        </th>

                                        <th class="text-center col-aksi">
                                            Aksi
                                        </th>

                                    </tr>

                                </thead>


                                <tbody>

                                    <?php foreach ($jenisIuran as $i => $item): ?>

                                        <?php
                                        $sifat   = $item['sifat_iuran'] ?? '';
                                        $periode = $item['periode'] ?? '';
                                        $status  = $item['status'] ?? '';
                                        ?>

                                        <tr>

                                            <!-- NOMOR -->
                                            <td class="text-center">
                                                <?= $i + 1 ?>
                                            </td>


                                            <!-- KODE IURAN -->
                                            <td class="text-center">

                                                <span class="kode-iuran">
                                                    <?= esc($item['kode_iuran']) ?>
                                                </span>

                                            </td>


                                            <!-- NAMA IURAN -->
                                            <td>

                                                <div class="d-flex align-items-center">

                                                    <div class="avatar-icon">
                                                        <i class="bi bi-receipt"></i>
                                                    </div>

                                                    <span class="nama-iuran">
                                                        <?= esc($item['nama_iuran']) ?>
                                                    </span>

                                                </div>

                                            </td>


                                            <!-- DESKRIPSI -->
                                            <td>

                                                <?php if (! empty($item['deskripsi'])): ?>

                                                    <span class="deskripsi-iuran">
                                                        <?= esc($item['deskripsi']) ?>
                                                    </span>

                                                <?php else: ?>

                                                    <span class="text-muted">
                                                        -
                                                    </span>

                                                <?php endif; ?>

                                            </td>


                                            <!-- NOMINAL -->
                                            <td class="text-end">

                                                <span class="nominal-iuran">
                                                    Rp <?= number_format(
                                                        (float) ($item['nominal'] ?? 0),
                                                        0,
                                                        ',',
                                                        '.'
                                                    ) ?>
                                                </span>

                                            </td>


                                            <!-- SIFAT IURAN -->
                                            <td class="text-center">

                                                <?php if ($sifat === 'wajib'): ?>

                                                    <span class="sifat-badge sifat-wajib">
                                                        <i class="bi bi-exclamation-circle me-1"></i>
                                                        Wajib
                                                    </span>

                                                <?php elseif ($sifat === 'sukarela'): ?>

                                                    <span class="sifat-badge sifat-sukarela">
                                                        <i class="bi bi-hand-thumbs-up me-1"></i>
                                                        Sukarela
                                                    </span>

                                                <?php else: ?>

                                                    <span class="text-muted">
                                                        -
                                                    </span>

                                                <?php endif; ?>

                                            </td>


                                            <!-- PERIODE -->
                                            <td class="text-center">

                                                <?php if ($periode === 'bulanan'): ?>

                                                    <span class="periode-badge">
                                                        <i class="bi bi-calendar3 me-1"></i>
                                                        Bulanan
                                                    </span>

                                                <?php elseif ($periode === 'tahunan'): ?>

                                                    <span class="periode-badge">
                                                        <i class="bi bi-calendar-event me-1"></i>
                                                        Tahunan
                                                    </span>

                                                <?php elseif ($periode === 'sekali'): ?>

                                                    <span class="periode-badge">
                                                        <i class="bi bi-calendar-check me-1"></i>
                                                        Sekali
                                                    </span>

                                                <?php else: ?>

                                                    <span class="text-muted">
                                                        -
                                                    </span>

                                                <?php endif; ?>

                                            </td>


                                            <!-- TANGGAL MULAI -->
                                            <td class="text-center">

                                                <?php if (! empty($item['tanggal_mulai'])): ?>

                                                    <?= date(
                                                        'd-m-Y',
                                                        strtotime($item['tanggal_mulai'])
                                                    ) ?>

                                                <?php else: ?>

                                                    <span class="text-muted">
                                                        -
                                                    </span>

                                                <?php endif; ?>

                                            </td>


                                            <!-- STATUS -->
                                            <td class="text-center">

                                                <?php if ($status === 'aktif'): ?>

                                                    <span class="badge rounded-pill bg-success status-badge">
                                                        <i class="bi bi-check-circle me-1"></i>
                                                        Aktif
                                                    </span>

                                                <?php else: ?>

                                                    <span class="badge rounded-pill bg-secondary status-badge">
                                                        <i class="bi bi-x-circle me-1"></i>
                                                        Nonaktif
                                                    </span>

                                                <?php endif; ?>

                                            </td>


                                            <!-- =================================================
                                                 AKSI
                                                 ================================================= -->
                                            <td class="text-center">

                                                <div class="btn-group"
                                                     role="group"
                                                     aria-label="Aksi Jenis Iuran">

                                                    <!-- EDIT -->
                                                    <a href="<?= site_url(
                                                        'jenis-iuran/edit/' . (int) $item['id']
                                                    ) ?>"
                                                       class="btn btn-sm btn-outline-primary"
                                                       data-bs-toggle="tooltip"
                                                       data-bs-placement="top"
                                                       title="Edit Data">

                                                        <i class="bi bi-pencil"></i>

                                                    </a>


                                                    <!-- NONAKTIFKAN -->
                                                    <?php if ($status === 'aktif'): ?>

                                                        <button type="button"
                                                                class="btn btn-sm btn-outline-danger"
                                                                data-bs-toggle="tooltip"
                                                                data-bs-placement="top"
                                                                title="Nonaktifkan"
                                                                onclick="confirmNonaktifkan(
                                                                    <?= (int) $item['id'] ?>,
                                                                    <?= esc(json_encode($item['nama_iuran']), 'attr') ?>
                                                                )">

                                                            <i class="bi bi-x-circle"></i>

                                                        </button>

                                                        <!-- FORM NONAKTIFKAN -->
                                                        <form id="nonaktifkan-form-<?= (int) $item['id'] ?>"
                                                              action="<?= site_url(
                                                                  'jenis-iuran/delete/' . (int) $item['id']
                                                              ) ?>"
                                                              method="post"
                                                              class="d-none">

                                                            <?= csrf_field() ?>

                                                        </form>

                                                    <?php endif; ?>

                                                </div>

                                            </td>

                                        </tr>

                                    <?php endforeach; ?>

                                </tbody>

                            </table>

                        </div>

                    </div>

                </div>

            </main>


            <?= view('layouts/footer') ?>

        </div>

    </div>
</div>


<!-- =========================================================
     DATATABLES CSS
     ========================================================= -->

<link rel="stylesheet"
      href="https://cdn.datatables.net/2.3.3/css/dataTables.bootstrap5.min.css">

<link rel="stylesheet"
      href="https://cdn.datatables.net/buttons/3.2.5/css/buttons.bootstrap5.min.css">

<link rel="stylesheet"
      href="https://cdn.datatables.net/responsive/3.0.5/css/responsive.bootstrap5.min.css">


<!-- =========================================================
     CUSTOM CSS
     ========================================================= -->

<style>

.table-card {
    border-radius: 12px;
    overflow: hidden;
}

.card {
    border-radius: 12px;
}


/* =========================================================
   STAT CARD
   ========================================================= */

.stat-card {
    transition: all 0.2s ease;
}

.stat-card:hover {
    transform: translateY(-2px);
}

.stat-icon {
    width: 52px;
    height: 52px;
    border-radius: 50%;

    display: flex;
    align-items: center;
    justify-content: center;

    font-size: 23px;
    margin-right: 15px;
}


/* =========================================================
   TABLE
   ========================================================= */

#tableJenisIuran {
    width: 100% !important;
    border-collapse: collapse !important;
}

#tableJenisIuran thead th {
    background-color: #f8f9fa !important;

    border-top: 1px solid #dee2e6 !important;
    border-bottom: 2px solid #adb5bd !important;

    border-left: 1px solid #dee2e6 !important;
    border-right: 1px solid #dee2e6 !important;

    font-weight: 600;
    white-space: nowrap;
    vertical-align: middle;
}

#tableJenisIuran tbody td {
    border-left: 1px solid #dee2e6 !important;
    border-right: 1px solid #dee2e6 !important;
    border-bottom: 1px solid #dee2e6 !important;

    vertical-align: middle;
}

#tableJenisIuran tbody tr {
    border-bottom: 1px solid #dee2e6 !important;
}

#tableJenisIuran tbody tr:hover {
    background-color: #f8f9fa !important;
}


/* =========================================================
   LEBAR KOLOM
   ========================================================= */

#tableJenisIuran .col-no {
    width: 55px !important;
    min-width: 55px !important;
}

#tableJenisIuran .col-kode {
    width: 150px !important;
    min-width: 150px !important;
}

#tableJenisIuran .col-nama {
    min-width: 200px !important;
}

#tableJenisIuran .col-deskripsi {
    min-width: 250px !important;
}

#tableJenisIuran .col-nominal {
    width: 140px !important;
    min-width: 140px !important;
}

#tableJenisIuran .col-sifat {
    width: 120px !important;
    min-width: 120px !important;
}

#tableJenisIuran .col-periode {
    width: 120px !important;
    min-width: 120px !important;
}

#tableJenisIuran .col-tanggal {
    width: 125px !important;
    min-width: 125px !important;
}

#tableJenisIuran .col-status {
    width: 110px !important;
    min-width: 110px !important;
}

#tableJenisIuran .col-aksi {
    width: 95px !important;
    min-width: 95px !important;
}


/* =========================================================
   KODE IURAN
   ========================================================= */

.kode-iuran {
    display: inline-block;

    padding: 5px 9px;

    background-color: #f8f9fa;
    border: 1px solid #dee2e6;

    border-radius: 7px;

    font-size: 12px;
    font-weight: 600;

    color: #495057;

    white-space: nowrap;
}


/* =========================================================
   AVATAR
   ========================================================= */

.avatar-icon {
    width: 38px;
    height: 38px;
    min-width: 38px;

    border-radius: 50%;

    background-color: rgba(13, 110, 253, 0.10);
    color: #0d6efd;

    display: flex;
    align-items: center;
    justify-content: center;

    margin-right: 10px;
}

.nama-iuran {
    white-space: nowrap;
    font-weight: 500;
}


/* =========================================================
   DESKRIPSI
   ========================================================= */

.deskripsi-iuran {
    display: inline-block;

    max-width: 280px;

    white-space: normal;
    word-break: break-word;

    color: #495057;
}


/* =========================================================
   NOMINAL
   ========================================================= */

.nominal-iuran {
    display: inline-block;

    font-weight: 600;

    white-space: nowrap;
}


/* =========================================================
   SIFAT IURAN
   ========================================================= */

.sifat-badge {
    display: inline-flex;

    align-items: center;
    justify-content: center;

    padding: 5px 9px;

    border-radius: 7px;

    font-size: 12px;
    font-weight: 600;

    white-space: nowrap;
}

.sifat-wajib {
    background-color: #fff3cd;
    color: #856404;
    border: 1px solid #ffecb5;
}

.sifat-sukarela {
    background-color: #d1e7dd;
    color: #0f5132;
    border: 1px solid #badbcc;
}


/* =========================================================
   PERIODE
   ========================================================= */

.periode-badge {
    display: inline-flex;

    align-items: center;
    justify-content: center;

    padding: 5px 9px;

    background-color: #eef5ff;
    border: 1px solid #cfe2ff;

    border-radius: 7px;

    font-size: 12px;
    font-weight: 600;

    color: #0d6efd;

    white-space: nowrap;
}


/* =========================================================
   STATUS
   ========================================================= */

.status-badge {
    min-width: 75px;

    padding: 6px 10px;

    font-weight: 500;
}


/* =========================================================
   BUTTON AKSI
   ========================================================= */

#tableJenisIuran .btn-group {
    display: inline-flex;
    vertical-align: middle;
}

#tableJenisIuran .btn {
    border-radius: 0;
}

#tableJenisIuran .btn:first-child {
    border-top-left-radius: 6px;
    border-bottom-left-radius: 6px;
}

#tableJenisIuran .btn:last-child {
    border-top-right-radius: 6px;
    border-bottom-right-radius: 6px;
}


/* =========================================================
   DATATABLES CONTAINER
   ========================================================= */

.dt-container {
    width: 100%;
}


/* =========================================================
   SHOW ENTRIES
   ========================================================= */

.dt-length {
    display: flex;
    align-items: center;

    gap: 6px;

    margin-bottom: 10px;
}

.dt-length label {
    margin: 0;

    white-space: nowrap;

    font-size: 14px;
}

.dt-length select {
    min-width: 60px;
    height: 34px;

    padding: 3px 25px 3px 8px;

    border: 1px solid #ced4da;
    border-radius: 6px;

    background-color: #fff;
}


/* =========================================================
   SEARCH
   ========================================================= */

.dt-search {
    display: flex;
    align-items: center;
    justify-content: flex-end;

    gap: 7px;

    margin-bottom: 10px;
}

.dt-search label {
    margin: 0;

    white-space: nowrap;

    font-size: 14px;
}

.dt-search input {
    min-width: 215px;
    height: 34px;

    border: 1px solid #adb5bd;
    border-radius: 6px;

    padding: 5px 10px;
}

.dt-search input:focus {
    border-color: #86b7fe;

    box-shadow:
        0 0 0 0.2rem rgba(13, 110, 253, 0.15);

    outline: none;
}


/* =========================================================
   DATATABLE BUTTONS
   ========================================================= */

.dt-buttons {
    display: flex;

    flex-wrap: wrap;

    gap: 3px;
}

.dt-buttons .btn {
    margin: 0 !important;

    border-radius: 5px;
}

.dt-buttons .btn:hover {
    opacity: 0.9;
}


/* =========================================================
   PAGINATION
   ========================================================= */

.dt-paging {
    margin-top: 10px;
}

.dt-paging .pagination {
    margin-bottom: 0;
}


/* =========================================================
   INFO
   ========================================================= */

.dt-info {
    padding-top: 12px;

    font-size: 14px;

    color: #495057;
}


/* =========================================================
   TABLE RESPONSIVE
   ========================================================= */

.table-responsive {
    width: 100%;

    overflow-x: auto;

    -webkit-overflow-scrolling: touch;
}


/* =========================================================
   RESPONSIVE
   ========================================================= */

@media (max-width: 768px) {

    main {
        padding: 15px !important;
    }

    .dt-search {
        justify-content: flex-start;

        width: 100%;

        margin-top: 8px;
    }

    .dt-search input {
        width: 100%;

        min-width: 0;
    }

    .dt-length {
        width: 100%;
    }

    .dt-buttons {
        width: 100%;

        margin-top: 8px;
    }

    .dt-buttons .btn {
        margin-bottom: 3px !important;
    }

    #tableJenisIuran {
        min-width: 1350px !important;
    }

    .card-header {
        padding: 14px !important;
    }

    .stat-icon {
        width: 45px;
        height: 45px;

        font-size: 19px;
    }

}


/* =========================================================
   VERY SMALL SCREEN
   ========================================================= */

@media (max-width: 480px) {

    .dt-length {
        justify-content: flex-start;
    }

    .dt-search {
        display: block;
    }

    .dt-search label {
        display: inline-block;

        margin-bottom: 5px;
    }

    .dt-search input {
        display: block;

        width: 100%;
    }

}

</style>


<!-- =========================================================
     DATATABLES JAVASCRIPT
     ========================================================= -->

<script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>

<script src="https://cdn.datatables.net/2.3.3/js/dataTables.min.js"></script>

<script src="https://cdn.datatables.net/2.3.3/js/dataTables.bootstrap5.min.js"></script>

<script src="https://cdn.datatables.net/buttons/3.2.5/js/dataTables.buttons.min.js"></script>

<script src="https://cdn.datatables.net/buttons/3.2.5/js/buttons.bootstrap5.min.js"></script>

<script src="https://cdn.datatables.net/responsive/3.0.5/js/dataTables.responsive.min.js"></script>

<script src="https://cdn.datatables.net/responsive/3.0.5/js/responsive.bootstrap5.min.js"></script>

<script src="https://cdnjs.cloudflare.com/ajax/libs/jszip/3.10.1/jszip.min.js"></script>

<script src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.2.20/pdfmake.min.js"></script>

<script src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.2.20/vfs_fonts.js"></script>

<script src="https://cdn.datatables.net/buttons/3.2.5/js/buttons.html5.min.js"></script>

<script src="https://cdn.datatables.net/buttons/3.2.5/js/buttons.print.min.js"></script>

<script src="https://cdn.datatables.net/buttons/3.2.5/js/buttons.colVis.min.js"></script>


<!-- =========================================================
     SWEETALERT
     ========================================================= -->

<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>


<script>

/* =========================================================
   KONFIRMASI NONAKTIFKAN
   ========================================================= */

function confirmNonaktifkan(id, nama)
{
    Swal.fire({

        title: 'Nonaktifkan Jenis Iuran?',

        html:
            'Jenis iuran<br>' +
            '<strong>' + nama + '</strong>' +
            '<br><br>' +
            'Data tidak akan dihapus secara permanen.' +
            '<br>Status akan diubah menjadi <strong>Nonaktif</strong>.',

        icon: 'warning',

        showCancelButton: true,

        confirmButtonColor: '#dc3545',

        cancelButtonColor: '#6c757d',

        confirmButtonText:
            '<i class="bi bi-x-circle"></i> Ya, Nonaktifkan',

        cancelButtonText: 'Batal'

    }).then(function(result) {

        if (result.isConfirmed) {

            const form = document.getElementById(
                'nonaktifkan-form-' + id
            );

            if (form) {

                form.submit();

            }

        }

    });
}


/* =========================================================
   DOM READY
   ========================================================= */

document.addEventListener('DOMContentLoaded', function () {


    /* =====================================================
       DATATABLE
       ===================================================== */

    new DataTable('#tableJenisIuran', {

        responsive: true,

        pageLength: 10,

        lengthMenu: [
            [10, 25, 50, 100, -1],
            [10, 25, 50, 100, 'Semua']
        ],

        order: [
            [2, 'asc']
        ],

        layout: {

            topStart: {
                pageLength: {
                    menu: [10, 25, 50, 100, -1]
                }
            },

            topEnd: {
                search: {
                    placeholder: 'Cari jenis iuran...'
                }
            },

            bottomStart: {

                buttons: [

                    {
                        extend: 'copy',
                        text: '<i class="bi bi-copy me-1"></i> Copy',
                        className: 'btn btn-secondary btn-sm'
                    },

                    {
                        extend: 'csv',
                        text: '<i class="bi bi-filetype-csv me-1"></i> CSV',
                        className: 'btn btn-secondary btn-sm'
                    },

                    {
                        extend: 'excel',
                        text: '<i class="bi bi-file-earmark-excel me-1"></i> Excel',
                        className: 'btn btn-success btn-sm'
                    },

                    {
                        extend: 'pdf',
                        text: '<i class="bi bi-file-earmark-pdf me-1"></i> PDF',
                        className: 'btn btn-danger btn-sm',
                        title: 'Jenis Iuran',
                        filename: 'jenis-iuran',
                        orientation: 'landscape',
                        pageSize: 'A4'
                    },

                    {
                        extend: 'print',
                        text: '<i class="bi bi-printer me-1"></i> Print',
                        className: 'btn btn-secondary btn-sm'
                    },

                    {
                        extend: 'colvis',
                        text: '<i class="bi bi-layout-three-columns me-1"></i> Kolom',
                        className: 'btn btn-secondary btn-sm'
                    }

                ]

            },

            bottomEnd: 'paging'

        },

        language: {

            processing: 'Memproses...',

            search: 'Cari:',

            lengthMenu: 'Tampilkan _MENU_ data',

            info: 'Menampilkan _START_ sampai _END_ dari _TOTAL_ data',

            infoEmpty: 'Tidak ada data',

            infoFiltered: '(disaring dari _MAX_ total data)',

            zeroRecords: 'Data tidak ditemukan',

            emptyTable: 'Belum ada jenis iuran',

            paginate: {
                first: 'Pertama',
                last: 'Terakhir',
                next: '>',
                previous: '<'
            },

            buttons: {
                copy: 'Copy',
                colvis: 'Visibilitas Kolom'
            }

        },

        columnDefs: [

            {
                targets: 0,
                searchable: false,
                orderable: false
            },

            {
                targets: 9,
                searchable: false,
                orderable: false
            }

        ]

    });


    /* =====================================================
       BOOTSTRAP TOOLTIP
       ===================================================== */

    const tooltipTriggerList =
        document.querySelectorAll(
            '[data-bs-toggle="tooltip"]'
        );

    [...tooltipTriggerList].map(
        tooltipTriggerEl =>
            new bootstrap.Tooltip(tooltipTriggerEl)
    );


    /* =====================================================
       SWEETALERT SUCCESS
       ===================================================== */

    <?php if (session()->getFlashdata('success')): ?>

        Swal.fire({

            icon: 'success',

            title: 'Berhasil',

            text: <?= json_encode(
                session()->getFlashdata('success')
            ) ?>,

            confirmButtonText: 'OK',

            timer: 2500,

            timerProgressBar: true

        });

    <?php endif; ?>


    /* =====================================================
       SWEETALERT ERROR
       ===================================================== */

    <?php if (session()->getFlashdata('error')): ?>

        Swal.fire({

            icon: 'error',

            title: 'Gagal',

            text: <?= json_encode(
                session()->getFlashdata('error')
            ) ?>,

            confirmButtonText: 'OK'

        });

    <?php endif; ?>

});

</script>