<?= view('layouts/header', [
    'title' => $title ?? 'Tambah Jenis Iuran'
]) ?>

<div class="container-fluid">
    <div class="row">

        <!-- =========================================================
             SIDEBAR
             ========================================================= -->
        <div class="col-lg-2 d-none d-lg-block p-0">
            <?= view('layouts/sidebar') ?>
        </div>

        <!-- =========================================================
             CONTENT
             ========================================================= -->
        <div class="col-lg-10 content p-0">

            <?= view('layouts/navbar') ?>

            <main class="p-3 p-md-4">

                <!-- =================================================
                     HEADER HALAMAN
                     ================================================= -->
                <div class="d-flex flex-wrap justify-content-between align-items-center mb-4">

                    <div>
                        <h3 class="fw-bold mb-1">
                            <i class="bi bi-plus-circle text-primary me-2"></i>
                            Tambah Jenis Iuran
                        </h3>

                        <p class="text-muted mb-0">
                            Tambahkan jenis iuran baru ke dalam sistem keuangan RT007 / RW023.
                        </p>
                    </div>

                    <div class="mt-3 mt-md-0">
                        <a href="<?= site_url('jenis-iuran') ?>"
                           class="btn btn-light border shadow-sm">
                            <i class="bi bi-arrow-left me-1"></i>
                            Kembali
                        </a>
                    </div>

                </div>


                <!-- =================================================
                     FORM CARD
                     ================================================= -->
                <div class="card border-0 shadow-sm form-card">

                    <!-- CARD HEADER -->
                    <div class="card-header bg-primary text-white py-3">

                        <h5 class="mb-0 fw-bold">
                            <i class="bi bi-receipt me-2"></i>
                            Form Jenis Iuran
                        </h5>

                        <small class="opacity-75">
                            Lengkapi informasi jenis iuran yang akan digunakan.
                        </small>

                    </div>


                    <!-- CARD BODY -->
                    <div class="card-body p-3 p-md-4">

                        <!-- =================================================
                             ERROR VALIDASI
                             ================================================= -->
                        <?php if (session()->getFlashdata('errors')): ?>

                            <div class="alert alert-danger shadow-sm">

                                <div class="fw-bold mb-2">
                                    <i class="bi bi-exclamation-triangle me-1"></i>
                                    Terdapat kesalahan:
                                </div>

                                <ul class="mb-0">

                                    <?php foreach (
                                        session()->getFlashdata('errors')
                                        as $error
                                    ): ?>

                                        <li>
                                            <?= esc($error) ?>
                                        </li>

                                    <?php endforeach; ?>

                                </ul>

                            </div>

                        <?php endif; ?>


                        <!-- =================================================
                             FORM
                             ================================================= -->
                        <form action="<?= site_url('jenis-iuran') ?>"
                              method="post">

                            <?= csrf_field() ?>


                            <div class="row g-3">


                                <!-- =================================================
                                     KODE IURAN
                                     ================================================= -->
                                <div class="col-md-6">

                                    <label for="kode_iuran"
                                           class="form-label fw-semibold">

                                        Kode Iuran
                                        <span class="text-danger">*</span>

                                    </label>

                                    <div class="input-group">

                                        <span class="input-group-text">
                                            <i class="bi bi-upc-scan"></i>
                                        </span>

                                        <input type="text"
                                               class="form-control"
                                               id="kode_iuran"
                                               name="kode_iuran"
                                               value="<?= old('kode_iuran') ?>"
                                               maxlength="30"
                                               placeholder="Contoh: IURAN-BULANAN"
                                               required>

                                    </div>

                                    <div class="form-text">
                                        Kode harus unik dan maksimal 30 karakter.
                                    </div>

                                </div>


                                <!-- =================================================
                                     NAMA IURAN
                                     ================================================= -->
                                <div class="col-md-6">

                                    <label for="nama_iuran"
                                           class="form-label fw-semibold">

                                        Nama Iuran
                                        <span class="text-danger">*</span>

                                    </label>

                                    <div class="input-group">

                                        <span class="input-group-text">
                                            <i class="bi bi-receipt"></i>
                                        </span>

                                        <input type="text"
                                               class="form-control"
                                               id="nama_iuran"
                                               name="nama_iuran"
                                               value="<?= old('nama_iuran') ?>"
                                               maxlength="100"
                                               placeholder="Contoh: Iuran Kebersihan"
                                               required>

                                    </div>

                                </div>


                                <!-- =================================================
                                     DESKRIPSI
                                     ================================================= -->
                                <div class="col-12">

                                    <label for="deskripsi"
                                           class="form-label fw-semibold">

                                        Deskripsi

                                    </label>

                                    <textarea class="form-control"
                                              id="deskripsi"
                                              name="deskripsi"
                                              rows="3"
                                              maxlength="255"
                                              placeholder="Keterangan mengenai jenis iuran..."><?= old('deskripsi') ?></textarea>

                                    <div class="form-text">
                                        Maksimal 255 karakter.
                                    </div>

                                </div>


                                <!-- =================================================
                                     NOMINAL
                                     ================================================= -->
                                <div class="col-md-6">

                                    <label for="nominal"
                                           class="form-label fw-semibold">

                                        Nominal
                                        <span class="text-danger">*</span>

                                    </label>

                                    <div class="input-group">

                                        <span class="input-group-text">
                                            Rp
                                        </span>

                                        <input type="number"
                                               class="form-control"
                                               id="nominal"
                                               name="nominal"
                                               value="<?= old('nominal', '0') ?>"
                                               min="0"
                                               step="0.01"
                                               placeholder="0"
                                               required>

                                    </div>

                                    <div class="form-text">
                                        Masukkan nominal iuran dalam Rupiah.
                                    </div>

                                </div>


                                <!-- =================================================
                                     SIFAT IURAN
                                     ================================================= -->
                                <div class="col-md-3">

                                    <label for="sifat_iuran"
                                           class="form-label fw-semibold">

                                        Sifat Iuran
                                        <span class="text-danger">*</span>

                                    </label>

                                    <select class="form-select"
                                            id="sifat_iuran"
                                            name="sifat_iuran"
                                            required>

                                        <option value="">
                                            -- Pilih Sifat --
                                        </option>

                                        <option value="wajib"
                                            <?= old('sifat_iuran') === 'wajib'
                                                ? 'selected'
                                                : '' ?>>
                                            Wajib
                                        </option>

                                        <option value="sukarela"
                                            <?= old('sifat_iuran') === 'sukarela'
                                                ? 'selected'
                                                : '' ?>>
                                            Sukarela
                                        </option>

                                    </select>

                                </div>


                                <!-- =================================================
                                     PERIODE
                                     ================================================= -->
                                <div class="col-md-3">

                                    <label for="periode"
                                           class="form-label fw-semibold">

                                        Periode
                                        <span class="text-danger">*</span>

                                    </label>

                                    <select class="form-select"
                                            id="periode"
                                            name="periode"
                                            required>

                                        <option value="">
                                            -- Pilih Periode --
                                        </option>

                                        <option value="bulanan"
                                            <?= old('periode') === 'bulanan'
                                                ? 'selected'
                                                : '' ?>>
                                            Bulanan
                                        </option>

                                        <option value="tahunan"
                                            <?= old('periode') === 'tahunan'
                                                ? 'selected'
                                                : '' ?>>
                                            Tahunan
                                        </option>

                                        <option value="sekali"
                                            <?= old('periode') === 'sekali'
                                                ? 'selected'
                                                : '' ?>>
                                            Sekali
                                        </option>

                                    </select>

                                </div>


                                <!-- =================================================
                                     TANGGAL MULAI
                                     ================================================= -->
                                <div class="col-md-6">

                                    <label for="tanggal_mulai"
                                           class="form-label fw-semibold">

                                        Tanggal Mulai

                                    </label>

                                    <div class="input-group">

                                        <span class="input-group-text">
                                            <i class="bi bi-calendar-event"></i>
                                        </span>

                                        <input type="date"
                                               class="form-control"
                                               id="tanggal_mulai"
                                               name="tanggal_mulai"
                                               value="<?= old('tanggal_mulai') ?>">

                                    </div>

                                    <div class="form-text">
                                        Tanggal mulai berlakunya jenis iuran.
                                    </div>

                                </div>


                                <!-- =================================================
                                     STATUS
                                     ================================================= -->
                                <div class="col-md-6">

                                    <label for="status"
                                           class="form-label fw-semibold">

                                        Status
                                        <span class="text-danger">*</span>

                                    </label>

                                    <select class="form-select"
                                            id="status"
                                            name="status"
                                            required>

                                        <option value="aktif"
                                            <?= old('status', 'aktif') === 'aktif'
                                                ? 'selected'
                                                : '' ?>>
                                            Aktif
                                        </option>

                                        <option value="nonaktif"
                                            <?= old('status') === 'nonaktif'
                                                ? 'selected'
                                                : '' ?>>
                                            Nonaktif
                                        </option>

                                    </select>

                                    <div class="form-text">
                                        Jenis iuran aktif dapat digunakan dalam transaksi keuangan.
                                    </div>

                                </div>


                            </div>


                            <!-- =================================================
                                 ACTION BUTTON
                                 ================================================= -->
                            <div class="d-flex flex-wrap justify-content-end gap-2 mt-4 pt-3 border-top">

                                <a href="<?= site_url('jenis-iuran') ?>"
                                   class="btn btn-light border">

                                    <i class="bi bi-x-circle me-1"></i>
                                    Batal

                                </a>

                                <button type="submit"
                                        class="btn btn-primary px-4">

                                    <i class="bi bi-save me-1"></i>
                                    Simpan Jenis Iuran

                                </button>

                            </div>


                        </form>

                    </div>

                </div>

            </main>

            <?= view('layouts/footer') ?>

        </div>

    </div>
</div>


<!-- =========================================================
     CUSTOM CSS
     ========================================================= -->

<style>

.form-card {
    border-radius: 12px;
    overflow: hidden;
}

.card {
    border-radius: 12px;
}

.form-label {
    margin-bottom: 7px;
}

.form-control,
.form-select,
.input-group-text {
    min-height: 42px;
}

.input-group-text {
    background-color: #f8f9fa;
}

.form-control:focus,
.form-select:focus {
    border-color: #86b7fe;

    box-shadow:
        0 0 0 0.2rem rgba(13, 110, 253, 0.15);
}

textarea.form-control {
    min-height: 100px;
}

.btn {
    border-radius: 7px;
}

.alert {
    border-radius: 8px;
}

@media (max-width: 768px) {

    main {
        padding: 15px !important;
    }

    .card-header {
        padding: 14px !important;
    }

    .form-card .card-body {
        padding: 15px !important;
    }

}

</style>