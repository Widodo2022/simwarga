<?= view('layouts/header', [
    'title' => $title ?? 'Data Kartu Keluarga'
]) ?>

<div class="container-fluid">

    <div class="row">

        <!-- =====================================================
             SIDEBAR
             ===================================================== -->
        <div class="col-lg-2 d-none d-lg-block p-0">
            <?= view('layouts/sidebar') ?>
        </div>


        <!-- =====================================================
             CONTENT
             ===================================================== -->
        <div class="col-lg-10 content p-0">

            <?= view('layouts/navbar') ?>


            <main class="p-3 p-md-4">


                <!-- =================================================
                     HEADER HALAMAN
                     ================================================= -->
                <div class="d-flex flex-wrap justify-content-between
                            align-items-center mb-4">

                    <div>

                        <h3 class="fw-bold mb-1">

                            <i class="bi bi-house-door text-primary me-2"></i>

                            Data Kartu Keluarga

                        </h3>

                        <p class="text-muted mb-0">

                            Kelola data Kartu Keluarga warga
                            RT007 / RW023.

                        </p>

                    </div>


                    <div class="mt-3 mt-md-0">

                        <a href="<?= site_url('kartu-keluarga/create') ?>"
                           class="btn btn-primary shadow-sm">

                            <i class="bi bi-plus-circle me-1"></i>

                            Tambah KK

                        </a>

                    </div>

                </div>



                <!-- =================================================
                     STATISTIK
                     ================================================= -->
                <?php

                $totalKK = count($kk);

                $kkAktif = count(
                    array_filter(
                        $kk,
                        static fn ($item) =>
                            ($item['status'] ?? '') === 'aktif'
                    )
                );

                $kkNonaktif = count(
                    array_filter(
                        $kk,
                        static fn ($item) =>
                            ($item['status'] ?? '') === 'nonaktif'
                    )
                );

                ?>


                <div class="row g-3 mb-4">


                    <!-- TOTAL KK -->
                    <div class="col-md-4">

                        <div class="card stat-card border-0 shadow-sm h-100">

                            <div class="card-body">

                                <div class="d-flex align-items-center">

                                    <div class="stat-icon bg-primary-subtle
                                                text-primary">

                                        <i class="bi bi-house-door"></i>

                                    </div>


                                    <div>

                                        <div class="text-muted small">
                                            Total Kartu Keluarga
                                        </div>

                                        <div class="fs-4 fw-bold">
                                            <?= $totalKK ?>
                                        </div>

                                    </div>

                                </div>

                            </div>

                        </div>

                    </div>



                    <!-- KK AKTIF -->
                    <div class="col-md-4">

                        <div class="card stat-card border-0 shadow-sm h-100">

                            <div class="card-body">

                                <div class="d-flex align-items-center">

                                    <div class="stat-icon bg-success-subtle
                                                text-success">

                                        <i class="bi bi-check-circle"></i>

                                    </div>


                                    <div>

                                        <div class="text-muted small">
                                            KK Aktif
                                        </div>

                                        <div class="fs-4 fw-bold">
                                            <?= $kkAktif ?>
                                        </div>

                                    </div>

                                </div>

                            </div>

                        </div>

                    </div>



                    <!-- KK NONAKTIF -->
                    <div class="col-md-4">

                        <div class="card stat-card border-0 shadow-sm h-100">

                            <div class="card-body">

                                <div class="d-flex align-items-center">

                                    <div class="stat-icon bg-secondary-subtle
                                                text-secondary">

                                        <i class="bi bi-x-circle"></i>

                                    </div>


                                    <div>

                                        <div class="text-muted small">
                                            KK Nonaktif
                                        </div>

                                        <div class="fs-4 fw-bold">
                                            <?= $kkNonaktif ?>
                                        </div>

                                    </div>

                                </div>

                            </div>

                        </div>

                    </div>

                </div>



                <!-- =================================================
                     DATA TABLE CARD
                     ================================================= -->
                <div class="card border-0 shadow-sm table-card">


                    <!-- =================================================
                         CARD HEADER
                         ================================================= -->
                    <div class="card-header bg-primary text-white py-3">

                        <div class="d-flex flex-wrap
                                    justify-content-between
                                    align-items-center">

                            <div>

                                <h5 class="mb-0 fw-bold">

                                    <i class="bi bi-table me-2"></i>

                                    Daftar Kartu Keluarga

                                </h5>

                                <small class="opacity-75">

                                    Data KK terdaftar dalam sistem

                                </small>

                            </div>


                            <span class="badge bg-white text-primary
                                         mt-2 mt-md-0">

                                <?= $totalKK ?> Data

                            </span>

                        </div>

                    </div>



                    <!-- =================================================
                         TABLE BODY
                         ================================================= -->
                    <div class="card-body">


                        <div class="table-responsive">


                            <table id="tableKK"
                                   class="table table-hover align-middle w-100">


                                <!-- =================================================
                                     THEAD
                                     ================================================= -->
                                <thead>

                                    <tr>

                                        <th class="text-center col-no">
                                            No
                                        </th>

                                        <th class="text-center col-kk">
                                            No. KK
                                        </th>

                                        <th class="col-kepala">
                                            Kepala Keluarga
                                        </th>

                                        <th class="text-center col-wilayah">
                                            Kode Wilayah
                                        </th>

                                        <th class="col-alamat">
                                            Alamat
                                        </th>

                                        <th class="col-catatan">
                                            Catatan
                                        </th>

                                        <th class="text-center col-status">
                                            Status
                                        </th>

                                        <th class="text-center col-aksi">
                                            Aksi
                                        </th>

                                    </tr>

                                </thead>



                                <!-- =================================================
                                     TBODY
                                     ================================================= -->
                                <tbody>


                                <?php foreach ($kk as $i => $item): ?>


                                    <tr>


                                        <!-- =============================
                                             NOMOR
                                             ============================= -->
                                        <td class="text-center">

                                            <?= $i + 1 ?>

                                        </td>



                                        <!-- =============================
                                             NO KK
                                             ============================= -->
                                        <td class="text-center">

                                            <span class="no-kk">

                                                <?= esc($item['no_kk']) ?>

                                            </span>

                                        </td>



                                        <!-- =============================
                                             KEPALA KELUARGA
                                             ============================= -->
                                        <td>

                                            <div class="d-flex align-items-center">


                                                <div class="avatar-icon">

                                                    <i class="bi bi-person"></i>

                                                </div>


                                                <span class="nama-kepala">

                                                    <?= esc(
                                                        $item['kepala_keluarga']
                                                    ) ?>

                                                </span>


                                            </div>

                                        </td>



                                        <!-- =============================
                                             KODE WILAYAH
                                             ============================= -->
                                        <td class="text-center">

                                            <?php if (
                                                ! empty($item['kode_wilayah'])
                                            ): ?>


                                                <span class="wilayah-badge">

                                                    <i class="bi bi-geo-alt me-1"></i>

                                                    <?= esc(
                                                        $item['kode_wilayah']
                                                    ) ?>

                                                </span>


                                            <?php else: ?>


                                                <span class="text-muted">
                                                    -
                                                </span>


                                            <?php endif; ?>

                                        </td>



                                        <!-- =============================
                                             ALAMAT
                                             ============================= -->
                                        <td>

                                            <?php if (
                                                ! empty($item['alamat'])
                                            ): ?>

                                                <span class="alamat-text">

                                                    <?= esc($item['alamat']) ?>

                                                </span>

                                            <?php else: ?>

                                                <span class="text-muted">
                                                    -
                                                </span>

                                            <?php endif; ?>

                                        </td>



                                        <!-- =============================
                                             CATATAN
                                             ============================= -->
                                        <td>

                                            <?php if (
                                                ! empty($item['catatan'])
                                            ): ?>

                                                <span class="catatan-text">

                                                    <?= esc($item['catatan']) ?>

                                                </span>

                                            <?php else: ?>

                                                <span class="text-muted">
                                                    -
                                                </span>

                                            <?php endif; ?>

                                        </td>



                                        <!-- =============================
                                             STATUS
                                             ============================= -->
                                        <td class="text-center">


                                            <?php if (
                                                ($item['status'] ?? '') === 'aktif'
                                            ): ?>


                                                <span class="badge rounded-pill
                                                             bg-success status-badge">

                                                    <i class="bi bi-check-circle me-1"></i>

                                                    Aktif

                                                </span>


                                            <?php else: ?>


                                                <span class="badge rounded-pill
                                                             bg-secondary status-badge">

                                                    <i class="bi bi-x-circle me-1"></i>

                                                    Nonaktif

                                                </span>


                                            <?php endif; ?>


                                        </td>



                                        <!-- =============================
                                             AKSI
                                             ============================= -->
                                        <td class="text-center">


                                            <div class="btn-group"
                                                 role="group"
                                                 aria-label="Aksi KK">


                                                <!-- DETAIL -->
                                                <a href="<?= site_url(
                                                    'kartu-keluarga/detail/' .
                                                    $item['id']
                                                ) ?>"
                                                   class="btn btn-sm btn-outline-info"
                                                   data-bs-toggle="tooltip"
                                                   data-bs-placement="top"
                                                   title="Lihat Detail">

                                                    <i class="bi bi-eye"></i>

                                                </a>



                                                <!-- EDIT -->
                                                <a href="<?= site_url(
                                                    'kartu-keluarga/edit/' .
                                                    $item['id']
                                                ) ?>"
                                                   class="btn btn-sm btn-outline-primary"
                                                   data-bs-toggle="tooltip"
                                                   data-bs-placement="top"
                                                   title="Edit Data">

                                                    <i class="bi bi-pencil"></i>

                                                </a>



                                                <?php if (
                                                    ($item['status'] ?? '') === 'aktif'
                                                ): ?>


                                                    <!-- NONAKTIFKAN -->
                                                    <button
                                                        type="button"
                                                        class="btn btn-sm btn-outline-danger btn-nonaktifkan-kk"
                                                        data-id="<?= (int) $item['id'] ?>"
                                                        data-no-kk="<?= esc($item['no_kk'], 'attr') ?>"
                                                        data-bs-toggle="tooltip"
                                                        data-bs-placement="top"
                                                        title="Nonaktifkan">

                                                        <i class="bi bi-x-circle"></i>

                                                    </button>


                                                <?php endif; ?>


                                            </div>



                                            <!-- FORM DELETE -->
                                            <form
                                                id="delete-form-<?= (int) $item['id'] ?>"
                                                action="<?= site_url(
                                                    'kartu-keluarga/delete/' .
                                                    $item['id']
                                                ) ?>"
                                                method="post"
                                                class="d-none">

                                                <?= csrf_field() ?>

                                            </form>


                                        </td>


                                    </tr>


                                <?php endforeach; ?>


                                </tbody>

                            </table>

                        </div>

                    </div>

                </div>


            </main>



            <?= view('layouts/footer') ?>

        </div>

    </div>

</div>



<!-- =========================================================
     DATATABLES CSS
     ========================================================= -->

<link rel="stylesheet"
      href="https://cdn.datatables.net/2.3.3/css/dataTables.bootstrap5.min.css">

<link rel="stylesheet"
      href="https://cdn.datatables.net/responsive/3.0.5/css/responsive.bootstrap5.min.css">

<link rel="stylesheet"
      href="https://cdn.datatables.net/buttons/3.2.5/css/buttons.bootstrap5.min.css">



<!-- =========================================================
     CUSTOM CSS
     ========================================================= -->

<style>

/* =========================================================
   CARD
   ========================================================= */

.table-card {
    border-radius: 12px;
    overflow: hidden;
}

.card {
    border-radius: 12px;
}


/* =========================================================
   STAT CARD
   ========================================================= */

.stat-card {
    transition: all 0.2s ease;
}

.stat-card:hover {
    transform: translateY(-2px);
}

.stat-icon {
    width: 52px;
    height: 52px;

    border-radius: 50%;

    display: flex;
    align-items: center;
    justify-content: center;

    font-size: 23px;

    margin-right: 15px;
}


/* =========================================================
   TABLE
   ========================================================= */

#tableKK {
    width: 100% !important;
    border-collapse: collapse !important;
}


/* =========================================================
   HEADER
   ========================================================= */

#tableKK thead th {

    background-color: #f8f9fa !important;

    border-top: 1px solid #dee2e6 !important;

    border-bottom: 2px solid #adb5bd !important;

    border-left: 1px solid #dee2e6 !important;

    border-right: 1px solid #dee2e6 !important;

    font-weight: 600;

    white-space: nowrap;

    vertical-align: middle;

}


/* =========================================================
   BODY
   ========================================================= */

#tableKK tbody td {

    border-left: 1px solid #dee2e6 !important;

    border-right: 1px solid #dee2e6 !important;

    border-bottom: 1px solid #dee2e6 !important;

    vertical-align: middle;

}


/* =========================================================
   BARIS
   ========================================================= */

#tableKK tbody tr {

    border-bottom: 1px solid #dee2e6 !important;

}


/* =========================================================
   HOVER
   ========================================================= */

#tableKK tbody tr:hover {

    background-color: #f8f9fa !important;

}


/* =========================================================
   LEBAR KOLOM
   ========================================================= */

#tableKK .col-no {
    width: 55px !important;
    min-width: 55px !important;
}

#tableKK .col-kk {
    width: 175px !important;
    min-width: 175px !important;
}

#tableKK .col-kepala {
    min-width: 220px !important;
}

#tableKK .col-wilayah {
    width: 150px !important;
    min-width: 150px !important;
}

#tableKK .col-alamat {
    min-width: 180px !important;
}

#tableKK .col-catatan {
    min-width: 180px !important;
}

#tableKK .col-status {
    width: 110px !important;
    min-width: 110px !important;
}

#tableKK .col-aksi {
    width: 135px !important;
    min-width: 135px !important;
}


/* =========================================================
   NO KK
   ========================================================= */

.no-kk {

    display: inline-block;

    font-weight: 700;

    white-space: nowrap;

    letter-spacing: 0.2px;

}


/* =========================================================
   KEPALA KELUARGA
   ========================================================= */

.avatar-icon {

    width: 38px;
    height: 38px;

    min-width: 38px;

    border-radius: 50%;

    background-color: rgba(13, 110, 253, 0.10);

    color: #0d6efd;

    display: flex;

    align-items: center;

    justify-content: center;

    margin-right: 10px;

}


.nama-kepala {

    white-space: nowrap;

}


/* =========================================================
   KODE WILAYAH
   ========================================================= */

.wilayah-badge {

    display: inline-flex;

    align-items: center;

    justify-content: center;

    min-width: 65px;

    padding: 5px 9px;

    background-color: #f8f9fa;

    border: 1px solid #dee2e6;

    border-radius: 7px;

    font-size: 12px;

    font-weight: 600;

    color: #495057;

    white-space: nowrap;

}


/* =========================================================
   ALAMAT
   ========================================================= */

.alamat-text {

    display: inline-block;

    max-width: 300px;

    white-space: normal;

    word-break: break-word;

}


/* =========================================================
   CATATAN
   ========================================================= */

.catatan-text {

    display: block;

    min-width: 180px;

    max-width: 300px;

    white-space: normal;

    line-height: 1.5;

    word-break: break-word;

}


/* =========================================================
   STATUS
   ========================================================= */

.status-badge {

    min-width: 75px;

    padding: 6px 10px;

    font-weight: 500;

}


/* =========================================================
   BUTTON AKSI
   ========================================================= */

#tableKK .btn-group {

    display: inline-flex;

    vertical-align: middle;

}


#tableKK .btn {

    border-radius: 0;

}


#tableKK .btn:first-child {

    border-top-left-radius: 6px;

    border-bottom-left-radius: 6px;

}


#tableKK .btn:last-child {

    border-top-right-radius: 6px;

    border-bottom-right-radius: 6px;

}


/* =========================================================
   DATATABLES CONTAINER
   ========================================================= */

.dt-container {

    width: 100%;

}


/* =========================================================
   SHOW ENTRIES
   ========================================================= */

.dt-length {

    display: flex;

    align-items: center;

    gap: 6px;

    margin-bottom: 10px;

}


.dt-length label {

    margin: 0;

    white-space: nowrap;

    font-size: 14px;

}


.dt-length select {

    min-width: 60px;

    height: 34px;

    padding: 3px 25px 3px 8px;

    border: 1px solid #ced4da;

    border-radius: 6px;

    background-color: #fff;

}


/* =========================================================
   SEARCH
   ========================================================= */

.dt-search {

    display: flex;

    align-items: center;

    justify-content: flex-end;

    gap: 7px;

    margin-bottom: 10px;

}


.dt-search label {

    margin: 0;

    white-space: nowrap;

    font-size: 14px;

}


.dt-search input {

    min-width: 215px;

    height: 34px;

    border: 1px solid #adb5bd;

    border-radius: 6px;

    padding: 5px 10px;

}


.dt-search input:focus {

    border-color: #86b7fe;

    box-shadow: 0 0 0 0.2rem rgba(13, 110, 253, 0.15);

    outline: none;

}


/* =========================================================
   DATATABLE BUTTONS
   ========================================================= */

.dt-buttons {

    display: flex;

    flex-wrap: wrap;

    gap: 3px;

}


.dt-buttons .btn {

    margin: 0 !important;

    border-radius: 5px;

}


.dt-buttons .btn:hover {

    opacity: 0.9;

}


/* =========================================================
   PAGINATION
   ========================================================= */

.dt-paging {

    margin-top: 10px;

}


.dt-paging .pagination {

    margin-bottom: 0;

}


/* =========================================================
   INFO
   ========================================================= */

.dt-info {

    padding-top: 12px;

    font-size: 14px;

    color: #495057;

}


/* =========================================================
   TABLE RESPONSIVE
   ========================================================= */

.table-responsive {

    width: 100%;

    overflow-x: auto;

    -webkit-overflow-scrolling: touch;

}


/* =========================================================
   MOBILE
   ========================================================= */

@media (max-width: 768px) {

    main {

        padding: 15px !important;

    }


    .dt-search {

        justify-content: flex-start;

        width: 100%;

        margin-top: 8px;

    }


    .dt-search input {

        width: 100%;

        min-width: 0;

    }


    .dt-length {

        width: 100%;

    }


    .dt-buttons {

        width: 100%;

        margin-top: 8px;

    }


    .dt-buttons .btn {

        margin-bottom: 3px !important;

    }


    #tableKK {

        min-width: 1100px !important;

    }


    .card-header {

        padding: 14px !important;

    }


    .stat-icon {

        width: 45px;

        height: 45px;

        font-size: 19px;

    }

}


/* =========================================================
   VERY SMALL SCREEN
   ========================================================= */

@media (max-width: 480px) {

    .dt-length {

        justify-content: flex-start;

    }


    .dt-search {

        display: block;

    }


    .dt-search label {

        display: inline-block;

        margin-bottom: 5px;

    }


    .dt-search input {

        display: block;

        width: 100%;

    }

}

</style>



<!-- =========================================================
     JAVASCRIPT LIBRARIES
     ========================================================= -->

<!-- jQuery -->
<script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>

<!-- Bootstrap Bundle -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>

<!-- DataTables -->
<script src="https://cdn.datatables.net/2.3.3/js/dataTables.min.js"></script>

<script src="https://cdn.datatables.net/2.3.3/js/dataTables.bootstrap5.min.js"></script>

<!-- DataTables Responsive -->
<script src="https://cdn.datatables.net/responsive/3.0.5/js/dataTables.responsive.min.js"></script>

<script src="https://cdn.datatables.net/responsive/3.0.5/js/responsive.bootstrap5.min.js"></script>

<!-- DataTables Buttons -->
<script src="https://cdn.datatables.net/buttons/3.2.5/js/dataTables.buttons.min.js"></script>

<script src="https://cdn.datatables.net/buttons/3.2.5/js/buttons.bootstrap5.min.js"></script>

<script src="https://cdnjs.cloudflare.com/ajax/libs/jszip/3.10.1/jszip.min.js"></script>

<script src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.2.20/pdfmake.min.js"></script>

<script src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.2.20/vfs_fonts.js"></script>

<script src="https://cdn.datatables.net/buttons/3.2.5/js/buttons.html5.min.js"></script>

<script src="https://cdn.datatables.net/buttons/3.2.5/js/buttons.print.min.js"></script>

<script src="https://cdn.datatables.net/buttons/3.2.5/js/buttons.colVis.min.js"></script>

<!-- SweetAlert2 -->
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>



<script>

document.addEventListener('DOMContentLoaded', function () {


    /* =========================================================
       DATATABLE
       ========================================================= */

    const table = new DataTable('#tableKK', {

        /* -------------------------------------------------
           RESPONSIVE
           ------------------------------------------------- */

        responsive: true,


        /* -------------------------------------------------
           DEFAULT DATA PER PAGE
           ------------------------------------------------- */

        pageLength: 10,


        /* -------------------------------------------------
           MENU JUMLAH DATA
           ------------------------------------------------- */

        lengthMenu: [
            [10, 25, 50, 100, -1],
            [10, 25, 50, 100, 'Semua']
        ],


        /* -------------------------------------------------
           DEFAULT SORTING
           No KK
           ------------------------------------------------- */

        order: [
            [1, 'asc']
        ],


        /* -------------------------------------------------
           LAYOUT
           ------------------------------------------------- */

        layout: {

            /* =============================================
               BARIS ATAS KIRI
               SHOW ENTRIES
               ============================================= */

            topStart: {

                pageLength: {
                    menu: [10, 25, 50, 100, -1]
                }

            },


            /* =============================================
               BARIS ATAS KANAN
               SEARCH
               ============================================= */

            topEnd: {

                search: {
                    placeholder: 'Cari data KK...'
                }

            },


            /* =============================================
               BAWAH
               BUTTON EXPORT
               ============================================= */

            bottomStart: {

                buttons: [

                    /* COPY */
                    {
                        extend: 'copy',
                        text: '<i class="bi bi-copy me-1"></i> Copy',
                        className: 'btn btn-secondary btn-sm'
                    },


                    /* CSV */
                    {
                        extend: 'csv',
                        text: '<i class="bi bi-filetype-csv me-1"></i> CSV',
                        className: 'btn btn-secondary btn-sm'
                    },


                    /* EXCEL */
                    {
                        extend: 'excel',
                        text: '<i class="bi bi-file-earmark-excel me-1"></i> Excel',
                        className: 'btn btn-success btn-sm'
                    },


                    /* PDF */
                    {
                        extend: 'pdf',
                        text: '<i class="bi bi-file-earmark-pdf me-1"></i> PDF',
                        className: 'btn btn-danger btn-sm',
                        title: 'Data Kartu Keluarga',
                        filename: 'data-kartu-keluarga',
                        orientation: 'landscape',
                        pageSize: 'A4'
                    },


                    /* PRINT */
                    {
                        extend: 'print',
                        text: '<i class="bi bi-printer me-1"></i> Print',
                        className: 'btn btn-secondary btn-sm'
                    },


                    /* COLUMN VISIBILITY */
                    {
                        extend: 'colvis',
                        text: '<i class="bi bi-layout-three-columns me-1"></i> Kolom',
                        className: 'btn btn-secondary btn-sm'
                    }

                ]

            },


            /* =============================================
               PAGINATION
               ============================================= */

            bottomEnd: 'paging'

        },


        /* -------------------------------------------------
           BAHASA
           ------------------------------------------------- */

        language: {

            processing: 'Memproses...',

            search: 'Cari:',

            lengthMenu: 'Show _MENU_ entries',

            info: 'Menampilkan _START_ sampai _END_ dari _TOTAL_ data',

            infoEmpty: 'Tidak ada data',

            infoFiltered: '(disaring dari _MAX_ total data)',

            zeroRecords: 'Data tidak ditemukan',

            emptyTable: 'Belum ada data Kartu Keluarga',

            paginate: {

                first: 'Pertama',

                last: 'Terakhir',

                next: '›',

                previous: '‹'

            },

            buttons: {

                copy: 'Copy',

                colvis: 'Visibilitas Kolom'

            }

        },


        /* -------------------------------------------------
           COLUMN SETTINGS
           ------------------------------------------------- */

        columnDefs: [

            /* No */
            {
                targets: 0,
                searchable: false,
                orderable: false
            },


            /* Aksi */
            {
                targets: 7,
                searchable: false,
                orderable: false
            }

        ]

    });



    /* =========================================================
       BOOTSTRAP TOOLTIP
       ========================================================= */

    if (typeof bootstrap !== 'undefined') {

        const tooltipTriggerList =
            document.querySelectorAll(
                '[data-bs-toggle="tooltip"]'
            );

        tooltipTriggerList.forEach(function (tooltipTriggerEl) {

            new bootstrap.Tooltip(tooltipTriggerEl);

        });

    }



    /* =========================================================
       TOMBOL NONAKTIFKAN KK
       ========================================================= */

    document
        .querySelectorAll('.btn-nonaktifkan-kk')
        .forEach(function (button) {


            button.addEventListener('click', function () {


                const id =
                    this.getAttribute('data-id');


                const noKK =
                    this.getAttribute('data-no-kk');


                if (typeof Swal === 'undefined') {

                    alert(
                        'Apakah Anda yakin ingin menonaktifkan KK ' +
                        noKK +
                        '?'
                    );

                    const form =
                        document.getElementById(
                            'delete-form-' + id
                        );

                    if (form) {

                        form.submit();

                    }

                    return;

                }


                Swal.fire({

                    title: 'Nonaktifkan KK?',

                    html:
                        'Kartu Keluarga<br>' +
                        '<strong>' +
                        noKK +
                        '</strong>' +
                        '<br><br>' +
                        'Data tidak akan dihapus secara permanen.',

                    icon: 'warning',

                    showCancelButton: true,

                    confirmButtonColor: '#dc3545',

                    cancelButtonColor: '#6c757d',

                    confirmButtonText:
                        '<i class="bi bi-x-circle"></i> Ya, Nonaktifkan',

                    cancelButtonText:
                        'Batal',

                    reverseButtons: true

                }).then(function (result) {


                    if (result.isConfirmed) {


                        const form =
                            document.getElementById(
                                'delete-form-' + id
                            );


                        if (form) {

                            form.submit();

                        } else {

                            Swal.fire({

                                icon: 'error',

                                title: 'Gagal',

                                text:
                                    'Form nonaktifkan KK tidak ditemukan.'

                            });

                        }

                    }

                });

            });

        });



    /* =========================================================
       SWEETALERT SUCCESS
       ========================================================= */

    <?php if (session()->getFlashdata('success')): ?>

        Swal.fire({

            icon: 'success',

            title: 'Berhasil',

            text:
                <?= json_encode(
                    session()->getFlashdata('success')
                ) ?>,

            confirmButtonText: 'OK',

            timer: 2500,

            timerProgressBar: true

        });

    <?php endif; ?>



    /* =========================================================
       SWEETALERT ERROR
       ========================================================= */

    <?php if (session()->getFlashdata('error')): ?>

        Swal.fire({

            icon: 'error',

            title: 'Gagal',

            text:
                <?= json_encode(
                    session()->getFlashdata('error')
                ) ?>,

            confirmButtonText: 'OK'

        });

    <?php endif; ?>


});

</script>