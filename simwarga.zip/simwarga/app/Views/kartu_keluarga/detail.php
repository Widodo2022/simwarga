<?= view('layouts/header', [
    'title' => $title ?? 'Detail Kartu Keluarga'
]) ?>

<div class="container-fluid">

    <div class="row">

        <!-- SIDEBAR -->
        <div class="col-lg-2 d-none d-lg-block p-0">
            <?= view('layouts/sidebar') ?>
        </div>

        <!-- CONTENT -->
        <div class="col-lg-10 content p-0">

            <?= view('layouts/navbar') ?>

            <main class="p-4">

                <!-- HEADER -->
                <div class="d-flex flex-wrap justify-content-between align-items-center mb-4">

                    <div>

                        <h3 class="fw-bold mb-1">
                            <i class="bi bi-house-door text-primary me-2"></i>
                            Detail Kartu Keluarga
                        </h3>

                        <p class="text-muted mb-0">
                            Informasi lengkap Kartu Keluarga dan anggota keluarga.
                        </p>

                    </div>

                    <div class="mt-3 mt-md-0">

                        <a href="<?= site_url('kartu-keluarga') ?>"
                           class="btn btn-secondary shadow-sm">

                            <i class="bi bi-arrow-left me-1"></i>
                            Kembali

                        </a>

                        <a href="<?= site_url('kartu-keluarga/edit/' . $kk['id']) ?>"
                           class="btn btn-primary shadow-sm">

                            <i class="bi bi-pencil me-1"></i>
                            Edit KK

                        </a>

                    </div>

                </div>


                <!-- ===================================================== -->
                <!-- INFORMASI KK -->
                <!-- ===================================================== -->

                <div class="card border-0 shadow-sm mb-4">

                    <div class="card-header bg-primary text-white py-3">

                        <div class="d-flex justify-content-between align-items-center">

                            <div>

                                <h5 class="mb-0 fw-bold">

                                    <i class="bi bi-card-heading me-2"></i>
                                    Informasi Kartu Keluarga

                                </h5>

                                <small class="opacity-75">
                                    Data identitas Kartu Keluarga
                                </small>

                            </div>

                            <?php if (($kk['status'] ?? '') === 'aktif'): ?>

                                <span class="badge bg-success rounded-pill px-3 py-2">

                                    <i class="bi bi-check-circle me-1"></i>
                                    Aktif

                                </span>

                            <?php else: ?>

                                <span class="badge bg-secondary rounded-pill px-3 py-2">

                                    <i class="bi bi-x-circle me-1"></i>
                                    Nonaktif

                                </span>

                            <?php endif; ?>

                        </div>

                    </div>


                    <div class="card-body">

                        <div class="row g-4">

                            <!-- NO KK -->
                            <div class="col-md-6">

                                <div class="info-label">
                                    <i class="bi bi-credit-card-2-front me-1"></i>
                                    Nomor Kartu Keluarga
                                </div>

                                <div class="info-value kk-number">

                                    <?= esc($kk['no_kk']) ?>

                                </div>

                            </div>


                            <!-- KEPALA KELUARGA -->
                            <div class="col-md-6">

                                <div class="info-label">
                                    <i class="bi bi-person me-1"></i>
                                    Kepala Keluarga
                                </div>

                                <div class="info-value">

                                    <?= esc($kk['kepala_keluarga']) ?>

                                </div>

                            </div>


                            <!-- KODE WILAYAH -->
                            <div class="col-md-6">

                                <div class="info-label">
                                    <i class="bi bi-geo-alt me-1"></i>
                                    Kode Wilayah
                                </div>

                                <div class="info-value">

                                    <?php if (! empty($kk['kode_wilayah'])): ?>

                                        <span class="badge bg-light text-dark border px-3 py-2">

                                            <i class="bi bi-geo-alt me-1 text-primary"></i>

                                            <?= esc($kk['kode_wilayah']) ?>

                                        </span>

                                    <?php else: ?>

                                        <span class="text-muted">
                                            -
                                        </span>

                                    <?php endif; ?>

                                </div>

                            </div>


                            <!-- ALAMAT -->
                            <div class="col-md-6">

                                <div class="info-label">
                                    <i class="bi bi-house me-1"></i>
                                    Alamat
                                </div>

                                <div class="info-value">

                                    <?php if (! empty($kk['alamat'])): ?>

                                        <?= esc($kk['alamat']) ?>

                                    <?php else: ?>

                                        <span class="text-muted">
                                            -
                                        </span>

                                    <?php endif; ?>

                                </div>

                            </div>

                      
                <!-- CATATAN -->
                <div class="col-md-6">

                    <div class="info-label">
                        <i class="bi bi-sticky me-1"></i>
                        Catatan
                    </div>

                    <div class="info-value">

                        <?php if (! empty($kk['catatan'])): ?>

                            <?= esc($kk['catatan']) ?>

                        <?php else: ?>

                            <span class="text-muted">
                                -
                            </span>

                        <?php endif; ?>

                    </div>

                </div>

            </div>
                
                <!-- ===================================================== -->
                <!-- STATISTIK ANGGOTA -->
                <!-- ===================================================== -->

                <div class="row g-3 mb-4">

                    <div class="col-md-4">

                        <div class="card border-0 shadow-sm h-100">

                            <div class="card-body">

                                <div class="d-flex align-items-center">

                                    <div class="icon-box bg-primary bg-opacity-10 text-primary">

                                        <i class="bi bi-people fs-4"></i>

                                    </div>

                                    <div>

                                        <div class="text-muted small">
                                            Total Anggota
                                        </div>

                                        <div class="fs-4 fw-bold">
                                            <?= count($anggota) ?>
                                        </div>

                                    </div>

                                </div>

                            </div>

                        </div>

                    </div>


                    <div class="col-md-4">

                        <div class="card border-0 shadow-sm h-100">

                            <div class="card-body">

                                <div class="d-flex align-items-center">

                                    <div class="icon-box bg-success bg-opacity-10 text-success">

                                        <i class="bi bi-gender-male fs-4"></i>

                                    </div>

                                    <div>

                                        <div class="text-muted small">
                                            Laki-laki
                                        </div>

                                        <div class="fs-4 fw-bold">

                                            <?php
                                            $jumlahLaki = count(
                                                array_filter(
                                                    $anggota,
                                                    static fn ($item) =>
                                                        ($item['jenis_kelamin'] ?? '') === 'L'
                                                )
                                            );
                                            ?>

                                            <?= $jumlahLaki ?>

                                        </div>

                                    </div>

                                </div>

                            </div>

                        </div>

                    </div>


                    <div class="col-md-4">

                        <div class="card border-0 shadow-sm h-100">

                            <div class="card-body">

                                <div class="d-flex align-items-center">

                                    <div class="icon-box bg-danger bg-opacity-10 text-danger">

                                        <i class="bi bi-gender-female fs-4"></i>

                                    </div>

                                    <div>

                                        <div class="text-muted small">
                                            Perempuan
                                        </div>

                                        <div class="fs-4 fw-bold">

                                            <?php
                                            $jumlahPerempuan = count(
                                                array_filter(
                                                    $anggota,
                                                    static fn ($item) =>
                                                        ($item['jenis_kelamin'] ?? '') === 'P'
                                                )
                                            );
                                            ?>

                                            <?= $jumlahPerempuan ?>

                                        </div>

                                    </div>

                                </div>

                            </div>

                        </div>

                    </div>

                </div>


                <!-- ===================================================== -->
                <!-- DAFTAR ANGGOTA KELUARGA -->
                <!-- ===================================================== -->

                <div class="card border-0 shadow-sm">

                    <!-- HEADER -->
                    <div class="card-header bg-primary text-white py-3">

                        <div class="d-flex justify-content-between align-items-center">

                            <div>

                                <h5 class="mb-0 fw-bold">

                                    <i class="bi bi-people me-2"></i>
                                    Anggota Keluarga

                                </h5>

                                <small class="opacity-75">
                                    Daftar anggota keluarga berdasarkan Nomor KK
                                </small>

                            </div>

                            <div class="d-flex align-items-center gap-2">

    <span class="badge bg-white text-primary">
        <?= count($anggota) ?> Anggota
    </span>

    <a href="<?= site_url('warga/create?no_kk=' . urlencode($kk['no_kk'])) ?>"
       class="btn btn-light btn-sm shadow-sm">

        <i class="bi bi-person-plus me-1"></i>
        Tambah Anggota

    </a>

</div>

                        </div>

                    </div>


                    <!-- TABLE -->
                    <div class="card-body">

                        <div class="table-responsive">

                            <table class="table table-bordered table-hover align-middle w-100">

                                <thead class="table-light">

                                    <tr>

                                        <th class="text-center" style="width: 60px;">
                                            No
                                        </th>

                                        <th style="min-width: 150px;">
                                            NIK
                                        </th>

                                        <th style="min-width: 220px;">
                                            Nama Lengkap
                                        </th>

                                        <th class="text-center" style="width: 120px;">
                                            Jenis Kelamin
                                        </th>

                                        <th style="min-width: 160px;">
                                            Tempat, Tanggal Lahir
                                        </th>

                                        <th style="min-width: 130px;">
                                            Agama
                                        </th>

                                        <th style="min-width: 150px;">
                                            Pendidikan
                                        </th>

                                        <th style="min-width: 150px;">
                                            Pekerjaan
                                        </th>

                                        <th style="min-width: 150px;">
                                            Hubungan
                                        </th>

                                    </tr>

                                </thead>


                                <tbody>

                                <?php if (! empty($anggota)): ?>

                                    <?php foreach ($anggota as $i => $item): ?>

                                        <tr>

                                            <!-- NO -->
                                            <td class="text-center">

                                                <?= $i + 1 ?>

                                            </td>


                                            <!-- NIK -->
                                            <td>

                                                <span class="fw-semibold text-nowrap">

                                                    <?= esc($item['nik']) ?>

                                                </span>

                                            </td>


                                            <!-- NAMA -->
                                            <td>

                                                <div class="d-flex align-items-center">

                                                    <div class="member-icon me-2">

                                                        <i class="bi bi-person"></i>

                                                    </div>

                                                    <span class="fw-semibold">

                                                        <?= esc($item['nama_lengkap']) ?>

                                                    </span>

                                                </div>

                                            </td>


                                            <!-- JENIS KELAMIN -->
                                            <td class="text-center">

                                                <?php if (($item['jenis_kelamin'] ?? '') === 'L'): ?>

                                                    <span class="badge bg-primary-subtle text-primary border">

                                                        <i class="bi bi-gender-male me-1"></i>
                                                        Laki-laki

                                                    </span>

                                                <?php else: ?>

                                                    <span class="badge bg-danger-subtle text-danger border">

                                                        <i class="bi bi-gender-female me-1"></i>
                                                        Perempuan

                                                    </span>

                                                <?php endif; ?>

                                            </td>


                                            <!-- TEMPAT TANGGAL LAHIR -->
                                            <td>

                                                <?php

                                                $tempatLahir = trim(
                                                    (string) ($item['tempat_lahir'] ?? '')
                                                );

                                                $tanggalLahir = $item['tanggal_lahir'] ?? '';

                                                ?>

                                                <?php if ($tempatLahir || $tanggalLahir): ?>

                                                    <?= esc($tempatLahir ?: '-') ?>

                                                    <?php if ($tanggalLahir): ?>

                                                        <br>

                                                        <small class="text-muted">

                                                            <?= date(
                                                                'd-m-Y',
                                                                strtotime($tanggalLahir)
                                                            ) ?>

                                                        </small>

                                                    <?php endif; ?>

                                                <?php else: ?>

                                                    <span class="text-muted">
                                                        -
                                                    </span>

                                                <?php endif; ?>

                                            </td>


                                            <!-- AGAMA -->
                                            <td>

                                                <?= ! empty($item['agama'])
                                                    ? esc($item['agama'])
                                                    : '<span class="text-muted">-</span>' ?>

                                            </td>


                                            <!-- PENDIDIKAN -->
                                            <td>

                                                <?= ! empty($item['pendidikan'])
                                                    ? esc($item['pendidikan'])
                                                    : '<span class="text-muted">-</span>' ?>

                                            </td>


                                            <!-- PEKERJAAN -->
                                            <td>

                                                <?= ! empty($item['pekerjaan'])
                                                    ? esc($item['pekerjaan'])
                                                    : '<span class="text-muted">-</span>' ?>

                                            </td>


                                            <!-- HUBUNGAN -->
                                            <td>

                                                <?php
                                                $hubungan = [
                                                    'KEPALA_KELUARGA' => 'Kepala Keluarga',
                                                    'ISTRI'           => 'Istri',
                                                    'ANAK'            => 'Anak',
                                                    'ORANG_TUA'       => 'Orang Tua',
                                                    'FAMILI_LAIN'     => 'Famili Lain',
                                                    'LAINNYA'         => 'Lainnya',
                                                ];

                                                $labelHubungan =
                                                    $hubungan[$item['hubungan_keluarga'] ?? '']
                                                    ?? '-';
                                                ?>

                                                <span class="badge bg-light text-dark border">

                                                    <?= esc($labelHubungan) ?>

                                                </span>

                                            </td>

                                        </tr>

                                    <?php endforeach; ?>

                                <?php else: ?>

                                    <tr>

                                        <td colspan="9"
                                            class="text-center py-5">

                                            <div class="text-muted">

                                                <i class="bi bi-people fs-1 d-block mb-3"></i>

                                                <h6 class="fw-bold">
                                                    Belum ada anggota keluarga
                                                </h6>

                                                <p class="mb-0">
                                                    Belum terdapat data warga dengan Nomor KK ini.
                                                </p>

                                            </div>

                                        </td>

                                    </tr>

                                <?php endif; ?>

                                </tbody>

                            </table>

                        </div>

                    </div>

                </div>

            </main>


            <?= view('layouts/footer') ?>

        </div>

    </div>

</div>


<!-- ===================================================== -->
<!-- CSS DETAIL KK -->
<!-- ===================================================== -->

<style>

    .card {
        border-radius: 12px;
        overflow: hidden;
    }

    .card-header {
        border-bottom: 0;
    }

    .info-label {
        color: #6c757d;
        font-size: 0.85rem;
        font-weight: 600;
        margin-bottom: 6px;
    }

    .info-value {
        font-size: 1rem;
        font-weight: 600;
        color: #212529;
    }

    .kk-number {
        letter-spacing: 1px;
        font-size: 1.15rem;
    }

    .icon-box {
        width: 52px;
        height: 52px;
        border-radius: 50%;
        display: flex;
        align-items: center;
        justify-content: center;
        margin-right: 15px;
        flex-shrink: 0;
    }

    .member-icon {
        width: 38px;
        height: 38px;
        border-radius: 50%;
        background: rgba(13, 110, 253, 0.10);
        color: #0d6efd;
        display: flex;
        align-items: center;
        justify-content: center;
        flex-shrink: 0;
    }

    .table {
        margin-bottom: 0;
    }

    .table thead th {
        vertical-align: middle;
        white-space: nowrap;
        font-weight: 600;
        background: #f8f9fa;
        border-bottom: 2px solid #adb5bd;
    }

    .table tbody td {
        vertical-align: middle;
        border-color: #dee2e6;
    }

    .table tbody tr:hover {
        background-color: #f8f9fa;
    }

    .badge {
        font-weight: 500;
    }

    .btn {
        border-radius: 8px;
    }

    @media (max-width: 768px) {

        main {
            padding: 1rem !important;
        }

        .info-value {
            font-size: 0.95rem;
        }

        .kk-number {
            font-size: 1rem;
        }

        .card-header h5 {
            font-size: 1rem;
        }

    }

</style>