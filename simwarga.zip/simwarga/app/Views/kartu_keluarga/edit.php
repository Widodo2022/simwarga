<?= view('layouts/header', [
    'title' => $title ?? 'Edit Kartu Keluarga'
]) ?>

<div class="container-fluid">

    <div class="row">

        <!-- =====================================================
             SIDEBAR
             ===================================================== -->
        <div class="col-lg-2 d-none d-lg-block p-0">
            <?= view('layouts/sidebar') ?>
        </div>


        <!-- =====================================================
             CONTENT
             ===================================================== -->
        <div class="col-lg-10 content p-0">

            <?= view('layouts/navbar') ?>


            <main class="p-3 p-md-4">

                <!-- =================================================
                     HEADER
                     ================================================= -->
                <div class="mb-4">

                    <a href="<?= site_url('kartu-keluarga') ?>"
                       class="text-decoration-none">

                        <i class="bi bi-arrow-left me-1"></i>
                        Kembali ke Data KK

                    </a>


                    <h3 class="fw-bold mt-3 mb-1">

                        <i class="bi bi-pencil-square text-primary me-2"></i>

                        Edit Kartu Keluarga

                    </h3>


                    <p class="text-muted mb-0">

                        Perbarui data Kartu Keluarga dan Kepala Keluarga.

                    </p>

                </div>



                <!-- =================================================
                     ERROR VALIDATION
                     ================================================= -->
                <?php $errors = session()->getFlashdata('errors'); ?>

                <?php if (! empty($errors)): ?>

                    <div class="alert alert-danger shadow-sm">

                        <div class="fw-bold mb-2">

                            <i class="bi bi-exclamation-triangle me-1"></i>

                            Periksa data berikut:

                        </div>


                        <ul class="mb-0">

                            <?php foreach ($errors as $error): ?>

                                <li>
                                    <?= esc($error) ?>
                                </li>

                            <?php endforeach; ?>

                        </ul>

                    </div>

                <?php endif; ?>



                <!-- =================================================
                     FORM KK
                     ================================================= -->
                <div class="card border-0 shadow-sm mb-4">

                    <div class="card-header bg-primary text-white py-3">

                        <h5 class="mb-0 fw-bold">

                            <i class="bi bi-house-door me-2"></i>

                            Informasi Kartu Keluarga

                        </h5>

                    </div>


                    <div class="card-body p-4">

                        <form
                            action="<?= site_url('kartu-keluarga/update/' . $kk['id']) ?>"
                            method="post"
                        >

                            <?= csrf_field() ?>


                            <div class="row g-3">


                                <!-- =================================================
                                     NO KK
                                     ================================================= -->
                                <div class="col-md-6">

                                    <label
                                        for="no_kk"
                                        class="form-label fw-semibold"
                                    >

                                        Nomor Kartu Keluarga

                                        <span class="text-danger">*</span>

                                    </label>


                                    <input
                                        type="text"
                                        class="form-control"
                                        id="no_kk"
                                        name="no_kk"
                                        value="<?= old(
                                            'no_kk',
                                            $kk['no_kk'] ?? ''
                                        ) ?>"
                                        maxlength="16"
                                        minlength="16"
                                        inputmode="numeric"
                                        placeholder="Masukkan 16 digit nomor KK"
                                        required
                                    >


                                    <div class="form-text">

                                        Nomor KK harus terdiri dari 16 digit.

                                    </div>

                                </div>



                                <!-- =================================================
                                     KEPALA KELUARGA
                                     ================================================= -->
                                <div class="col-md-6">

                                    <label
                                        for="kepala_keluarga"
                                        class="form-label fw-semibold"
                                    >

                                        Kepala Keluarga

                                        <span class="text-danger">*</span>

                                    </label>


                                    <input
                                        type="text"
                                        class="form-control"
                                        id="kepala_keluarga"
                                        name="kepala_keluarga"
                                        value="<?= old(
                                            'kepala_keluarga',
                                            $kk['kepala_keluarga'] ?? ''
                                        ) ?>"
                                        maxlength="150"
                                        placeholder="Nama kepala keluarga"
                                        required
                                    >

                                </div>



                                <!-- =================================================
                                     KODE WILAYAH
                                     ================================================= -->
                                <div class="col-md-6">

                                    <label
                                        for="kode_wilayah"
                                        class="form-label fw-semibold"
                                    >

                                        Kode Wilayah

                                    </label>


                                    <input
                                        type="text"
                                        class="form-control"
                                        id="kode_wilayah"
                                        name="kode_wilayah"
                                        value="<?= old(
                                            'kode_wilayah',
                                            $kk['kode_wilayah'] ?? ''
                                        ) ?>"
                                        maxlength="50"
                                        placeholder="Contoh: 32.01.01.1001"
                                    >

                                </div>



                                <!-- =================================================
                                     STATUS KK
                                     ================================================= -->
                                <div class="col-md-6">

                                    <label
                                        for="status"
                                        class="form-label fw-semibold"
                                    >

                                        Status Kartu Keluarga

                                    </label>


                                    <select
                                        class="form-select"
                                        id="status"
                                        name="status"
                                    >

                                        <option
                                            value="aktif"
                                            <?= old(
                                                'status',
                                                $kk['status'] ?? 'aktif'
                                            ) === 'aktif'
                                                ? 'selected'
                                                : ''
                                            ?>
                                        >
                                            Aktif
                                        </option>


                                        <option
                                            value="nonaktif"
                                            <?= old(
                                                'status',
                                                $kk['status'] ?? ''
                                            ) === 'nonaktif'
                                                ? 'selected'
                                                : ''
                                            ?>
                                        >
                                            Nonaktif
                                        </option>

                                    </select>

                                </div>



                                <!-- =================================================
                                     ALAMAT
                                     ================================================= -->
                                <div class="col-12">

                                    <label
                                        for="alamat"
                                        class="form-label fw-semibold"
                                    >

                                        Alamat

                                    </label>


                                    <textarea
                                        class="form-control"
                                        id="alamat"
                                        name="alamat"
                                        rows="3"
                                        placeholder="Masukkan alamat lengkap..."
                                    ><?= old(
                                        'alamat',
                                        $kk['alamat'] ?? ''
                                    ) ?></textarea>

                                </div>



                                <!-- =================================================
                                     CATATAN
                                     ================================================= -->
                                <div class="col-12">

                                    <label
                                        for="catatan"
                                        class="form-label fw-semibold"
                                    >

                                        <i class="bi bi-sticky me-1"></i>

                                        Catatan

                                    </label>


                                    <textarea
                                        class="form-control"
                                        id="catatan"
                                        name="catatan"
                                        rows="3"
                                        placeholder="Tambahkan catatan jika diperlukan..."
                                    ><?= old(
                                        'catatan',
                                        $kk['catatan'] ?? ''
                                    ) ?></textarea>


                                    <div class="form-text">

                                        Catatan bersifat opsional.

                                    </div>

                                </div>

                            </div>



                            <!-- =================================================
                                 DATA KEPALA KELUARGA
                                 ================================================= -->
                            <hr class="my-4">


                            <div class="mb-3">

                                <h5 class="fw-bold mb-1">

                                    <i class="bi bi-person-vcard text-primary me-2"></i>

                                    Data Kepala Keluarga

                                </h5>


                                <p class="text-muted small mb-0">

                                    Data berikut akan disinkronkan dengan Data Warga.

                                </p>

                            </div>


                            <div class="row g-3">


                                <!-- =================================================
                                     NIK
                                     ================================================= -->
                                <div class="col-md-6">

                                    <label
                                        for="nik_kepala_keluarga"
                                        class="form-label fw-semibold"
                                    >

                                        NIK Kepala Keluarga

                                        <span class="text-danger">*</span>

                                    </label>


                                    <input
                                        type="text"
                                        class="form-control"
                                        id="nik_kepala_keluarga"
                                        name="nik_kepala_keluarga"
                                        value="<?= old(
                                            'nik_kepala_keluarga',
                                            $nikKepalaKeluarga ?? ''
                                        ) ?>"
                                        maxlength="16"
                                        minlength="16"
                                        inputmode="numeric"
                                        placeholder="Masukkan 16 digit NIK"
                                        required
                                    >


                                    <div class="form-text">

                                        NIK harus terdiri dari 16 digit angka.

                                    </div>

                                </div>



                                <!-- =================================================
                                     JENIS KELAMIN
                                     ================================================= -->
                                <div class="col-md-6">

                                    <label
                                        for="jenis_kelamin_kepala_keluarga"
                                        class="form-label fw-semibold"
                                    >

                                        Jenis Kelamin

                                        <span class="text-danger">*</span>

                                    </label>


                                    <select
                                        class="form-select"
                                        id="jenis_kelamin_kepala_keluarga"
                                        name="jenis_kelamin_kepala_keluarga"
                                        required
                                    >

                                        <option value="">
                                            -- Pilih Jenis Kelamin --
                                        </option>


                                        <option
                                            value="L"
                                            <?= old(
                                                'jenis_kelamin_kepala_keluarga',
                                                $jenisKelaminKepalaKeluarga ?? ''
                                            ) === 'L'
                                                ? 'selected'
                                                : ''
                                            ?>
                                        >
                                            Laki-laki
                                        </option>


                                        <option
                                            value="P"
                                            <?= old(
                                                'jenis_kelamin_kepala_keluarga',
                                                $jenisKelaminKepalaKeluarga ?? ''
                                            ) === 'P'
                                                ? 'selected'
                                                : ''
                                            ?>
                                        >
                                            Perempuan
                                        </option>

                                    </select>

                                </div>



                                <!-- =================================================
                                     TEMPAT LAHIR
                                     ================================================= -->
                                <div class="col-md-6">

                                    <label
                                        for="tempat_lahir_kepala_keluarga"
                                        class="form-label fw-semibold"
                                    >

                                        Tempat Lahir

                                    </label>


                                    <input
                                        type="text"
                                        class="form-control"
                                        id="tempat_lahir_kepala_keluarga"
                                        name="tempat_lahir_kepala_keluarga"
                                        value="<?= old(
                                            'tempat_lahir_kepala_keluarga',
                                            $tempatLahirKepalaKeluarga ?? ''
                                        ) ?>"
                                        maxlength="100"
                                        placeholder="Contoh: Batam"
                                    >

                                </div>



                                <!-- =================================================
                                     TANGGAL LAHIR
                                     ================================================= -->
                                <div class="col-md-6">

                                    <label
                                        for="tanggal_lahir_kepala_keluarga"
                                        class="form-label fw-semibold"
                                    >

                                        Tanggal Lahir

                                    </label>


                                    <input
                                        type="date"
                                        class="form-control"
                                        id="tanggal_lahir_kepala_keluarga"
                                        name="tanggal_lahir_kepala_keluarga"
                                        value="<?= old(
                                            'tanggal_lahir_kepala_keluarga',
                                            $tanggalLahirKepalaKeluarga ?? ''
                                        ) ?>"
                                    >

                                </div>



                                <!-- =================================================
                                     AGAMA
                                     ================================================= -->
                                <div class="col-md-6">

                                    <label
                                        for="agama_kepala_keluarga"
                                        class="form-label fw-semibold"
                                    >

                                        Agama

                                    </label>


                                    <select
                                        class="form-select"
                                        id="agama_kepala_keluarga"
                                        name="agama_kepala_keluarga"
                                    >

                                        <option value="">
                                            -- Pilih Agama --
                                        </option>


                                        <option
                                            value="ISLAM"
                                            <?= old(
                                                'agama_kepala_keluarga',
                                                $agamaKepalaKeluarga ?? ''
                                            ) === 'ISLAM'
                                                ? 'selected'
                                                : ''
                                            ?>
                                        >
                                            Islam
                                        </option>


                                        <option
                                            value="KRISTEN"
                                            <?= old(
                                                'agama_kepala_keluarga',
                                                $agamaKepalaKeluarga ?? ''
                                            ) === 'KRISTEN'
                                                ? 'selected'
                                                : ''
                                            ?>
                                        >
                                            Kristen
                                        </option>


                                        <option
                                            value="KATOLIK"
                                            <?= old(
                                                'agama_kepala_keluarga',
                                                $agamaKepalaKeluarga ?? ''
                                            ) === 'KATOLIK'
                                                ? 'selected'
                                                : ''
                                            ?>
                                        >
                                            Katolik
                                        </option>


                                        <option
                                            value="HINDU"
                                            <?= old(
                                                'agama_kepala_keluarga',
                                                $agamaKepalaKeluarga ?? ''
                                            ) === 'HINDU'
                                                ? 'selected'
                                                : ''
                                            ?>
                                        >
                                            Hindu
                                        </option>


                                        <option
                                            value="BUDDHA"
                                            <?= old(
                                                'agama_kepala_keluarga',
                                                $agamaKepalaKeluarga ?? ''
                                            ) === 'BUDDHA'
                                                ? 'selected'
                                                : ''
                                            ?>
                                        >
                                            Buddha
                                        </option>


                                        <option
                                            value="KONGHUCU"
                                            <?= old(
                                                'agama_kepala_keluarga',
                                                $agamaKepalaKeluarga ?? ''
                                            ) === 'KONGHUCU'
                                                ? 'selected'
                                                : ''
                                            ?>
                                        >
                                            Konghucu
                                        </option>

                                    </select>

                                </div>



                                <!-- =================================================
                                     PENDIDIKAN
                                     ================================================= -->
                                <div class="col-md-6">

                                    <label
                                        for="pendidikan_kepala_keluarga"
                                        class="form-label fw-semibold"
                                    >

                                        Pendidikan

                                    </label>


                                    <input
                                        type="text"
                                        class="form-control"
                                        id="pendidikan_kepala_keluarga"
                                        name="pendidikan_kepala_keluarga"
                                        value="<?= old(
                                            'pendidikan_kepala_keluarga',
                                            $pendidikanKepalaKeluarga ?? ''
                                        ) ?>"
                                        maxlength="100"
                                        placeholder="Contoh: SMA"
                                    >

                                </div>



                                <!-- =================================================
                                     PEKERJAAN
                                     ================================================= -->
                                <div class="col-md-6">

                                    <label
                                        for="pekerjaan_kepala_keluarga"
                                        class="form-label fw-semibold"
                                    >

                                        Pekerjaan

                                    </label>


                                    <input
                                        type="text"
                                        class="form-control"
                                        id="pekerjaan_kepala_keluarga"
                                        name="pekerjaan_kepala_keluarga"
                                        value="<?= old(
                                            'pekerjaan_kepala_keluarga',
                                            $pekerjaanKepalaKeluarga ?? ''
                                        ) ?>"
                                        maxlength="100"
                                        placeholder="Contoh: Wiraswasta"
                                    >

                                </div>



                                <!-- =================================================
                                     NO HP
                                     ================================================= -->
                                <div class="col-md-6">

                                    <label
                                        for="no_hp_kepala_keluarga"
                                        class="form-label fw-semibold"
                                    >

                                        Nomor HP

                                    </label>


                                    <input
                                        type="text"
                                        class="form-control"
                                        id="no_hp_kepala_keluarga"
                                        name="no_hp_kepala_keluarga"
                                        value="<?= old(
                                            'no_hp_kepala_keluarga',
                                            $noHpKepalaKeluarga ?? ''
                                        ) ?>"
                                        maxlength="20"
                                        inputmode="tel"
                                        placeholder="08xxxxxxxxxx"
                                    >

                                </div>



                                <!-- =================================================
                                     STATUS PERKAWINAN
                                     ================================================= -->
                                <div class="col-md-6">

                                    <label
                                        for="status_perkawinan_kepala_keluarga"
                                        class="form-label fw-semibold"
                                    >

                                        Status Perkawinan

                                    </label>


                                    <select
                                        class="form-select"
                                        id="status_perkawinan_kepala_keluarga"
                                        name="status_perkawinan_kepala_keluarga"
                                    >

                                        <option value="">
                                            -- Pilih Status Perkawinan --
                                        </option>


                                        <option
                                            value="KAWIN"
                                            <?= old(
                                                'status_perkawinan_kepala_keluarga',
                                                $statusPerkawinanKepalaKeluarga ?? ''
                                            ) === 'KAWIN'
                                                ? 'selected'
                                                : ''
                                            ?>
                                        >
                                            Kawin
                                        </option>


                                        <option
                                            value="BELUM_KAWIN"
                                            <?= old(
                                                'status_perkawinan_kepala_keluarga',
                                                $statusPerkawinanKepalaKeluarga ?? ''
                                            ) === 'BELUM_KAWIN'
                                                ? 'selected'
                                                : ''
                                            ?>
                                        >
                                            Belum Kawin
                                        </option>


                                        <option
                                            value="JANDA"
                                            <?= old(
                                                'status_perkawinan_kepala_keluarga',
                                                $statusPerkawinanKepalaKeluarga ?? ''
                                            ) === 'JANDA'
                                                ? 'selected'
                                                : ''
                                            ?>
                                        >
                                            Janda
                                        </option>


                                        <option
                                            value="DUDA"
                                            <?= old(
                                                'status_perkawinan_kepala_keluarga',
                                                $statusPerkawinanKepalaKeluarga ?? ''
                                            ) === 'DUDA'
                                                ? 'selected'
                                                : ''
                                            ?>
                                        >
                                            Duda
                                        </option>


                                        <option
                                            value="MENINGGAL"
                                            <?= old(
                                                'status_perkawinan_kepala_keluarga',
                                                $statusPerkawinanKepalaKeluarga ?? ''
                                            ) === 'MENINGGAL'
                                                ? 'selected'
                                                : ''
                                            ?>
                                        >
                                            Meninggal
                                        </option>


                                        <option
                                            value="LAIN_LAIN"
                                            <?= old(
                                                'status_perkawinan_kepala_keluarga',
                                                $statusPerkawinanKepalaKeluarga ?? ''
                                            ) === 'LAIN_LAIN'
                                                ? 'selected'
                                                : ''
                                            ?>
                                        >
                                            Lain Lain
                                        </option>

                                    </select>

                                </div>

                            </div>



                            <!-- =================================================
                                 INFORMASI SINKRONISASI
                                 ================================================= -->
                            <div class="alert alert-info mt-4 mb-0">

                                <i class="bi bi-info-circle me-2"></i>

                                Perubahan data Kepala Keluarga akan
                                disinkronkan ke data warga dengan hubungan
                                <strong>KEPALA_KELUARGA</strong>.

                            </div>



                            <!-- =================================================
                                 BUTTON
                                 ================================================= -->
                            <div class="d-flex justify-content-end gap-2 mt-4">


                                <a
                                    href="<?= site_url('kartu-keluarga') ?>"
                                    class="btn btn-secondary"
                                >

                                    <i class="bi bi-x-circle me-1"></i>

                                    Batal

                                </a>


                                <button
                                    type="submit"
                                    class="btn btn-primary"
                                >

                                    <i class="bi bi-check-circle me-1"></i>

                                    Simpan Perubahan

                                </button>

                            </div>


                        </form>

                    </div>

                </div>

            </main>


            <?= view('layouts/footer') ?>

        </div>

    </div>

</div>