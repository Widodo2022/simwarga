<?= view('layouts/header', [
    'title' => $title ?? 'Tambah Kartu Keluarga'
]) ?>

<div class="container-fluid">
    <div class="row">

        <!-- SIDEBAR -->
        <div class="col-lg-2 d-none d-lg-block p-0">
            <?= view('layouts/sidebar') ?>
        </div>

        <!-- CONTENT -->
        <div class="col-lg-10 content p-0">

            <?= view('layouts/navbar') ?>

            <main class="p-4">

                <div class="mb-4">

                    <a href="<?= site_url('kartu-keluarga') ?>"
                       class="text-decoration-none">

                        <i class="bi bi-arrow-left me-1"></i>
                        Kembali ke Data KK

                    </a>

                    <h3 class="fw-bold mt-3 mb-1">
                        Tambah Kartu Keluarga
                    </h3>

                    <p class="text-muted mb-0">
                        Tambahkan data Kartu Keluarga baru.
                    </p>

                </div>


                <!-- ERROR -->

                <?php $errors = session()->getFlashdata('errors'); ?>

                <?php if (! empty($errors)): ?>

                    <div class="alert alert-danger">

                        <strong>
                            <i class="bi bi-exclamation-triangle me-1"></i>
                            Periksa data berikut:
                        </strong>

                        <ul class="mb-0 mt-2">

                            <?php foreach ($errors as $error): ?>

                                <li><?= esc($error) ?></li>

                            <?php endforeach; ?>

                        </ul>

                    </div>

                <?php endif; ?>


                <!-- FORM -->

                <div class="card shadow-sm border-0">

                    <div class="card-header bg-white py-3">

                        <strong>
                            <i class="bi bi-house-door me-2"></i>
                            Informasi Kartu Keluarga
                        </strong>

                    </div>

                    <div class="card-body">

                        <form action="<?= site_url('kartu-keluarga') ?>"
                              method="post">

                            <?= csrf_field() ?>


                            <!-- NO KK -->

                            <div class="mb-3">

                                <label for="no_kk"
                                       class="form-label fw-semibold">

                                    Nomor Kartu Keluarga
                                    <span class="text-danger">*</span>

                                </label>

                                <input type="text"
                                       class="form-control"
                                       id="no_kk"
                                       name="no_kk"
                                       value="<?= old('no_kk') ?>"
                                       maxlength="16"
                                       inputmode="numeric"
                                       placeholder="Masukkan 16 digit nomor KK"
                                       required>

                                <div class="form-text">
                                    Nomor KK harus terdiri dari 16 digit.
                                </div>

                            </div>


                            <!-- KEPALA KELUARGA -->

                            <div class="mb-3">

                                <label for="kepala_keluarga"
                                       class="form-label fw-semibold">

                                    Kepala Keluarga
                                    <span class="text-danger">*</span>

                                </label>

                                <input type="text"
                                       class="form-control"
                                       id="kepala_keluarga"
                                       name="kepala_keluarga"
                                       value="<?= old('kepala_keluarga') ?>"
                                       maxlength="150"
                                       placeholder="Nama kepala keluarga"
                                       required>

                            </div>

                                   <!-- NIK KEPALA KELUARGA -->

                                        <div class="mb-3">

                                            <label for="nik" class="form-label fw-semibold">

                                                NIK Kepala Keluarga
                                                <span class="text-danger">*</span>

                                            </label>

                                            <input
                                                type="text"
                                                class="form-control"
                                                id="nik"
                                                name="nik"
                                                value="<?= old('nik') ?>"
                                                maxlength="16"
                                                minlength="16"
                                                inputmode="numeric"
                                                placeholder="Masukkan 16 digit NIK"
                                                required
                                            >

                                            <div class="form-text">
                                                NIK kepala keluarga akan digunakan sebagai identitas warga.
                                            </div>

                                        </div> 

                                <!-- JENIS KELAMIN -->

                                <div class="mb-3">

                                    <label for="jenis_kelamin" class="form-label fw-semibold">

                                        Jenis Kelamin
                                        <span class="text-danger">*</span>

                                    </label>

                                    <select
                                        class="form-select"
                                        id="jenis_kelamin"
                                        name="jenis_kelamin"
                                        required
                                    >

                                        <option value="">
                                            -- Pilih Jenis Kelamin --
                                        </option>

                                        <option
                                            value="L"
                                            <?= old('jenis_kelamin') === 'L' ? 'selected' : '' ?>
                                        >
                                            Laki-laki
                                        </option>

                                        <option
                                            value="P"
                                            <?= old('jenis_kelamin') === 'P' ? 'selected' : '' ?>
                                        >
                                            Perempuan
                                        </option>

                                    </select>

                                </div>

                                    <!-- TEMPAT LAHIR -->

                                    <div class="mb-3">

                                        <label for="tempat_lahir" class="form-label fw-semibold">
                                            Tempat Lahir
                                        </label>

                                        <input
                                            type="text"
                                            class="form-control"
                                            id="tempat_lahir"
                                            name="tempat_lahir"
                                            value="<?= old('tempat_lahir') ?>"
                                            maxlength="100"
                                            placeholder="Contoh: Batam"
                                        >

                                    </div>


                        <!-- TANGGAL LAHIR -->

                        <div class="mb-3">

                            <label for="tanggal_lahir" class="form-label fw-semibold">
                                Tanggal Lahir
                            </label>

                            <input
                                type="date"
                                class="form-control"
                                id="tanggal_lahir"
                                name="tanggal_lahir"
                                value="<?= old('tanggal_lahir') ?>"
                            >

                        </div>

                                    <!-- AGAMA -->

                                <div class="mb-3">

                                    <label for="agama" class="form-label fw-semibold">
                                        Agama
                                    </label>

                                    <select
                                        class="form-select"
                                        id="agama"
                                        name="agama"
                                    >

                                        <option value="">
                                            -- Pilih Agama --
                                        </option>

                                        <option value="ISLAM"
                                            <?= old('agama') === 'ISLAM' ? 'selected' : '' ?>>
                                            Islam
                                        </option>

                                        <option value="KRISTEN"
                                            <?= old('agama') === 'KRISTEN' ? 'selected' : '' ?>>
                                            Kristen
                                        </option>

                                        <option value="KATOLIK"
                                            <?= old('agama') === 'KATOLIK' ? 'selected' : '' ?>>
                                            Katolik
                                        </option>

                                        <option value="HINDU"
                                            <?= old('agama') === 'HINDU' ? 'selected' : '' ?>>
                                            Hindu
                                        </option>

                                        <option value="BUDDHA"
                                            <?= old('agama') === 'BUDDHA' ? 'selected' : '' ?>>
                                            Buddha
                                        </option>

                                        <option value="KONGHUCU"
                                            <?= old('agama') === 'KONGHUCU' ? 'selected' : '' ?>>
                                            Konghucu
                                        </option>

                                    </select>

                                </div>

                                <!-- PENDIDIKAN -->

                                    <div class="mb-3">

                                        <label for="pendidikan" class="form-label fw-semibold">
                                            Pendidikan
                                        </label>

                                        <input
                                            type="text"
                                            class="form-control"
                                            id="pendidikan"
                                            name="pendidikan"
                                            value="<?= old('pendidikan') ?>"
                                            maxlength="100"
                                            placeholder="Contoh: SMA"
                                        >

                                    </div>


                                    <!-- PEKERJAAN -->

                                    <div class="mb-3">

                                        <label for="pekerjaan" class="form-label fw-semibold">
                                            Pekerjaan
                                        </label>

                                        <input
                                            type="text"
                                            class="form-control"
                                            id="pekerjaan"
                                            name="pekerjaan"
                                            value="<?= old('pekerjaan') ?>"
                                            maxlength="100"
                                            placeholder="Contoh: Wiraswasta"
                                        >

                                    </div>


                                    <!-- NO HP -->

                                    <div class="mb-3">

                                        <label for="no_hp" class="form-label fw-semibold">
                                            Nomor HP
                                        </label>

                                        <input
                                            type="text"
                                            class="form-control"
                                            id="no_hp"
                                            name="no_hp"
                                            value="<?= old('no_hp') ?>"
                                            maxlength="20"
                                            inputmode="tel"
                                            placeholder="08xxxxxxxxxx"
                                        >

                                    </div>
                                    <!-- STATUS PERKAWINAN -->

                                        <div class="mb-4">

                                            <label for="status_perkawinan" class="form-label fw-semibold">

                                                Status Perkawinan
                                                <span class="text-danger">*</span>

                                            </label>

                                            <select
                                                class="form-select"
                                                id="status_perkawinan"
                                                name="status_perkawinan"
                                                required
                                            >

                                                <option value="">
                                                    -- Pilih Status Perkawinan --
                                                </option>

                                                <option value="KAWIN"
                                                    <?= old('status_perkawinan') === 'KAWIN' ? 'selected' : '' ?>>
                                                    Kawin
                                                </option>

                                                <option value="BELUM_KAWIN"
                                                    <?= old('status_perkawinan') === 'BELUM_KAWIN' ? 'selected' : '' ?>>
                                                    Belum Kawin
                                                </option>

                                                <option value="JANDA"
                                                    <?= old('status_perkawinan') === 'JANDA' ? 'selected' : '' ?>>
                                                    Janda
                                                </option>

                                                <option value="DUDA"
                                                    <?= old('status_perkawinan') === 'DUDA' ? 'selected' : '' ?>>
                                                    Duda
                                                </option>

                                                <option value="MENINGGAL"
                                                    <?= old('status_perkawinan') === 'MENINGGAL' ? 'selected' : '' ?>>
                                                    Meninggal
                                                </option>

                                                <option value="LAIN_LAIN"
                                                    <?= old('status_perkawinan') === 'LAIN_LAIN' ? 'selected' : '' ?>>
                                                    Lain Lain
                                                </option>

                                            </select>

                                        </div>

                            <!-- KODE WILAYAH -->

                            <div class="mb-3">

                                <label for="kode_wilayah"
                                       class="form-label fw-semibold">

                                    Kode Wilayah

                                </label>

                                <input type="text"
                                       class="form-control"
                                       id="kode_wilayah"
                                       name="kode_wilayah"
                                       value="<?= old('kode_wilayah') ?>"
                                       maxlength="50"
                                       placeholder="Contoh: 32.01.01.1001">

                                <div class="form-text">
                                    Untuk sementara dapat diisi manual.
                                </div>

                            </div>


                            <!-- ALAMAT -->

                            <div class="mb-3">

                                <label for="alamat"
                                       class="form-label fw-semibold">

                                    Alamat

                                </label>

                                <textarea class="form-control"
                                          id="alamat"
                                          name="alamat"
                                          rows="4"
                                          placeholder="Alamat lengkap keluarga"><?= old('alamat') ?></textarea>

                            </div>

                            <!-- CATATAN -->
                            <div class="mb-3">
    <label for="catatan" class="form-label">
        <i class="bi bi-sticky me-1"></i> Catatan
    </label>
    <textarea
        class="form-control"
        id="catatan"
        name="catatan"
        rows="3"
        placeholder="Masukkan catatan penting tentang keluarga ini..."
    ><?= old('catatan') ?></textarea>
    <div class="form-text">
        Catatan bersifat opsional. Contoh: informasi khusus keluarga, keterangan administrasi, atau catatan lainnya.
    </div>
</div>

                            <!-- STATUS -->

                            <div class="mb-4">

                                <label for="status"
                                       class="form-label fw-semibold">

                                    Status

                                </label>

                                <select class="form-select"
                                        id="status"
                                        name="status">

                                    <option value="aktif"
                                        <?= old('status', 'aktif') === 'aktif' ? 'selected' : '' ?>>
                                        Aktif
                                    </option>

                                    <option value="nonaktif"
                                        <?= old('status') === 'nonaktif' ? 'selected' : '' ?>>
                                        Nonaktif
                                    </option>

                                </select>

                            </div>


                            <!-- BUTTON -->

                            <div class="d-flex gap-2">

                                <a href="<?= site_url('kartu-keluarga') ?>"
                                   class="btn btn-secondary">

                                    <i class="bi bi-x-circle me-1"></i>
                                    Batal

                                </a>

                                <button type="submit"
                                        class="btn btn-primary">

                                    <i class="bi bi-save me-1"></i>
                                    Simpan Kartu Keluarga

                                </button>

                            </div>

                        </form>

                    </div>

                </div>

            </main>

            <?= view('layouts/footer') ?>

        </div>

    </div>
</div>