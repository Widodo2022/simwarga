<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Login - Sistem Informasi Manajemen WARGA RT007 RW023</title>

    <link
        href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css"
        rel="stylesheet"
    >
</head>

<body class="bg-light">

<div class="container">
    <div class="row justify-content-center align-items-center min-vh-100">

        <div class="col-12 col-sm-10 col-md-6 col-lg-4">

            <div class="card shadow border-0">

                <div class="card-body p-4">

                    <div class="text-center mb-4">

                        <h3 class="fw-bold">
                            SIMWARGA
                        </h3>

                        <p class="text-muted mb-0">
                            RT 007 / RW 023
                        </p>

                        <small class="text-muted">
                            Vila Gading Harapan
                        </small>

                    </div>

                    <?php if (session()->getFlashdata('error')): ?>

                        <div class="alert alert-danger">
                            <?= session()->getFlashdata('error') ?>
                        </div>

                    <?php endif; ?>

                    <?php if (session()->getFlashdata('success')): ?>

                        <div class="alert alert-success">
                            <?= session()->getFlashdata('success') ?>
                        </div>

                    <?php endif; ?>

                    <form
                        action="<?= site_url('login') ?>"
                        method="post"
                    >

                        <?= csrf_field() ?>

                        <div class="mb-3">

                            <label class="form-label">
                                Username
                            </label>

                            <input
                                type="text"
                                name="username"
                                class="form-control"
                                value="<?= old('username') ?>"
                                autocomplete="username"
                                required
                                autofocus
                            >

                        </div>

                        <div class="mb-3">

                            <label class="form-label">
                                Password
                            </label>

                            <input
                                type="password"
                                name="password"
                                class="form-control"
                                autocomplete="current-password"
                                required
                            >

                        </div>

                        <button
                            type="submit"
                            class="btn btn-primary w-100"
                        >
                            Login
                        </button>

                    </form>

                </div>

            </div>

            <div class="text-center mt-3">

                <small class="text-muted">
                    Sistem Manajemen Warga Digital
                </small>

            </div>

        </div>

    </div>
</div>

</body>
</html>