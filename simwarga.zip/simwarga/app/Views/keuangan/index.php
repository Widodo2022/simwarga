<?= view('layouts/header', ['title' => $title ?? 'Keuangan RT']) ?>
<div class="container-fluid">
    <div class="row">
        <div class="col-lg-2 d-none d-lg-block p-0"><?= view('layouts/sidebar') ?></div>
        <div class="col-lg-10 content p-0">
            <?= view('layouts/navbar') ?>
            <main class="p-3 p-md-4">
                <div class="mb-4">
                    <h3 class="fw-bold mb-1"><i class="bi bi-journal-text text-primary me-2"></i>Keuangan RT</h3>
                    <p class="text-muted mb-0">Ringkasan keuangan berdasarkan tagihan iuran yang tercatat.</p>
                </div>

                <div class="row g-3 mb-4">
                    <div class="col-md-3"><div class="card border-0 shadow-sm h-100"><div class="card-body"><div class="text-muted small">Saldo Awal</div><div class="fs-5 fw-bold">Rp <?= number_format((float)$saldoAwal,0,',','.') ?></div></div></div></div>
                    <div class="col-md-3"><div class="card border-0 shadow-sm h-100"><div class="card-body"><div class="text-muted small">Pemasukan Valid</div><div class="fs-5 fw-bold text-success">Rp <?= number_format((float)$pemasukan,0,',','.') ?></div></div></div></div>
                    <div class="col-md-3"><div class="card border-0 shadow-sm h-100"><div class="card-body"><div class="text-muted small">Pengeluaran Disetujui</div><div class="fs-5 fw-bold text-danger">Rp <?= number_format((float)$pengeluaran,0,',','.') ?></div></div></div></div>
                    <div class="col-md-3"><div class="card border-0 shadow-sm h-100"><div class="card-body"><div class="text-muted small">Saldo Akhir</div><div class="fs-5 fw-bold text-primary">Rp <?= number_format((float)$saldoAkhir,0,',','.') ?></div></div></div></div>
                </div>
                <?php if (!$saldoConfigured): ?><div class="alert alert-warning">Saldo awal belum ditetapkan. Tetapkan sekali saat pembukuan pertama kali diinisialisasi.</div><div class="card border-0 shadow-sm mb-4"><div class="card-body"><form method="post" action="<?= site_url('keuangan/saldo-awal') ?>"><?= csrf_field() ?><div class="row g-3"><div class="col-md-4"><label class="form-label">Tanggal Mulai</label><input type="date" name="tanggal_mulai" class="form-control" value="<?= date('Y-m-d') ?>" required></div><div class="col-md-4"><label class="form-label">Saldo Awal</label><input type="number" name="nominal" class="form-control" min="0" step="0.01" required></div><div class="col-md-4"><label class="form-label">Keterangan</label><input name="keterangan" class="form-control"></div></div><button class="btn btn-primary mt-3">Tetapkan Saldo Awal</button></form></div></div><?php endif; ?>
                <div class="card border-0 shadow-sm">
                    <div class="card-header bg-white py-3 fw-bold">Transaksi Tagihan Terbaru</div>
                    <div class="card-body table-responsive">
                        <table class="table table-hover align-middle mb-0">
                            <thead><tr><th>No</th><th>KK</th><th>Jenis</th><th>Periode</th><th class="text-end">Nominal</th><th>Status</th></tr></thead>
                            <tbody>
                            <?php foreach (array_slice($tagihan,0,20) as $i=>$row): ?>
                                <tr>
                                    <td><?= $i+1 ?></td>
                                    <td class="font-monospace"><?= esc($row['no_kk']) ?></td>
                                    <td><?= esc($row['nama_iuran'] ?? '-') ?></td>
                                    <td><?= esc(ucfirst($row['periode'])) ?> <?= esc($row['tahun']) ?></td>
                                    <td class="text-end">Rp <?= number_format((float)$row['nominal'],0,',','.') ?></td>
                                    <td><?= esc(ucfirst(str_replace('_',' ',$row['status']))) ?></td>
                                </tr>
                            <?php endforeach; ?>
                            <?php if (empty($tagihan)): ?><tr><td colspan="6" class="text-center text-muted py-4">Belum ada transaksi tagihan.</td></tr><?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </main>
            <?= view('layouts/footer') ?>
        </div>
    </div>
</div>
