<?= view('layouts/header', ['title' => $title ?? 'Dashboard']) ?>

<div class="container-fluid">
    <div class="row">
        <div class="col-lg-2 d-none d-lg-block p-0"><?= view('layouts/sidebar') ?></div>

        <div class="col-lg-10 content p-0">
            <?= view('layouts/navbar') ?>

            <main class="p-3 p-md-4">
                <?php if (!empty($wargaMode)): ?>
                <div class="card border-0 shadow-sm">
                    <div class="card-body p-4">
                        <h3 class="fw-bold">Selamat datang, <?= esc($nama) ?></h3>
                        <p class="text-muted mb-0">Akun Warga memiliki akses baca saja. Gunakan menu Tagihan Iuran untuk melihat kewajiban dan status pembayaran milik Anda.</p>
                        <a class="btn btn-primary mt-3" href="<?= site_url('tagihan-iuran') ?>"><i class="bi bi-receipt me-1"></i>Lihat Tagihan Saya</a>
                    </div>
                </div>
                <?php else: ?>
                <div class="mb-4">
                    <h3 class="fw-bold mb-1">Dashboard</h3>
                    <p class="text-muted mb-0">Selamat datang, <strong><?= esc($nama) ?></strong>. Ringkasan kondisi SIMWARGA RT007 / RW023.</p>
                </div>

                <div class="row g-3 mb-4">
                    <div class="col-6 col-xl-3"><div class="card border-0 shadow-sm h-100"><div class="card-body"><div class="text-muted small">KK Aktif</div><div class="fs-3 fw-bold text-primary mt-1"><?= (int)$totalKK ?></div><?php if (canAccess('kk.view')): ?><a href="<?= site_url('kartu-keluarga') ?>" class="small text-decoration-none">Kelola KK <i class="bi bi-arrow-right"></i></a><?php endif; ?></div></div></div>
                    <div class="col-6 col-xl-3"><div class="card border-0 shadow-sm h-100"><div class="card-body"><div class="text-muted small">Warga Aktif</div><div class="fs-3 fw-bold text-success mt-1"><?= (int)$totalWarga ?></div><?php if (canAccess('warga.view')): ?><a href="<?= site_url('warga') ?>" class="small text-decoration-none">Kelola warga <i class="bi bi-arrow-right"></i></a><?php endif; ?></div></div></div>
                    <div class="col-6 col-xl-3"><div class="card border-0 shadow-sm h-100"><div class="card-body"><div class="text-muted small">Jenis Iuran Aktif</div><div class="fs-3 fw-bold text-warning mt-1"><?= (int)$totalJenisIuran ?></div><?php if (canAccess('jenis_iuran.view')): ?><a href="<?= site_url('jenis-iuran') ?>" class="small text-decoration-none">Kelola iuran <i class="bi bi-arrow-right"></i></a><?php endif; ?></div></div></div>
                    <div class="col-6 col-xl-3"><div class="card border-0 shadow-sm h-100"><div class="card-body"><div class="text-muted small">Total Tagihan</div><div class="fs-3 fw-bold text-dark mt-1"><?= (int)$totalTagihan ?></div><?php if (canAccess('tagihan_iuran.view')): ?><a href="<?= site_url('tagihan-iuran') ?>" class="small text-decoration-none">Lihat tagihan <i class="bi bi-arrow-right"></i></a><?php endif; ?></div></div></div>
                </div>

                <div class="row g-3">
                    <div class="col-lg-7">
                        <div class="card border-0 shadow-sm h-100">
                            <div class="card-header bg-white py-3 fw-bold"><i class="bi bi-cash-stack text-primary me-2"></i>Ringkasan Pembayaran</div>
                            <div class="card-body">
                                <div class="d-flex justify-content-between border-bottom py-3">
                                    <span>Sudah Lunas</span><strong class="text-success">Rp <?= number_format((float)$nominalLunas,0,',','.') ?></strong>
                                </div>
                                <div class="d-flex justify-content-between py-3">
                                    <span>Belum Bayar</span><strong class="text-danger">Rp <?= number_format((float)$nominalBelumBayar,0,',','.') ?></strong>
                                </div>
                                <div class="mt-3">
                                    <div class="d-flex justify-content-between small text-muted mb-1"><span>Lunas</span><span><?= (int)$totalLunas ?> transaksi</span></div>
                                    <div class="d-flex justify-content-between small text-muted"><span>Belum bayar</span><span><?= (int)$totalBelumBayar ?> transaksi</span></div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="col-lg-5">
                        <div class="card border-0 shadow-sm h-100">
                            <div class="card-header bg-white py-3 fw-bold"><i class="bi bi-lightning-charge text-warning me-2"></i>Akses Cepat</div>
                            <div class="card-body d-grid gap-2">
                                <?php if (canAccess('kk.create')): ?><a class="btn btn-primary" href="<?= site_url('kartu-keluarga/create') ?>"><i class="bi bi-house-add me-1"></i>Tambah Kartu Keluarga</a><?php endif; ?>
                                <?php if (canAccess('warga.create')): ?><a class="btn btn-outline-primary" href="<?= site_url('warga/create') ?>"><i class="bi bi-person-plus me-1"></i>Tambah Warga</a><?php endif; ?>
                                <?php if (canAccess('jenis_iuran.create')): ?><a class="btn btn-outline-primary" href="<?= site_url('jenis-iuran/create') ?>"><i class="bi bi-plus-circle me-1"></i>Tambah Jenis Iuran</a><?php endif; ?>
                                <?php if (canAccess('tagihan_iuran.create')): ?><a class="btn btn-outline-primary" href="<?= site_url('tagihan-iuran/create') ?>"><i class="bi bi-receipt-cutoff me-1"></i>Buat Tagihan</a><?php endif; ?>
                            </div>
                        </div>
                    </div>
                </div>
                <?php endif; ?>
            </main>

            <?= view('layouts/footer') ?>
        </div>
    </div>
</div>
