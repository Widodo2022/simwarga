<?= view('layouts/header', ['title' => $title ?? 'Laporan']) ?>
<div class="container-fluid">
    <div class="row">
        <div class="col-lg-2 d-none d-lg-block p-0"><?= view('layouts/sidebar') ?></div>
        <div class="col-lg-10 content p-0">
            <?= view('layouts/navbar') ?>
            <main class="p-3 p-md-4">
                <div class="d-flex flex-wrap justify-content-between align-items-center gap-2 mb-4">
                    <div>
                        <h3 class="fw-bold mb-1"><i class="bi bi-bar-chart text-primary me-2"></i>Laporan</h3>
                        <p class="text-muted mb-0">Ringkasan data administrasi dan iuran RT007 / RW023.</p>
                    </div>
                    <button class="btn btn-outline-secondary" onclick="window.print()"><i class="bi bi-printer me-1"></i>Print</button>
                </div>

                <div class="row g-3 mb-4">
                    <div class="col-6 col-xl-3"><div class="card border-0 shadow-sm h-100"><div class="card-body"><div class="text-muted small">KK Aktif</div><div class="fs-4 fw-bold"><?= (int)$totalKK ?></div></div></div></div>
                    <div class="col-6 col-xl-3"><div class="card border-0 shadow-sm h-100"><div class="card-body"><div class="text-muted small">Warga Aktif</div><div class="fs-4 fw-bold"><?= (int)$totalWarga ?></div></div></div></div>
                    <div class="col-6 col-xl-3"><div class="card border-0 shadow-sm h-100"><div class="card-body"><div class="text-muted small">Jenis Iuran Aktif</div><div class="fs-4 fw-bold"><?= (int)$totalJenisIuran ?></div></div></div></div>
                    <div class="col-6 col-xl-3"><div class="card border-0 shadow-sm h-100"><div class="card-body"><div class="text-muted small">Total Tagihan</div><div class="fs-4 fw-bold"><?= (int)$totalTagihan ?></div></div></div></div>
                </div>

                <div class="card border-0 shadow-sm mb-4">
                    <div class="card-header bg-primary text-white py-3 fw-bold">Ringkasan Iuran</div>
                    <div class="card-body">
                        <div class="row g-3">
                            <div class="col-md-4"><div class="border rounded p-3"><div class="text-muted small">Nilai Tagihan</div><div class="fs-5 fw-bold">Rp <?= number_format((float)$nominalTagihan,0,',','.') ?></div></div></div>
                            <div class="col-md-4"><div class="border rounded p-3"><div class="text-muted small">Sudah Lunas</div><div class="fs-5 fw-bold text-success">Rp <?= number_format((float)$nominalLunas,0,',','.') ?></div></div></div>
                            <div class="col-md-4"><div class="border rounded p-3"><div class="text-muted small">Belum Lunas</div><div class="fs-5 fw-bold text-danger">Rp <?= number_format((float)$nominalBelumBayar,0,',','.') ?></div></div></div>
                        </div>
                    </div>
                </div>

                <div class="card border-0 shadow-sm">
                    <div class="card-header bg-white py-3 fw-bold">Daftar Tagihan</div>
                    <div class="card-body table-responsive">
                        <table class="table table-sm table-hover align-middle">
                            <thead><tr><th>No</th><th>KK</th><th>Jenis Iuran</th><th>Tahun</th><th class="text-end">Nominal</th><th>Status</th></tr></thead>
                            <tbody>
                            <?php foreach ($tagihan as $i=>$row): ?>
                                <tr>
                                    <td><?= $i+1 ?></td>
                                    <td class="font-monospace"><?= esc($row['no_kk']) ?></td>
                                    <td><?= esc($row['nama_iuran'] ?? '-') ?></td>
                                    <td><?= esc($row['tahun']) ?></td>
                                    <td class="text-end">Rp <?= number_format((float)$row['nominal'],0,',','.') ?></td>
                                    <td><?= esc(ucfirst(str_replace('_',' ',$row['status']))) ?></td>
                                </tr>
                            <?php endforeach; ?>
                            <?php if (empty($tagihan)): ?><tr><td colspan="6" class="text-center text-muted py-4">Belum ada data.</td></tr><?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </main>
            <?= view('layouts/footer') ?>
        </div>
    </div>
</div>
<style>@media print{.sidebar,.navbar,.offcanvas,button{display:none!important}.content{width:100%!important}.card{box-shadow:none!important;border:1px solid #ddd!important}}</style>
