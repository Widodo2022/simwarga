<?php

use CodeIgniter\Router\RouteCollection;

/** @var RouteCollection $routes */

/*
|--------------------------------------------------------------------------
| Public
|--------------------------------------------------------------------------
*/
$routes->get('/', 'Home::index');
$routes->get('/login', 'Auth::login');
$routes->post('/login', 'Auth::attemptLogin');
$routes->get('/logout', 'Auth::logout');

/*
|--------------------------------------------------------------------------
| Halaman setelah login
|--------------------------------------------------------------------------
*/
$routes->group('', ['filter' => 'auth'], static function ($routes) {

    $routes->get('/dashboard', 'Dashboard::index');

    // Manajemen akses & RBAC (khusus Administrator)
    $routes->get('/akses', 'Akses::index');
    $routes->get('/akses/user/create', 'Akses::createUser');
    $routes->post('/akses/user', 'Akses::storeUser');
    $routes->get('/akses/user/edit/(:num)', 'Akses::editUser/$1');
    $routes->post('/akses/user/update/(:num)', 'Akses::updateUser/$1');
    $routes->post('/akses/role/(:num)/permissions', 'Akses::updateRolePermissions/$1');

    // Backup & Restore Sistem (khusus Administrator)
    $routes->get('/backup', 'Backup::index');
    $routes->post('/backup/database', 'Backup::createDatabase');
    $routes->post('/backup/source', 'Backup::createSource');
    $routes->get('/backup/download/(:any)', 'Backup::download/$1');
    $routes->post('/backup/restore-database', 'Backup::restoreDatabase');
    $routes->post('/backup/restore-source', 'Backup::restoreSource');

    // Master wilayah
    $routes->get('/master-wilayah', 'MasterWilayah::index');

    // Warga
    $routes->get('/warga', 'Warga::index');
    $routes->get('/warga/create', 'Warga::create');
    $routes->post('/warga', 'Warga::store');
    $routes->get('/warga/edit/(:num)', 'Warga::edit/$1');
    $routes->post('/warga/update/(:num)', 'Warga::update/$1');
    $routes->post('/warga/delete/(:num)', 'Warga::delete/$1');
    $routes->get('/warga/ktp/(:num)', 'Warga::ktp/$1');

    // Kartu Keluarga
    $routes->get('/kartu-keluarga', 'KartuKeluarga::index');
    $routes->get('/kartu-keluarga/create', 'KartuKeluarga::create');
    $routes->post('/kartu-keluarga', 'KartuKeluarga::store');
    $routes->get('/kartu-keluarga/edit/(:num)', 'KartuKeluarga::edit/$1');
    $routes->post('/kartu-keluarga/update/(:num)', 'KartuKeluarga::update/$1');
    $routes->get('/kartu-keluarga/detail/(:num)', 'KartuKeluarga::detail/$1');
    $routes->post('/kartu-keluarga/delete/(:num)', 'KartuKeluarga::delete/$1');

    // Jenis Iuran
    $routes->get('/jenis-iuran', 'JenisIuran::index');
    $routes->get('/jenis-iuran/create', 'JenisIuran::create');
    $routes->post('/jenis-iuran', 'JenisIuran::store');
    $routes->get('/jenis-iuran/edit/(:num)', 'JenisIuran::edit/$1');
    $routes->post('/jenis-iuran/update/(:num)', 'JenisIuran::update/$1');
    $routes->post('/jenis-iuran/delete/(:num)', 'JenisIuran::delete/$1');

    // Keuangan RT
    $routes->get('/keuangan', 'Keuangan::index');
    $routes->post('/keuangan/saldo-awal', 'Keuangan::setSaldoAwal');

    // Pengeluaran RT
    $routes->get('/pengeluaran', 'Pengeluaran::index');
    $routes->get('/pengeluaran/create', 'Pengeluaran::create');
    $routes->post('/pengeluaran', 'Pengeluaran::store');
    $routes->get('/pengeluaran/edit/(:num)', 'Pengeluaran::edit/$1');
    $routes->post('/pengeluaran/update/(:num)', 'Pengeluaran::update/$1');
    $routes->post('/pengeluaran/submit/(:num)', 'Pengeluaran::submit/$1');
    $routes->post('/pengeluaran/check/(:num)', 'Pengeluaran::check/$1');
    $routes->post('/pengeluaran/approve/(:num)', 'Pengeluaran::approve/$1');
    $routes->post('/pengeluaran/delete/(:num)', 'Pengeluaran::delete/$1');
    $routes->get('/pengeluaran/master', 'PengeluaranMaster::index');
    $routes->post('/pengeluaran/master/kategori', 'PengeluaranMaster::saveKategori');
    $routes->post('/pengeluaran/master/penerima', 'PengeluaranMaster::savePenerima');
    $routes->post('/pengeluaran/master/sumber', 'PengeluaranMaster::saveSumber');

    // Laporan
    $routes->get('/laporan', 'Laporan::index');

    // Tagihan Iuran
    $routes->get('/tagihan-iuran', 'TagihanIuran::index');
    $routes->get('/tagihan-iuran/create', 'TagihanIuran::create');
    $routes->get('/tagihan-iuran/generate', 'TagihanIuran::generate');
    $routes->post('/tagihan-iuran/generate/preview', 'TagihanIuran::generatePreview');
    $routes->post('/tagihan-iuran/generate/confirm', 'TagihanIuran::generateConfirm');
    $routes->get('/tagihan-iuran/pembayaran', 'TagihanIuran::pembayaran');
    $routes->post('/tagihan-iuran/pembayaran', 'TagihanIuran::storePembayaran');
    $routes->get('/tagihan-iuran/outstanding/(:segment)', 'TagihanIuran::outstandingJson/$1');
    $routes->post('/tagihan-iuran/pembayaran/cancel/(:num)', 'TagihanIuran::cancelPayment/$1');
    $routes->post('/tagihan-iuran/cancel/(:num)', 'TagihanIuran::cancelTagihan/$1');
    $routes->post('/tagihan-iuran/restore/(:num)', 'TagihanIuran::restoreTagihan/$1');
    $routes->post('/tagihan-iuran', 'TagihanIuran::store');
    $routes->get('/tagihan-iuran/edit/(:num)', 'TagihanIuran::edit/$1');
    $routes->post('/tagihan-iuran/update/(:num)', 'TagihanIuran::update/$1');
    $routes->get('/tagihan-iuran/detail/(:num)', 'TagihanIuran::show/$1');
    $routes->post('/tagihan-iuran/bayar/(:num)', 'TagihanIuran::bayar/$1');
    $routes->post('/tagihan-iuran/status/(:num)', 'TagihanIuran::status/$1');
    $routes->post('/tagihan-iuran/batalkan/(:num)', 'TagihanIuran::batalkan/$1');
    $routes->post('/tagihan-iuran/delete/(:num)', 'TagihanIuran::delete/$1');
});
