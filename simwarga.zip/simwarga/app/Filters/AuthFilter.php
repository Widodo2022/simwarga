<?php

namespace App\Filters;

use CodeIgniter\Filters\FilterInterface;
use CodeIgniter\HTTP\RequestInterface;
use CodeIgniter\HTTP\ResponseInterface;

class AuthFilter implements FilterInterface
{
    public function before(RequestInterface $request, $arguments = null)
    {
        if (! session()->get('isLoggedIn')) {
            return redirect()->to(site_url('login'))->with('error', 'Silakan login terlebih dahulu.');
        }

        $path = trim($request->getUri()->getPath(), '/');
        $path = preg_replace('#^simwarga/public/index\.php/?#', '', $path);
        $method = strtoupper($request->getMethod());
        $permission = $this->permissionFor($path, $method);

        if ($permission !== null) {
            $permissions = session()->get('permissions') ?? [];
            if (! in_array($permission, $permissions, true)) {
                return redirect()->to(site_url('dashboard'))->with('error', 'Akses ditolak. Permission yang diperlukan: ' . $permission);
            }
        }

        if ((string) session()->get('role_kode') === 'WARGA') {
            $allowed = $method === 'GET' && (
                $path === 'dashboard'
                || $path === 'tagihan-iuran'
                || preg_match('#^tagihan-iuran/detail/[0-9]+$#', $path)
            );
            if (! $allowed) {
                return redirect()->to(site_url('dashboard'))->with('error', 'Akun Warga hanya memiliki akses melihat informasi miliknya.');
            }
        }
    }

    public function after(RequestInterface $request, ResponseInterface $response, $arguments = null) {}

    private function permissionFor(string $path, string $method): ?string
    {
        if ($path === 'dashboard') return 'dashboard.view';
        if ($path === 'akses' || preg_match('#^akses/(user|role)/#', $path)) return 'rbac.manage';

        if ($path === 'backup') return 'system.backup.history';
        if ($path === 'backup/database' || $path === 'backup/source') return 'system.backup';
        if (preg_match('#^backup/download/#', $path)) return 'system.backup.download';
        if ($path === 'backup/restore-database' || $path === 'backup/restore-source') return 'system.restore';

        if ($path === 'warga') return $method === 'GET' ? 'warga.view' : 'warga.create';
        if ($path === 'warga/create') return 'warga.create';
        if (preg_match('#^warga/edit/#', $path)) return 'warga.edit';
        if (preg_match('#^warga/update/#', $path)) return 'warga.edit';
        if (preg_match('#^warga/delete/#', $path)) return 'warga.delete';
        if (preg_match('#^warga/ktp/#', $path)) return 'warga.view';

        if ($path === 'kartu-keluarga') return $method === 'GET' ? 'kk.view' : 'kk.create';
        if ($path === 'kartu-keluarga/create') return 'kk.create';
        if (preg_match('#^kartu-keluarga/detail/#', $path)) return 'kk.view';
        if (preg_match('#^kartu-keluarga/edit/#', $path)) return 'kk.edit';
        if (preg_match('#^kartu-keluarga/update/#', $path)) return 'kk.edit';
        if (preg_match('#^kartu-keluarga/delete/#', $path)) return 'kk.delete';

        if ($path === 'jenis-iuran') return $method === 'GET' ? 'jenis_iuran.view' : 'jenis_iuran.create';
        if ($path === 'jenis-iuran/create') return 'jenis_iuran.create';
        if (preg_match('#^jenis-iuran/edit/#', $path)) return 'jenis_iuran.edit';
        if (preg_match('#^jenis-iuran/update/#', $path)) return 'jenis_iuran.edit';
        if (preg_match('#^jenis-iuran/delete/#', $path)) return 'jenis_iuran.delete';

        if ($path === 'tagihan-iuran') return $method === 'GET' ? 'tagihan_iuran.view' : 'tagihan_iuran.create';
        if ($path === 'tagihan-iuran/create' || $path === 'tagihan-iuran/generate' || $path === 'tagihan-iuran/generate/preview' || $path === 'tagihan-iuran/generate/confirm') return 'tagihan_iuran.create';
        if (preg_match('#^tagihan-iuran/edit/#', $path) || $path === 'tagihan-iuran/update') return 'tagihan_iuran.edit';
        if (preg_match('#^tagihan-iuran/detail/#', $path) || preg_match('#^tagihan-iuran/outstanding/#', $path)) return 'tagihan_iuran.view';
        if ($path === 'tagihan-iuran/pembayaran') return $method === 'GET' ? 'pembayaran_iuran.view' : 'pembayaran_iuran.create';
        if (preg_match('#^tagihan-iuran/pembayaran/cancel/#', $path)) return 'pembayaran_iuran.cancel';
        if (preg_match('#^tagihan-iuran/cancel/#', $path) || preg_match('#^tagihan-iuran/batalkan/#', $path) || preg_match('#^tagihan-iuran/delete/#', $path)) return 'tagihan_iuran.cancel';
        if (preg_match('#^tagihan-iuran/restore/#', $path)) return 'tagihan_iuran.restore';
        if ($path === 'tagihan-iuran' && $method !== 'GET') return 'tagihan_iuran.create';
        if (preg_match('#^tagihan-iuran/bayar/#', $path)) return 'pembayaran_iuran.create';
        if (preg_match('#^tagihan-iuran/status/#', $path)) return 'tagihan_iuran.edit';

        if ($path === 'pengeluaran') return $method === 'GET' ? 'pengeluaran.view' : 'pengeluaran.create';
        if ($path === 'pengeluaran/create') return 'pengeluaran.create';
        if (preg_match('#^pengeluaran/edit/#', $path) || preg_match('#^pengeluaran/update/#', $path)) return 'pengeluaran.edit';
        if (preg_match('#^pengeluaran/submit/#', $path)) return 'pengeluaran.submit';
        if (preg_match('#^pengeluaran/check/#', $path)) return 'pengeluaran.check';
        if (preg_match('#^pengeluaran/approve/#', $path)) return 'pengeluaran.approve';
        if (preg_match('#^pengeluaran/delete/#', $path)) return 'pengeluaran.delete';
        if ($path === 'pengeluaran/master') return 'pengeluaran.master.manage';
        if (str_starts_with($path, 'pengeluaran/master/')) return 'pengeluaran.master.manage';

        if ($path === 'keuangan') return 'keuangan.view';
        if ($path === 'keuangan/saldo-awal') return 'keuangan.opening_balance.manage';
        if ($path === 'laporan') return 'laporan.view';
        if ($path === 'master-wilayah') return 'master_wilayah.view';
        return null;
    }
}
