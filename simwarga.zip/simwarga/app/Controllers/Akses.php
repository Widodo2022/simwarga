<?php

namespace App\Controllers;

use App\Models\PermissionModel;
use App\Models\RoleModel;
use App\Models\RolePermissionModel;
use App\Models\UserModel;
use App\Models\UserRoleModel;

class Akses extends BaseController
{
    protected UserModel $users;
    protected RoleModel $roles;
    protected PermissionModel $permissions;
    protected RolePermissionModel $rolePermissions;
    protected UserRoleModel $userRoles;

    public function __construct()
    {
        $this->users = new UserModel();
        $this->roles = new RoleModel();
        $this->permissions = new PermissionModel();
        $this->rolePermissions = new RolePermissionModel();
        $this->userRoles = new UserRoleModel();
    }

    public function index()
    {
        if ($deny = $this->requirePermission('rbac.manage')) return $deny;

        $rows = $this->users
            ->select('users.*, roles.kode AS role_kode, roles.nama AS role_nama, kartu_keluarga.kepala_keluarga')
            ->join('user_roles', 'user_roles.user_id = users.id', 'left')
            ->join('roles', 'roles.id = user_roles.role_id', 'left')
            ->join('kartu_keluarga', 'kartu_keluarga.no_kk = users.no_kk', 'left')
            ->orderBy('users.nama_lengkap', 'ASC')
            ->findAll();

        $roles = $this->roles->where('status', 'aktif')->orderBy('id', 'ASC')->findAll();
        $permissions = $this->permissions->where('status', 'aktif')->orderBy('modul', 'ASC')->orderBy('nama', 'ASC')->findAll();
        $matrix = [];
        foreach ($roles as $role) {
            $matrix[$role['id']] = array_map(
                static fn(array $p): string => (string) $p['kode'],
                $this->rolePermissions->getPermissionsByRole((int) $role['id'])
            );
        }

        return view('akses/index', [
            'title' => 'Manajemen Akses & RBAC',
            'users' => $rows,
            'roles' => $roles,
            'permissions' => $permissions,
            'matrix' => $matrix,
        ]);
    }

    public function createUser()
    {
        if ($deny = $this->requirePermission('rbac.manage')) return $deny;
        return view('akses/user_form', $this->formData(null));
    }

    public function storeUser()
    {
        if ($deny = $this->requirePermission('rbac.manage')) return $deny;

        $data = $this->collectUserData();
        $errors = $this->validateUser($data, null);
        if ($errors) return redirect()->back()->withInput()->with('errors', $errors);

        $role = $this->roles->where('id', (int) $data['role_id'])->where('status', 'aktif')->first();
        if (! $role) return redirect()->back()->withInput()->with('error', 'Role tidak valid.');

        if ($role['kode'] === 'WARGA' && trim((string) $data['no_kk']) === '') {
            return redirect()->back()->withInput()->with('error', 'Akun Warga wajib dihubungkan ke Nomor KK.');
        }
        if ($role['kode'] !== 'WARGA') $data['no_kk'] = null;

        $data['password'] = password_hash($data['password'], PASSWORD_DEFAULT);
        unset($data['role_id']);
        $data['status'] = 'aktif';
        $this->users->insert($data);
        $userId = (int) $this->users->getInsertID();
        $this->userRoles->insert(['user_id' => $userId, 'role_id' => (int) $role['id']]);

        return redirect()->to(site_url('akses'))->with('success', 'User berhasil dibuat dan diberi role ' . $role['nama'] . '.');
    }

    public function editUser(int $id)
    {
        if ($deny = $this->requirePermission('rbac.manage')) return $deny;
        $user = $this->users->find($id);
        if (! $user) return redirect()->to(site_url('akses'))->with('error', 'User tidak ditemukan.');
        $role = $this->userRoles->getPrimaryRole($id);
        $user['role_id'] = $role['id'] ?? null;
        return view('akses/user_form', $this->formData($user));
    }

    public function updateUser(int $id)
    {
        if ($deny = $this->requirePermission('rbac.manage')) return $deny;
        $user = $this->users->find($id);
        if (! $user) return redirect()->to(site_url('akses'))->with('error', 'User tidak ditemukan.');

        $data = $this->collectUserData(true);
        $errors = $this->validateUser($data, $id);
        if ($errors) return redirect()->back()->withInput()->with('errors', $errors);

        $role = $this->roles->where('id', (int) $data['role_id'])->where('status', 'aktif')->first();
        if (! $role) return redirect()->back()->withInput()->with('error', 'Role tidak valid.');

        $self = $id === (int) session()->get('user_id');
        if ($self && (($data['status'] ?? $user['status']) !== 'aktif' || (int) $data['role_id'] !== (int) ($this->userRoles->getPrimaryRole($id)['id'] ?? 0))) {
            return redirect()->back()->withInput()->with('error', 'Akun yang sedang dipakai tidak boleh dinonaktifkan atau dipindahkan role dari halaman ini.');
        }

        if ($role['kode'] === 'WARGA' && trim((string) $data['no_kk']) === '') {
            return redirect()->back()->withInput()->with('error', 'Akun Warga wajib dihubungkan ke Nomor KK.');
        }
        if ($role['kode'] !== 'WARGA') $data['no_kk'] = null;

        $update = [
            'username' => $data['username'],
            'nama_lengkap' => $data['nama_lengkap'],
            'email' => $data['email'] ?: null,
            'status' => $data['status'],
            'no_kk' => $data['no_kk'] ?: null,
        ];
        if ($data['password'] !== '') $update['password'] = password_hash($data['password'], PASSWORD_DEFAULT);
        $this->users->update($id, $update);

        $this->userRoles->where('user_id', $id)->delete();
        $this->userRoles->insert(['user_id' => $id, 'role_id' => (int) $role['id']]);

        return redirect()->to(site_url('akses'))->with('success', 'User berhasil diperbarui.');
    }

    public function updateRolePermissions(int $roleId)
    {
        if ($deny = $this->requirePermission('rbac.manage')) return $deny;
        $role = $this->roles->find($roleId);
        if (! $role) return redirect()->to(site_url('akses'))->with('error', 'Role tidak ditemukan.');

        $requested = array_values(array_unique(array_map('strval', (array) $this->request->getPost('permissions'))));
        $valid = $this->permissions->where('status', 'aktif')->findAll();
        $validCodes = array_map(static fn(array $p): string => (string) $p['kode'], $valid);
        $requested = array_values(array_intersect($requested, $validCodes));

        // Kewenangan yang dikunci oleh aturan bisnis SIMWARGA tidak boleh diubah melalui UI.
        $protected = $this->protectedPermissionCodes();
        foreach ($protected as $code => $allowedRoles) {
            $requested = array_diff($requested, [$code]);
            if (in_array($role['kode'], $allowedRoles, true)) $requested[] = $code;
        }

        $requested = array_values(array_unique($requested));
        $db = db_connect();
        $db->transStart();
        $this->rolePermissions->where('role_id', $roleId)->delete();
        foreach ($requested as $code) {
            $permission = $this->permissions->where('kode', $code)->first();
            if ($permission) $this->rolePermissions->insert(['role_id' => $roleId, 'permission_id' => $permission['id']]);
        }
        $db->transComplete();

        if (! $db->transStatus()) return redirect()->to(site_url('akses'))->with('error', 'Permission role gagal diperbarui.');
        return redirect()->to(site_url('akses'))->with('success', 'Permission role ' . $role['nama'] . ' berhasil diperbarui.');
    }

    private function formData(?array $user): array
    {
        return [
            'title' => $user ? 'Edit User' : 'Tambah User',
            'user' => $user,
            'roles' => $this->roles->where('status', 'aktif')->orderBy('id', 'ASC')->findAll(),
            'kk' => db_connect()->table('kartu_keluarga')->where('status', 'aktif')->orderBy('no_kk', 'ASC')->get()->getResultArray(),
        ];
    }

    private function collectUserData(bool $editing = false): array
    {
        return [
            'username' => trim((string) $this->request->getPost('username')),
            'password' => (string) $this->request->getPost('password'),
            'nama_lengkap' => trim((string) $this->request->getPost('nama_lengkap')),
            'email' => trim((string) $this->request->getPost('email')),
            'status' => trim((string) ($this->request->getPost('status') ?: 'aktif')),
            'role_id' => (int) $this->request->getPost('role_id'),
            'no_kk' => trim((string) $this->request->getPost('no_kk')),
        ];
    }

    private function validateUser(array $data, ?int $id): array
    {
        $errors = [];
        if (mb_strlen($data['username']) < 3 || mb_strlen($data['username']) > 100) $errors['username'] = 'Username 3-100 karakter.';
        $existing = $this->users->where('username', $data['username'])->first();
        if ($existing && (int) $existing['id'] !== (int) $id) $errors['username'] = 'Username sudah digunakan.';
        if ($id === null && mb_strlen($data['password']) < 8) $errors['password'] = 'Password minimal 8 karakter.';
        if ($id !== null && $data['password'] !== '' && mb_strlen($data['password']) < 8) $errors['password'] = 'Password baru minimal 8 karakter.';
        if ($data['nama_lengkap'] === '') $errors['nama_lengkap'] = 'Nama lengkap wajib diisi.';
        if (! in_array($data['status'], ['aktif', 'nonaktif'], true)) $errors['status'] = 'Status tidak valid.';
        if ($data['role_id'] < 1) $errors['role_id'] = 'Role wajib dipilih.';
        if ($data['no_kk'] !== '' && ! db_connect()->table('kartu_keluarga')->where('no_kk', $data['no_kk'])->where('status', 'aktif')->countAllResults()) $errors['no_kk'] = 'Nomor KK tidak ditemukan atau tidak aktif.';
        return $errors;
    }

    private function protectedPermissionCodes(): array
    {
        return [
            'system.backup' => ['ADMINISTRATOR'],
            'system.backup.download' => ['ADMINISTRATOR'],
            'system.backup.history' => ['ADMINISTRATOR'],
            'system.restore' => ['ADMINISTRATOR'],
            'rbac.manage' => ['ADMINISTRATOR'],
            'tagihan_iuran.restore' => ['ADMINISTRATOR', 'KETUA_RT'],
            'tagihan_iuran.cancel' => ['ADMINISTRATOR', 'KETUA_RT', 'BENDAHARA'],
            'pengeluaran.approve' => ['KETUA_RT'],
            'pengeluaran.check' => ['SEKRETARIS'],
        ];
    }
}
