<?php

namespace App\Controllers;

use App\Models\KartuKeluargaModel;
use App\Models\WargaModel;

class KartuKeluarga extends BaseController
{
    protected KartuKeluargaModel $kkModel;
    protected WargaModel $wargaModel;

    public function __construct()
    {
        $this->kkModel = new KartuKeluargaModel();
        $this->wargaModel = new WargaModel();
    }

    public function index()
    {
        return view('kartu_keluarga/index', [
            'title' => 'Data Kartu Keluarga',
            'kk' => $this->kkModel
                ->orderBy('no_kk', 'ASC')
                ->findAll(),
        ]);
    }

    public function detail(int $id)
    {
        $kk = $this->kkModel->find($id);

        if (! $kk) {
            return redirect()->to(site_url('kartu-keluarga'))
                ->with('error', 'Data Kartu Keluarga tidak ditemukan.');
        }

        $anggota = $this->wargaModel
            ->where('no_kk', $kk['no_kk'])
            ->orderBy('hubungan_keluarga', 'ASC')
            ->orderBy('nama_lengkap', 'ASC')
            ->findAll();

        return view('kartu_keluarga/detail', [
            'title' => 'Detail Kartu Keluarga',
            'kk' => $kk,
            'anggota' => $anggota,
        ]);
    }

    public function create()
    {
        return view('kartu_keluarga/create', [
            'title' => 'Tambah Kartu Keluarga',
        ]);
    }

    public function store()
    {
        $data = $this->collectKKData();
        $dataWarga = $this->collectKepalaData($data['no_kk'], $data['kepala_keluarga']);

        // Validasi KK menggunakan aturan model yang sesuai dengan database.
        if (! $this->kkModel->validate($data)) {
            return redirect()->back()->withInput()
                ->with('errors', $this->kkModel->errors());
        }

        if (! $this->validateKepala($dataWarga)) {
            return redirect()->back()->withInput()
                ->with('errors', $this->wargaModel->errors());
        }

        if ($this->kkModel->where('no_kk', $data['no_kk'])->first()) {
            return redirect()->back()->withInput()
                ->with('errors', ['no_kk' => 'Nomor KK tersebut sudah terdaftar.']);
        }

        if ($this->wargaModel->where('nik', $dataWarga['nik'])->first()) {
            return redirect()->back()->withInput()
                ->with('errors', ['nik' => 'NIK tersebut sudah terdaftar sebagai warga.']);
        }

        $db = db_connect();
        $db->transStart();

        $kkSaved = $this->kkModel->insert($data);
        if (! $kkSaved) {
            $db->transRollback();
            return redirect()->back()->withInput()
                ->with('errors', $this->kkModel->errors());
        }

        $wargaSaved = $this->wargaModel->insert($dataWarga);
        if (! $wargaSaved) {
            $db->transRollback();
            return redirect()->back()->withInput()
                ->with('errors', $this->wargaModel->errors());
        }

        $db->transComplete();

        if ($db->transStatus() === false) {
            return redirect()->back()->withInput()
                ->with('error', 'Data KK dan Kepala Keluarga gagal disimpan.');
        }

        return redirect()->to(site_url('kartu-keluarga'))
            ->with('success', 'Data Kartu Keluarga dan Kepala Keluarga berhasil ditambahkan.');
    }

    public function edit(int $id)
    {
        $kk = $this->kkModel->find($id);

        if (! $kk) {
            return redirect()->to(site_url('kartu-keluarga'))
                ->with('error', 'Data Kartu Keluarga tidak ditemukan.');
        }

        $kepala = $this->wargaModel
            ->where('no_kk', $kk['no_kk'])
            ->where('hubungan_keluarga', 'KEPALA_KELUARGA')
            ->first();

        return view('kartu_keluarga/edit', [
            'title' => 'Edit Kartu Keluarga',
            'kk' => $kk,
            'nikKepalaKeluarga' => $kepala['nik'] ?? '',
            'jenisKelaminKepalaKeluarga' => $kepala['jenis_kelamin'] ?? '',
            'tanggalLahirKepalaKeluarga' => $kepala['tanggal_lahir'] ?? '',
            'tempatLahirKepalaKeluarga' => $kepala['tempat_lahir'] ?? '',
            'agamaKepalaKeluarga' => $kepala['agama'] ?? '',
            'pendidikanKepalaKeluarga' => $kepala['pendidikan'] ?? '',
            'pekerjaanKepalaKeluarga' => $kepala['pekerjaan'] ?? '',
            'noHpKepalaKeluarga' => $kepala['no_hp'] ?? '',
            'statusPerkawinanKepalaKeluarga' => $kepala['status_perkawinan'] ?? 'BELUM_KAWIN',
        ]);
    }

    public function update(int $id)
    {
        $kkLama = $this->kkModel->find($id);

        if (! $kkLama) {
            return redirect()->to(site_url('kartu-keluarga'))
                ->with('error', 'Data Kartu Keluarga tidak ditemukan.');
        }

        $data = $this->collectKKData();
        $data['no_hp'] = trim((string) ($this->request->getPost('no_hp_kepala_keluarga') ?? $kkLama['no_hp'] ?? ''));
        $kepalaLama = $this->wargaModel
            ->where('no_kk', $kkLama['no_kk'])
            ->where('hubungan_keluarga', 'KEPALA_KELUARGA')
            ->first();

        if (! $this->kkModel->validate($data)) {
            return redirect()->back()->withInput()
                ->with('errors', $this->kkModel->errors());
        }

        $dataWarga = $this->collectKepalaData(
            $data['no_kk'],
            $data['kepala_keluarga']
        );

        if (! $this->validateKepala($dataWarga)) {
            return redirect()->back()->withInput()
                ->with('errors', $this->wargaModel->errors());
        }

        $wargaDenganNik = $this->wargaModel
            ->where('nik', $dataWarga['nik'])
            ->first();

        if ($wargaDenganNik && (int) $wargaDenganNik['id'] !== (int) ($kepalaLama['id'] ?? 0)) {
            return redirect()->back()->withInput()
                ->with('errors', [
                    'nik_kepala_keluarga' => 'NIK tersebut sudah digunakan oleh warga lain.'
                ]);
        }

        // Jika nomor KK berubah, pastikan tidak bentrok dan sinkronkan seluruh anggota.
        if ($data['no_kk'] !== $kkLama['no_kk']
            && $this->kkModel->where('no_kk', $data['no_kk'])->first()) {
            return redirect()->back()->withInput()
                ->with('errors', ['no_kk' => 'Nomor KK baru sudah digunakan oleh KK lain.']);
        }

        $db = db_connect();
        $db->transStart();

        if (! $this->kkModel->update($id, $data)) {
            $db->transRollback();
            return redirect()->back()->withInput()
                ->with('errors', $this->kkModel->errors());
        }

        if ($kepalaLama) {
            if (! $this->wargaModel->update($kepalaLama['id'], $dataWarga)) {
                $db->transRollback();
                return redirect()->back()->withInput()
                    ->with('errors', $this->wargaModel->errors());
            }
        } else {
            if (! $this->wargaModel->insert($dataWarga)) {
                $db->transRollback();
                return redirect()->back()->withInput()
                    ->with('errors', $this->wargaModel->errors());
            }
        }

        // Menjaga relasi anggota keluarga jika nomor KK berubah.
        if ($data['no_kk'] !== $kkLama['no_kk']) {
            $this->wargaModel
                ->where('no_kk', $kkLama['no_kk'])
                ->where('id !=', (int) ($kepalaLama['id'] ?? 0))
                ->set(['no_kk' => $data['no_kk']])
                ->update();
        }

        $db->transComplete();

        if ($db->transStatus() === false) {
            return redirect()->back()->withInput()
                ->with('error', 'Data KK dan Kepala Keluarga gagal diperbarui.');
        }

        return redirect()->to(site_url('kartu-keluarga/detail/' . $id))
            ->with('success', 'Data KK dan Kepala Keluarga berhasil diperbarui.');
    }

    public function delete(int $id)
    {
        $kk = $this->kkModel->find($id);

        if (! $kk) {
            return redirect()->to(site_url('kartu-keluarga'))
                ->with('error', 'Data Kartu Keluarga tidak ditemukan.');
        }

        if (($kk['status'] ?? '') === 'nonaktif') {
            return redirect()->to(site_url('kartu-keluarga'))
                ->with('error', 'Kartu Keluarga sudah berstatus nonaktif.');
        }

        $db = db_connect();
        $db->transStart();

        $this->kkModel->update($id, ['status' => 'nonaktif']);

        // Pertahankan perilaku lama: kepala keluarga ikut dinonaktifkan.
        $this->wargaModel
            ->where('no_kk', $kk['no_kk'])
            ->where('hubungan_keluarga', 'KEPALA_KELUARGA')
            ->set(['status' => 'nonaktif'])
            ->update();

        $db->transComplete();

        if ($db->transStatus() === false) {
            return redirect()->to(site_url('kartu-keluarga'))
                ->with('error', 'Data Kartu Keluarga gagal dinonaktifkan.');
        }

        return redirect()->to(site_url('kartu-keluarga'))
            ->with('success', 'Kartu Keluarga dan Kepala Keluarga berhasil dinonaktifkan.');
    }

    private function collectKKData(): array
    {
        return [
            'no_kk' => trim((string) $this->request->getPost('no_kk')),
            'kepala_keluarga' => trim((string) $this->request->getPost('kepala_keluarga')),
            'kode_wilayah' => trim((string) $this->request->getPost('kode_wilayah')),
            'no_hp' => trim((string) $this->request->getPost('no_hp')),
            'alamat' => trim((string) $this->request->getPost('alamat')),
            'status' => $this->request->getPost('status') ?: 'aktif',
        ];
    }

    private function collectKepalaData(string $noKK, string $nama): array
    {
        return [
            'nik' => trim((string) $this->request->getPost('nik_kepala_keluarga') ?: $this->request->getPost('nik')),
            'no_kk' => $noKK,
            'nama_lengkap' => $nama,
            'jenis_kelamin' => trim((string) ($this->request->getPost('jenis_kelamin_kepala_keluarga') ?: $this->request->getPost('jenis_kelamin'))),
            'tempat_lahir' => trim((string) ($this->request->getPost('tempat_lahir_kepala_keluarga') ?: $this->request->getPost('tempat_lahir'))),
            'tanggal_lahir' => $this->request->getPost('tanggal_lahir_kepala_keluarga') ?: ($this->request->getPost('tanggal_lahir') ?: null),
            'agama' => trim((string) ($this->request->getPost('agama_kepala_keluarga') ?: $this->request->getPost('agama'))),
            'pendidikan' => trim((string) ($this->request->getPost('pendidikan_kepala_keluarga') ?: $this->request->getPost('pendidikan'))),
            'pekerjaan' => trim((string) ($this->request->getPost('pekerjaan_kepala_keluarga') ?: $this->request->getPost('pekerjaan'))),
            'no_hp' => trim((string) ($this->request->getPost('no_hp_kepala_keluarga') ?: $this->request->getPost('no_hp'))),
            'hubungan_keluarga' => 'KEPALA_KELUARGA',
            'status_perkawinan' => trim((string) ($this->request->getPost('status_perkawinan_kepala_keluarga') ?: $this->request->getPost('status_perkawinan') ?: 'BELUM_KAWIN')),
            'status' => 'aktif',
        ];
    }

    private function validateKepala(array $dataWarga): bool
    {
        return $this->wargaModel->validate($dataWarga);
    }
}
