<?php

namespace App\Controllers;

use App\Models\MasterWilayahModel;

class MasterWilayah extends BaseController
{
    protected MasterWilayahModel $masterWilayahModel;

    public function __construct()
    {
        $this->masterWilayahModel = new MasterWilayahModel();
    }

    public function index()
    {
        $data = [
            'title'    => 'Master Wilayah',
            'wilayah'  => $this->masterWilayahModel
                ->orderBy('jenis', 'ASC')
                ->orderBy('nama', 'ASC')
                ->findAll(),
        ];

        return view('master_wilayah/index', $data);
    }
}