<?php

namespace App\Controllers;

use App\Models\JenisIuranModel;

class JenisIuran extends BaseController
{
    protected JenisIuranModel $jenisIuranModel;

    public function __construct()
    {
        $this->jenisIuranModel = new JenisIuranModel();
    }

    /**
     * Daftar jenis iuran.
     */
    public function index()
    {
        $data = [
            'title' => 'Jenis Iuran',

            'jenisIuran' => $this->jenisIuranModel
                ->orderBy('nama_iuran', 'ASC')
                ->findAll(),
        ];

        return view('jenis_iuran/index', $data);
    }

    /**
     * Form tambah jenis iuran.
     */
    public function create()
    {
        $data = [
            'title' => 'Tambah Jenis Iuran',
        ];

        return view('jenis_iuran/create', $data);
    }

    /**
     * Simpan jenis iuran baru.
     */
    public function store()
    {
        $data = $this->request->getPost();

        // Bersihkan input
        $data['kode_iuran'] = strtoupper(
            trim((string) ($data['kode_iuran'] ?? ''))
        );

        $data['nama_iuran'] = trim(
            (string) ($data['nama_iuran'] ?? '')
        );

        $data['deskripsi'] = trim(
            (string) ($data['deskripsi'] ?? '')
        );

        $data['nominal'] = trim(
            (string) ($data['nominal'] ?? '0')
        );

        $data['sifat_iuran'] = trim(
            (string) ($data['sifat_iuran'] ?? 'wajib')
        );

        $data['periode'] = trim(
            (string) ($data['periode'] ?? 'bulanan')
        );

        $data['tanggal_mulai'] = trim(
            (string) ($data['tanggal_mulai'] ?? '')
        );

        $data['status'] = trim(
            (string) ($data['status'] ?? 'aktif')
        );

        // Jika tanggal kosong, simpan NULL
        if ($data['tanggal_mulai'] === '') {
            $data['tanggal_mulai'] = null;
        }

        // Jika deskripsi kosong, simpan NULL
        if ($data['deskripsi'] === '') {
            $data['deskripsi'] = null;
        }

        if ($this->jenisIuranModel->where('kode_iuran', $data['kode_iuran'])->first()) {
            return redirect()->back()
                ->withInput()
                ->with('errors', [
                    'kode_iuran' => 'Kode iuran tersebut sudah terdaftar.'
                ]);
        }

        if (! $this->jenisIuranModel->insert($data)) {

            return redirect()
                ->back()
                ->withInput()
                ->with(
                    'errors',
                    $this->jenisIuranModel->errors()
                );
        }

        return redirect()
            ->to(site_url('jenis-iuran'))
            ->with(
                'success',
                'Jenis iuran berhasil ditambahkan.'
            );
    }

    /**
     * Form edit jenis iuran.
     */
    public function edit(int $id)
    {
        $jenisIuran = $this->jenisIuranModel->find($id);

        if (! $jenisIuran) {

            return redirect()
                ->to(site_url('jenis-iuran'))
                ->with(
                    'error',
                    'Data jenis iuran tidak ditemukan.'
                );
        }

        $data = [
            'title' => 'Edit Jenis Iuran',
            'jenisIuran' => $jenisIuran,
        ];

        return view('jenis_iuran/edit', $data);
    }

    /**
     * Update jenis iuran.
     */
    public function update(int $id)
    {
        $jenisIuran = $this->jenisIuranModel->find($id);

        if (! $jenisIuran) {

            return redirect()
                ->to(site_url('jenis-iuran'))
                ->with(
                    'error',
                    'Data jenis iuran tidak ditemukan.'
                );
        }

        $data = $this->request->getPost();

        // Bersihkan input
        $data['kode_iuran'] = strtoupper(
            trim((string) ($data['kode_iuran'] ?? ''))
        );

        $data['nama_iuran'] = trim(
            (string) ($data['nama_iuran'] ?? '')
        );

        $data['deskripsi'] = trim(
            (string) ($data['deskripsi'] ?? '')
        );

        $data['nominal'] = trim(
            (string) ($data['nominal'] ?? '0')
        );

        $data['sifat_iuran'] = trim(
            (string) ($data['sifat_iuran'] ?? 'wajib')
        );

        $data['periode'] = trim(
            (string) ($data['periode'] ?? 'bulanan')
        );

        $data['tanggal_mulai'] = trim(
            (string) ($data['tanggal_mulai'] ?? '')
        );

        $data['status'] = trim(
            (string) ($data['status'] ?? 'aktif')
        );

        // Jika tanggal kosong, simpan NULL
        if ($data['tanggal_mulai'] === '') {
            $data['tanggal_mulai'] = null;
        }

        // Jika deskripsi kosong, simpan NULL
        if ($data['deskripsi'] === '') {
            $data['deskripsi'] = null;
        }

        $kodeLain = $this->jenisIuranModel
            ->where('kode_iuran', $data['kode_iuran'])
            ->where('id !=', $id)
            ->first();

        if ($kodeLain) {
            return redirect()->back()
                ->withInput()
                ->with('errors', [
                    'kode_iuran' => 'Kode iuran tersebut sudah digunakan oleh data lain.'
                ]);
        }

        if (! $this->jenisIuranModel->update($id, $data)) {

            return redirect()
                ->back()
                ->withInput()
                ->with(
                    'errors',
                    $this->jenisIuranModel->errors()
                );
        }

        return redirect()
            ->to(site_url('jenis-iuran'))
            ->with(
                'success',
                'Jenis iuran berhasil diperbarui.'
            );
    }

    /**
     * Nonaktifkan jenis iuran.
     *
     * Data tidak dihapus secara permanen.
     */
    public function delete(int $id)
    {
        $jenisIuran = $this->jenisIuranModel->find($id);

        if (! $jenisIuran) {

            return redirect()
                ->to(site_url('jenis-iuran'))
                ->with(
                    'error',
                    'Data jenis iuran tidak ditemukan.'
                );
        }

        // Jika sudah nonaktif
        if (($jenisIuran['status'] ?? '') === 'nonaktif') {

            return redirect()
                ->to(site_url('jenis-iuran'))
                ->with(
                    'error',
                    'Jenis iuran sudah berstatus nonaktif.'
                );
        }

        if (! $this->jenisIuranModel->update($id, [
            'status' => 'nonaktif',
        ])) {

            return redirect()
                ->to(site_url('jenis-iuran'))
                ->with(
                    'error',
                    'Jenis iuran gagal dinonaktifkan.'
                );
        }

        return redirect()
            ->to(site_url('jenis-iuran'))
            ->with(
                'success',
                'Jenis iuran berhasil dinonaktifkan.'
            );
    }
}