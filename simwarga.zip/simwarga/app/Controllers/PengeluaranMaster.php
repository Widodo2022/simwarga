<?php
namespace App\Controllers;
use App\Models\PengeluaranKategoriModel; use App\Models\PengeluaranPenerimaModel; use App\Models\SumberDanaModel;
class PengeluaranMaster extends BaseController
{
 public function index(){return view('pengeluaran/master',['title'=>'Master Pengeluaran','kategori'=>(new PengeluaranKategoriModel())->findAll(),'penerima'=>(new PengeluaranPenerimaModel())->findAll(),'sumber'=>(new SumberDanaModel())->findAll()]);}
 public function saveKategori(){if(!$this->hasPermission('pengeluaran.master.manage'))return $this->denyPermission('pengeluaran.master.manage');$m=new PengeluaranKategoriModel();$m->insert(['kode'=>trim((string)$this->request->getPost('kode')),'nama'=>trim((string)$this->request->getPost('nama')),'status'=>'aktif']);return redirect()->back()->with('success','Kategori ditambahkan.');}
 public function savePenerima(){if(!$this->hasPermission('pengeluaran.master.manage'))return $this->denyPermission('pengeluaran.master.manage');$m=new PengeluaranPenerimaModel();$m->insert(['nama'=>trim((string)$this->request->getPost('nama')),'kontak'=>trim((string)$this->request->getPost('kontak'))?:null,'status'=>'aktif']);return redirect()->back()->with('success','Penerima ditambahkan.');}
 public function saveSumber(){if(!$this->hasPermission('pengeluaran.master.manage'))return $this->denyPermission('pengeluaran.master.manage');$m=new SumberDanaModel();$m->insert(['kode'=>trim((string)$this->request->getPost('kode')),'nama'=>trim((string)$this->request->getPost('nama')),'status'=>'aktif']);return redirect()->back()->with('success','Sumber dana ditambahkan.');}
}
