<?php

namespace App\Controllers;

use CodeIgniter\HTTP\Files\UploadedFile;
use CodeIgniter\HTTP\ResponseInterface;
use Config\Database as DatabaseConfig;

class Backup extends BaseController
{
    private const MAX_SQL_BYTES = 100 * 1024 * 1024;
    private const MAX_SOURCE_BYTES = 500 * 1024 * 1024;

    public function index()
    {
        if (! $this->isAdministrator()) {
            return $this->denyPermission('system.backup');
        }

        $dir = $this->backupDirectory();
        $files = [];
        if (is_dir($dir)) {
            foreach (glob($dir . DIRECTORY_SEPARATOR . '*') ?: [] as $file) {
                if (! is_file($file)) {
                    continue;
                }
                $files[] = [
                    'name' => basename($file),
                    'size' => filesize($file) ?: 0,
                    'date' => date('Y-m-d H:i:s', filemtime($file) ?: time()),
                ];
            }
        }
        usort($files, static fn ($a, $b) => strcmp($b['date'], $a['date']));

        return view('backup/index', [
            'title' => 'Backup & Restore Sistem',
            'files' => $files,
        ]);
    }

    public function createDatabase()
    {
        if (! $this->isAdministrator()) {
            return $this->denyPermission('system.backup');
        }

        try {
            $this->ensureBackupDirectory();
            $db = $this->dbConfig();
            $filename = 'database_' . date('Ymd_His') . '.sql';
            $path = $this->backupDirectory() . DIRECTORY_SEPARATOR . $filename;
            $command = $this->mysqlTool('mysqldump')
                . ' --single-transaction --quick --routines --triggers'
                . ' --host=' . escapeshellarg($db['hostname'])
                . ' --port=' . (int) $db['port']
                . ' --user=' . escapeshellarg($db['username'])
                . ($db['password'] !== '' ? ' --password=' . escapeshellarg($db['password']) : '')
                . ' ' . escapeshellarg($db['database'])
                . ' > ' . escapeshellarg($path) . ' 2> ' . escapeshellarg($path . '.err');

            $exit = 0;
            exec($command, $output, $exit);
            if ($exit !== 0 || ! is_file($path) || filesize($path) === 0) {
                $error = is_file($path . '.err') ? trim((string) file_get_contents($path . '.err')) : 'mysqldump gagal.';
                @unlink($path);
                @unlink($path . '.err');
                throw new \RuntimeException($error ?: 'Backup database gagal.');
            }
            @unlink($path . '.err');

            $this->audit('backup.database', 'Backup Sistem', $filename);
            return redirect()->back()->with('success', 'Backup database berhasil dibuat: ' . $filename);
        } catch (\Throwable $e) {
            return redirect()->back()->with('error', 'Backup database gagal: ' . $e->getMessage());
        }
    }

    public function createSource()
    {
        if (! $this->isAdministrator()) {
            return $this->denyPermission('system.backup');
        }

        try {
            $this->ensureBackupDirectory();
            $filename = 'source_' . date('Ymd_His') . '.tar.gz';
            $path = $this->backupDirectory() . DIRECTORY_SEPARATOR . $filename;
            $root = rtrim(ROOTPATH, DIRECTORY_SEPARATOR);
            $parent = dirname($root);
            $project = basename($root);

            $command = 'tar -czf ' . escapeshellarg($path)
                . ' --exclude=' . escapeshellarg($project . '/writable/cache/*')
                . ' --exclude=' . escapeshellarg($project . '/writable/logs/*')
                . ' --exclude=' . escapeshellarg($project . '/writable/debugbar/*')
                . ' --exclude=' . escapeshellarg($project . '/writable/backups/*')
                . ' --exclude=' . escapeshellarg($project . '/.git')
                . ' -C ' . escapeshellarg($parent) . ' ' . escapeshellarg($project);

            $exit = 0;
            exec($command, $output, $exit);
            if ($exit !== 0 || ! is_file($path) || filesize($path) === 0) {
                @unlink($path);
                throw new \RuntimeException('Backup source aplikasi gagal.');
            }

            $this->audit('backup.source', 'Backup Sistem', $filename);
            return redirect()->back()->with('success', 'Backup source aplikasi berhasil dibuat: ' . $filename);
        } catch (\Throwable $e) {
            return redirect()->back()->with('error', 'Backup source aplikasi gagal: ' . $e->getMessage());
        }
    }

    public function download(string $filename)
    {
        if (! $this->isAdministrator()) {
            return $this->denyPermission('system.backup.download');
        }

        $filename = basename($filename);
        $path = $this->backupDirectory() . DIRECTORY_SEPARATOR . $filename;
        if (! is_file($path)) {
            return redirect()->back()->with('error', 'File backup tidak ditemukan.');
        }

        return $this->response->download($path, null);
    }

    public function restoreDatabase()
    {
        if (! $this->isAdministrator()) {
            return $this->denyPermission('system.restore');
        }

        /** @var UploadedFile|null $file */
        $file = $this->request->getFile('backup_file');
        if (! $file || ! $file->isValid()) {
            return redirect()->back()->with('error', 'File SQL backup wajib dipilih.');
        }
        if ($file->getSize() > self::MAX_SQL_BYTES) {
            return redirect()->back()->with('error', 'File SQL terlalu besar. Maksimal 100 MB.');
        }
        if (strtolower($file->getClientExtension()) !== 'sql') {
            return redirect()->back()->with('error', 'Restore database hanya menerima file .sql.');
        }

        try {
            $this->ensureBackupDirectory();
            // Selalu buat emergency backup sebelum restore.
            $this->runDatabaseBackup('before_restore_' . date('Ymd_His'));

            $tmpName = 'restore_' . bin2hex(random_bytes(8)) . '.sql';
            $file->move($this->backupDirectory(), $tmpName);
            $tmp = $this->backupDirectory() . DIRECTORY_SEPARATOR . $tmpName;

            $db = $this->dbConfig();
            $command = $this->mysqlTool('mysql')
                . ' --host=' . escapeshellarg($db['hostname'])
                . ' --port=' . (int) $db['port']
                . ' --user=' . escapeshellarg($db['username'])
                . ($db['password'] !== '' ? ' --password=' . escapeshellarg($db['password']) : '')
                . ' ' . escapeshellarg($db['database'])
                . ' < ' . escapeshellarg($tmp) . ' 2> ' . escapeshellarg($tmp . '.err');

            $exit = 0;
            exec($command, $output, $exit);
            $error = is_file($tmp . '.err') ? trim((string) file_get_contents($tmp . '.err')) : '';
            @unlink($tmp);
            @unlink($tmp . '.err');
            if ($exit !== 0) {
                throw new \RuntimeException($error ?: 'Restore database gagal.');
            }

            $this->audit('restore.database', 'Restore Sistem', $file->getClientName());
            session()->destroy();
            return redirect()->to(site_url('login'))->with('success', 'Database berhasil direstore. Silakan login kembali.');
        } catch (\Throwable $e) {
            return redirect()->back()->with('error', 'Restore database gagal: ' . $e->getMessage());
        }
    }

    public function restoreSource()
    {
        if (! $this->isAdministrator()) {
            return $this->denyPermission('system.restore');
        }

        /** @var UploadedFile|null $file */
        $file = $this->request->getFile('backup_file');
        if (! $file || ! $file->isValid()) {
            return redirect()->back()->with('error', 'File source backup wajib dipilih.');
        }
        if ($file->getSize() > self::MAX_SOURCE_BYTES) {
            return redirect()->back()->with('error', 'File source terlalu besar. Maksimal 500 MB.');
        }
        if (! in_array(strtolower($file->getClientExtension()), ['gz', 'tgz', 'tar'], true)) {
            return redirect()->back()->with('error', 'Restore source menerima arsip .tar.gz/.tgz/.tar.');
        }

        // Demi keselamatan, restore source tidak menimpa aplikasi yang sedang berjalan dari request web.
        // Arsip disimpan sebagai paket restore dan administrator mendapat instruksi lokasi file.
        try {
            $this->ensureBackupDirectory();
            $safe = 'restore_source_' . date('Ymd_His') . '_' . bin2hex(random_bytes(4)) . '.tar.gz';
            $file->move($this->backupDirectory(), $safe);
            $this->audit('restore.source.prepare', 'Restore Sistem', $file->getClientName());
            return redirect()->back()->with('success', 'Paket source restore sudah diamankan di writable/backups/system/' . $safe . '. Untuk keamanan, file aplikasi aktif tidak ditimpa melalui web. Gunakan prosedur restore server setelah backup ini diverifikasi.');
        } catch (\Throwable $e) {
            return redirect()->back()->with('error', 'Menyiapkan source restore gagal: ' . $e->getMessage());
        }
    }

    private function isAdministrator(): bool
    {
        return session()->get('isLoggedIn') === true
            && in_array((string) session()->get('role_kode'), ['ADMINISTRATOR', 'ADMIN'], true)
            && $this->hasPermission('system.backup');
    }

    private function backupDirectory(): string
    {
        return WRITEPATH . 'backups' . DIRECTORY_SEPARATOR . 'system';
    }

    private function ensureBackupDirectory(): void
    {
        $dir = $this->backupDirectory();
        if (! is_dir($dir) && ! mkdir($dir, 0770, true) && ! is_dir($dir)) {
            throw new \RuntimeException('Folder backup tidak dapat dibuat.');
        }
    }

    private function mysqlTool(string $name): string
    {
        $candidates = [
            '/opt/lampp/bin/' . $name,
            $name,
        ];
        foreach ($candidates as $candidate) {
            if ($candidate === $name || is_executable($candidate)) {
                return escapeshellcmd($candidate);
            }
        }
        throw new \RuntimeException($name . ' tidak tersedia.');
    }

    private function dbConfig(): array
    {
        $config = config(DatabaseConfig::class);
        return [
            'hostname' => (string) ($config->default['hostname'] ?? env('database.default.hostname', '127.0.0.1')),
            'username' => (string) ($config->default['username'] ?? env('database.default.username', 'root')),
            'password' => (string) ($config->default['password'] ?? env('database.default.password', '')),
            'database' => (string) ($config->default['database'] ?? env('database.default.database', '')),
            'port' => (int) ($config->default['port'] ?? env('database.default.port', 3306)),
        ];
    }

    private function runDatabaseBackup(string $prefix): void
    {
        $this->ensureBackupDirectory();
        $db = $this->dbConfig();
        $path = $this->backupDirectory() . DIRECTORY_SEPARATOR . $prefix . '.sql';
        $command = $this->mysqlTool('mysqldump')
            . ' --single-transaction --quick --routines --triggers'
            . ' --host=' . escapeshellarg($db['hostname'])
            . ' --port=' . (int) $db['port']
            . ' --user=' . escapeshellarg($db['username'])
            . ($db['password'] !== '' ? ' --password=' . escapeshellarg($db['password']) : '')
            . ' ' . escapeshellarg($db['database'])
            . ' > ' . escapeshellarg($path);
        $exit = 0;
        exec($command, $output, $exit);
        if ($exit !== 0 || ! is_file($path) || filesize($path) === 0) {
            @unlink($path);
            throw new \RuntimeException('Backup otomatis sebelum restore gagal. Restore dibatalkan.');
        }
    }

    private function audit(string $aksi, string $modul, string $referensi): void
    {
        if (! $this->db->tableExists('audit_log')) {
            return;
        }
        $this->db->table('audit_log')->insert([
            'user_id' => (int) session()->get('user_id'),
            'aksi' => $aksi,
            'modul' => $modul,
            'referensi_id' => $referensi,
            'ringkasan' => 'Administrator melakukan ' . $aksi . ': ' . $referensi,
            'created_at' => date('Y-m-d H:i:s'),
        ]);
    }
}
