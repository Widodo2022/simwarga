<?php

namespace App\Controllers;

use App\Models\JenisIuranModel;
use App\Models\KartuKeluargaModel;
use App\Models\TagihanIuranModel;
use App\Models\WargaModel;

class Laporan extends BaseController
{
    public function index()
    {
        $tagihan = new TagihanIuranModel();

        return view('laporan/index', [
            'title' => 'Laporan',
            'totalKK' => (new KartuKeluargaModel())->where('status', 'aktif')->countAllResults(),
            'totalWarga' => (new WargaModel())->where('status', 'aktif')->countAllResults(),
            'totalJenisIuran' => (new JenisIuranModel())->where('status', 'aktif')->countAllResults(),
            'totalTagihan' => $tagihan->getTotalTagihan(),
            'nominalTagihan' => $tagihan->getTotalNominal(),
            'nominalLunas' => $tagihan->getTotalNominalLunas(),
            'nominalBelumBayar' => $tagihan->getTotalNominalBelumBayar(),
            'tagihan' => $tagihan->getTagihanLengkap(),
        ]);
    }
}
