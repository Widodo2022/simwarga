<?php

namespace App\Controllers;

use App\Models\WargaModel;
use App\Models\KartuKeluargaModel;


class Warga extends BaseController
{
    protected WargaModel $wargaModel;
    protected KartuKeluargaModel $kkModel;


    public function __construct()
    {
        $this->wargaModel = new WargaModel();
        $this->kkModel    = new KartuKeluargaModel();
    }


    /**
     * Daftar warga.
     */
    public function index()
    {
        $data = [
            'title' => 'Data Warga',

            'warga' => $this->wargaModel
                ->select('warga.*, kartu_keluarga.kode_wilayah, kartu_keluarga.alamat')
                ->join(
                    'kartu_keluarga',
                    'kartu_keluarga.no_kk = warga.no_kk',
                    'left'
                )
                ->orderBy('warga.nama_lengkap', 'ASC')
                ->findAll(),
        ];


        return view('warga/index', $data);
    }


    /**
     * Form tambah warga.
     */
    public function create()
    {
        $noKk = trim((string) $this->request->getGet('no_kk'));


        $namaLengkap = trim(
            (string) $this->request->getGet('nama_lengkap')
        );


        $hubunganKeluarga = trim(
            (string) $this->request->getGet('hubungan_keluarga')
        );


        $data = [
            'title' => 'Tambah Warga',


            'kk' => $this->kkModel
                ->where('status', 'aktif')
                ->orderBy('no_kk', 'ASC')
                ->findAll(),


            'no_kk' => $noKk,
            'nama_lengkap' => $namaLengkap,
            'hubungan_keluarga' => $hubunganKeluarga,
        ];


        return view('warga/create', $data);
    }


    /**
     * Simpan warga baru.
     */
    public function store()
    {
        $data = $this->request->getPost();


        // Nomor HP
        $data['no_hp'] = trim((string) ($data['no_hp'] ?? ''));


        // Upload KTP
        $fileKtp = $this->request->getFile('lampiran_ktp');


        if ($fileKtp && $fileKtp->isValid() && ! $fileKtp->hasMoved()) {


            // Validasi tipe dan ukuran file
            $validation = [
                'lampiran_ktp' => [
                    'label' => 'Lampiran KTP',
                    'rules' => 'uploaded[lampiran_ktp]|max_size[lampiran_ktp,5120]|ext_in[lampiran_ktp,jpg,jpeg,png,pdf,webp]',
                ],
            ];


            if (! $this->validate($validation)) {
                return redirect()
                    ->back()
                    ->withInput()
                    ->with('errors', $this->validator->getErrors());
            }


            // Buat nama file unik
            $newName = $fileKtp->getRandomName();


            // Pastikan folder upload tersedia.
            $uploadDir = WRITEPATH . 'uploads/warga';
            if (! is_dir($uploadDir)) {
                mkdir($uploadDir, 0755, true);
            }

            $fileKtp->move($uploadDir, $newName);


            // Simpan nama file ke database
            $data['lampiran_ktp'] = $newName;
        }


        if (! $this->wargaModel->insert($data)) {


            // Jika database gagal menyimpan, hapus file yang sudah diupload
            if (! empty($data['lampiran_ktp'])) {
                $filePath = WRITEPATH . 'uploads/warga/' . $data['lampiran_ktp'];


                if (is_file($filePath)) {
                    unlink($filePath);
                }
            }


            return redirect()
                ->back()
                ->withInput()
                ->with('errors', $this->wargaModel->errors());
        }


        return redirect()
            ->to(site_url('warga'))
            ->with('success', 'Data warga berhasil ditambahkan.');
    }


    /**
     * Form edit warga.
     */
    public function edit(int $id)
    {
        $warga = $this->wargaModel->find($id);


        if (! $warga) {
            return redirect()
                ->to(site_url('warga'))
                ->with('error', 'Data warga tidak ditemukan.');
        }


        $data = [
            'title' => 'Edit Warga',
            'warga' => $warga,
            'kk'    => $this->kkModel
                ->where('status', 'aktif')
                ->orderBy('no_kk', 'ASC')
                ->findAll(),
        ];


        return view('warga/edit', $data);
    }


    /**
     * Update warga.
     */
    public function update(int $id)
    {
        $warga = $this->wargaModel->find($id);


        if (! $warga) {
            return redirect()
                ->to(site_url('warga'))
                ->with('error', 'Data warga tidak ditemukan.');
        }


        $data = $this->request->getPost();


        // Nomor HP
        $data['no_hp'] = trim((string) ($data['no_hp'] ?? ''));


        // File KTP baru
        $fileKtp = $this->request->getFile('lampiran_ktp');


        if ($fileKtp && $fileKtp->isValid() && ! $fileKtp->hasMoved()) {


            // Validasi file KTP
            $validation = [
                'lampiran_ktp' => [
                    'label' => 'Lampiran KTP',
                    'rules' => 'uploaded[lampiran_ktp]|max_size[lampiran_ktp,5120]|ext_in[lampiran_ktp,jpg,jpeg,png,pdf]',
                ],
            ];


            if (! $this->validate($validation)) {
                return redirect()
                    ->back()
                    ->withInput()
                    ->with('errors', $this->validator->getErrors());
            }


            // Simpan file dengan nama acak
            $newName = $fileKtp->getRandomName();


            $uploadDir = WRITEPATH . 'uploads/warga';
            if (! is_dir($uploadDir)) {
                mkdir($uploadDir, 0755, true);
            }

            $fileKtp->move($uploadDir, $newName);


            // Simpan nama file baru
            $data['lampiran_ktp'] = $newName;
        } else {
            // Tidak upload KTP baru -> pertahankan file lama
            $data['lampiran_ktp'] = $warga['lampiran_ktp'] ?? null;
        }


        if (! $this->wargaModel->update($id, $data)) {


            // Jika update database gagal dan ada file baru,
            // hapus file baru agar tidak menjadi file sampah.
            if (
                ! empty($data['lampiran_ktp']) &&
                $data['lampiran_ktp'] !== ($warga['lampiran_ktp'] ?? null)
            ) {
                $filePath = WRITEPATH . 'uploads/warga/' . $data['lampiran_ktp'];


                if (is_file($filePath)) {
                    unlink($filePath);
                }
            }


            return redirect()
                ->back()
                ->withInput()
                ->with('errors', $this->wargaModel->errors());
        }


        // Jika berhasil menggunakan file baru,
        // hapus file KTP lama.
        if (
            ! empty($warga['lampiran_ktp']) &&
            ! empty($data['lampiran_ktp']) &&
            $warga['lampiran_ktp'] !== $data['lampiran_ktp']
        ) {
            $oldFile = WRITEPATH . 'uploads/warga/' . $warga['lampiran_ktp'];


            if (is_file($oldFile)) {
                unlink($oldFile);
            }
        }


        return redirect()
            ->to(site_url('warga'))
            ->with('success', 'Data warga berhasil diperbarui.');
    }


    /**
     * Nonaktifkan warga.
     */
    public function delete(int $id)
    {
        $warga = $this->wargaModel->find($id);


        if (! $warga) {
            return redirect()
                ->to(site_url('warga'))
                ->with('error', 'Data warga tidak ditemukan.');
        }


        $this->wargaModel->update($id, [
            'status' => 'nonaktif',
        ]);


        return redirect()
            ->to(site_url('warga'))
            ->with('success', 'Data warga berhasil dinonaktifkan.');
    }


    public function ktp(int $id)
    {
        $warga = $this->wargaModel->find($id);


        if (! $warga || empty($warga['lampiran_ktp'])) {
            throw \CodeIgniter\Exceptions\PageNotFoundException::forPageNotFound(
                'Lampiran KTP tidak ditemukan.'
            );
        }


        $filePath = WRITEPATH . 'uploads/warga/' . $warga['lampiran_ktp'];


        if (! is_file($filePath)) {
            throw \CodeIgniter\Exceptions\PageNotFoundException::forPageNotFound(
                'File KTP tidak ditemukan.'
            );
        }


        $mimeType = mime_content_type($filePath);


        return $this->response
            ->setHeader('Content-Type', $mimeType)
            ->setHeader(
                'Content-Disposition',
                'inline; filename="' . basename($filePath) . '"'
            )
            ->setBody(file_get_contents($filePath));
    }
}