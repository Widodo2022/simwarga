<?php

namespace App\Controllers;

use App\Models\JenisIuranModel;
use App\Models\KartuKeluargaModel;
use App\Models\TagihanIuranModel;
use App\Models\WargaModel;

class Dashboard extends BaseController
{
    public function index()
    {
        $tagihan = new TagihanIuranModel();

        if ((string) session()->get('role_kode') === 'WARGA') {
            return view('dashboard/index', ['title'=>'Dashboard','nama'=>session()->get('nama_lengkap') ?? 'Warga','wargaMode'=>true]);
        }

        return view('dashboard/index', [
            'title' => 'Dashboard',
            'nama' => session()->get('nama_lengkap') ?? 'Pengguna',
            'totalKK' => (new KartuKeluargaModel())->where('status', 'aktif')->countAllResults(),
            'totalWarga' => (new WargaModel())->where('status', 'aktif')->countAllResults(),
            'totalJenisIuran' => (new JenisIuranModel())->where('status', 'aktif')->countAllResults(),
            'totalTagihan' => $tagihan->getTotalTagihan(),
            'totalLunas' => $tagihan->getTotalLunas(),
            'totalBelumBayar' => $tagihan->getTotalBelumBayar(),
            'nominalLunas' => $tagihan->getTotalNominalLunas(),
            'nominalBelumBayar' => $tagihan->getTotalNominalBelumBayar(),
        ]);
    }
}
