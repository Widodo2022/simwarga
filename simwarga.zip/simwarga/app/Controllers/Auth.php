<?php

namespace App\Controllers;

use App\Models\UserModel;
use App\Models\UserRoleModel;
use App\Models\RolePermissionModel;

class Auth extends BaseController
{
    protected UserModel $userModel;
    protected UserRoleModel $userRoleModel;
    protected RolePermissionModel $rolePermissionModel;

    public function __construct()
    {
        $this->userModel = new UserModel();
        $this->userRoleModel = new UserRoleModel();
        $this->rolePermissionModel = new RolePermissionModel();
    }

    /**
     * Halaman login.
     */
    public function login()
    {
        if (session()->get('isLoggedIn')) {
            return redirect()->to(site_url('dashboard'));
        }

        return view('auth/login');
    }

    /**
     * Proses login.
     */
    public function attemptLogin()
    {
        $rules = [
            'username' => 'required|min_length[3]|max_length[100]',
            'password' => 'required|min_length[6]',
        ];

        if (! $this->validate($rules)) {
            return redirect()
                ->back()
                ->withInput()
                ->with('error', $this->validator->listErrors());
        }

        $username = trim((string) $this->request->getPost('username'));
        $password = (string) $this->request->getPost('password');

        $user = $this->userModel->getByUsername($username);

        if (! $user || ! password_verify($password, $user['password'])) {
            return redirect()
                ->back()
                ->withInput()
                ->with('error', 'Username atau password salah.');
        }

        $roles = $this->userRoleModel->getRolesByUser((int) $user['id']);

        if (empty($roles)) {
            return redirect()
                ->back()
                ->withInput()
                ->with('error', 'User belum memiliki role.');
        }

        /*
         * Untuk tahap awal kita gunakan role pertama
         * sebagai role aktif user.
         */
        $role = $roles[0];

        $permissions = $this->rolePermissionModel
            ->getPermissionsByRole((int) $role['id']);

        $permissionCodes = [];

        foreach ($permissions as $permission) {
            $permissionCodes[] = $permission['kode'];
        }

        session()->regenerate(true);

        session()->set([
            'user_id'       => $user['id'],
            'username'      => $user['username'],
            'nama_lengkap'  => $user['nama_lengkap'],
            'email'         => $user['email'],
            'no_kk'         => $user['no_kk'] ?? null,
            'role_id'       => $role['id'],
            'role_kode'     => $role['kode'],
            'role_nama'     => $role['nama'],
            'permissions'   => $permissionCodes,
            'isLoggedIn'    => true,
        ]);

        $this->userModel->update(
            $user['id'],
            [
                'last_login' => date('Y-m-d H:i:s'),
            ]
        );

        return redirect()->to(site_url('dashboard'));
    }

    /**
     * Logout.
     */
    public function logout()
    {
        session()->destroy();

        return redirect()
            ->to(site_url('login'))
            ->with('success', 'Anda berhasil logout.');
    }
}