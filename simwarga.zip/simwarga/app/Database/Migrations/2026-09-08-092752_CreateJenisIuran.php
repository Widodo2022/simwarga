<?php

namespace App\Database\Migrations;

use CodeIgniter\Database\Migration;

class CreateJenisIuran extends Migration
{
    public function up()
    {
        // Jangan membuat tabel jika sudah ada.
        if ($this->db->tableExists('jenis_iuran')) {
            return;
        }

        $this->forge->addField([
            'id' => [
                'type'           => 'INT',
                'constraint'     => 10,
                'unsigned'       => true,
                'auto_increment' => true,
            ],

            'kode_iuran' => [
                'type'       => 'VARCHAR',
                'constraint' => 30,
            ],

            'nama_iuran' => [
                'type'       => 'VARCHAR',
                'constraint' => 100,
            ],

            'deskripsi' => [
                'type'       => 'VARCHAR',
                'constraint' => 255,
                'null'       => true,
            ],

            'nominal' => [
                'type'       => 'DECIMAL',
                'constraint' => '15,2',
                'default'    => 0,
            ],

            'sifat_iuran' => [
                'type'       => 'ENUM',
                'constraint' => ['wajib', 'sukarela'],
                'default'    => 'wajib',
            ],

            'periode' => [
                'type'       => 'ENUM',
                'constraint' => ['bulanan', 'tahunan', 'sekali'],
                'default'    => 'bulanan',
            ],

            'tanggal_mulai' => [
                'type' => 'DATE',
                'null' => true,
            ],

            'status' => [
                'type'       => 'ENUM',
                'constraint' => ['aktif', 'nonaktif'],
                'default'    => 'aktif',
            ],

            'created_at' => [
                'type' => 'DATETIME',
                'null' => true,
            ],

            'updated_at' => [
                'type' => 'DATETIME',
                'null' => true,
            ],
        ]);

        $this->forge->addKey('id', true);

        $this->forge->addUniqueKey('kode_iuran');

        $this->forge->createTable('jenis_iuran');
    }

    public function down()
    {
        $this->forge->dropTable('jenis_iuran', true);
    }
}