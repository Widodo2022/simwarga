<?php

namespace App\Database\Migrations;

use CodeIgniter\Database\Migration;

class CreateIuranPengeluaranCore extends Migration
{
    public function up()
    {
        $this->createMetodePembayaran();
        $this->createPembayaranIuran();
        $this->createPembayaranDetail();
        $this->createPembayaranLampiran();
        $this->createPembatalanPembayaran();
        $this->createPembatalanTagihan();
        $this->createPemulihanTagihan();
        $this->createIuranGenerationLog();
        $this->createAuditLog();
        $this->createPengeluaranKategori();
        $this->createPengeluaranPenerima();
        $this->createSumberDana();
        $this->createSaldoAwal();
        $this->createPengeluaran();
        $this->createPengeluaranLampiran();
        $this->createPengeluaranPemeriksaan();
        $this->createPengeluaranPersetujuan();
        $this->seedPermissions();

        // Anti-duplikasi: satu KK + jenis iuran + periode + tahun + bulan hanya boleh sekali.
        if ($this->db->tableExists('tagihan_iuran')) {
            $indexes = $this->db->query('SHOW INDEX FROM tagihan_iuran')->getResultArray();
            $exists = false;
            foreach ($indexes as $index) {
                if (($index['Key_name'] ?? '') === 'uq_tagihan_kk_jenis_periode') {
                    $exists = true;
                    break;
                }
            }
            if (! $exists) {
                $this->db->query("ALTER TABLE tagihan_iuran ADD COLUMN bulan_key TINYINT GENERATED ALWAYS AS (COALESCE(bulan,0)) STORED");
                $this->db->query('ALTER TABLE tagihan_iuran ADD UNIQUE KEY uq_tagihan_kk_jenis_periode (no_kk, jenis_iuran_id, periode, tahun, bulan_key)');
            }
        }
    }


    private function seedPermissions(): void
    {
        if (! $this->db->tableExists('permissions')) return;
        $items = [
            ['tagihan_iuran.view','Lihat Tagihan Iuran','tagihan_iuran','view','Melihat daftar tagihan'],
            ['tagihan_iuran.create','Generate/Buat Tagihan Iuran','tagihan_iuran','create','Membuat tagihan'],
            ['tagihan_iuran.edit','Edit Tagihan Iuran','tagihan_iuran','edit','Mengubah tagihan yang belum dibayar'],
            ['tagihan_iuran.cancel','Batalkan Tagihan Iuran','tagihan_iuran','cancel','Membatalkan kewajiban tanpa menghapus histori'],
            ['tagihan_iuran.restore','Pulihkan Tagihan Iuran','tagihan_iuran','restore','Memulihkan tagihan yang dibatalkan'],
            ['pembayaran_iuran.create','Catat Pembayaran Iuran','pembayaran_iuran','create','Mencatat pembayaran langsung valid'],
            ['pembayaran_iuran.cancel','Batalkan Pembayaran Iuran','pembayaran_iuran','cancel','Membatalkan pembayaran dan menghitung ulang tagihan'],
            ['pengeluaran.view','Lihat Pengeluaran','pengeluaran','view','Melihat pengeluaran'],
            ['pengeluaran.create','Buat Pengeluaran','pengeluaran','create','Membuat draft pengeluaran'],
            ['pengeluaran.edit','Edit Pengeluaran','pengeluaran','edit','Mengubah pengeluaran'],
            ['pengeluaran.submit','Kirim Pengeluaran','pengeluaran','submit','Mengirim pengeluaran untuk pemeriksaan'],
            ['pengeluaran.check','Periksa Pengeluaran','pengeluaran','check','Memeriksa pengeluaran sebagai Sekretaris'],
            ['pengeluaran.approve','Setujui Pengeluaran','pengeluaran','approve','Memberi keputusan akhir'],
            ['pengeluaran.delete','Hapus Permanen Pengeluaran','pengeluaran','delete','Menghapus transaksi secara permanen dengan audit trail'],
            ['pengeluaran.master.manage','Kelola Master Pengeluaran','pengeluaran','master','Mengelola kategori, penerima dan sumber dana'],
            ['keuangan.opening_balance.manage','Kelola Saldo Awal','keuangan','opening_balance','Menetapkan saldo awal pembukuan'],
        ];
        $now=date('Y-m-d H:i:s');
        foreach($items as $x){
            if($this->db->table('permissions')->where('kode',$x[0])->countAllResults()>0) continue;
            $this->db->table('permissions')->insert(['kode'=>$x[0],'nama'=>$x[1],'modul'=>$x[2],'aksi'=>$x[3],'deskripsi'=>$x[4],'status'=>'aktif','created_at'=>$now,'updated_at'=>$now]);
        }
    }

    private function createMetodePembayaran(): void
    {
        if ($this->db->tableExists('metode_pembayaran')) return;
        $this->forge->addField([
            'id'=>['type'=>'INT','unsigned'=>true,'auto_increment'=>true],
            'kode'=>['type'=>'VARCHAR','constraint'=>30],
            'nama'=>['type'=>'VARCHAR','constraint'=>100],
            'status'=>['type'=>'ENUM','constraint'=>['aktif','nonaktif'],'default'=>'aktif'],
            'keterangan'=>['type'=>'VARCHAR','constraint'=>255,'null'=>true],
            'created_at'=>['type'=>'DATETIME','null'=>true],
            'updated_at'=>['type'=>'DATETIME','null'=>true],
        ]);
        $this->forge->addKey('id',true); $this->forge->addUniqueKey('kode'); $this->forge->createTable('metode_pembayaran');
        $now=date('Y-m-d H:i:s');
        $this->db->table('metode_pembayaran')->insertBatch([
            ['kode'=>'CASH','nama'=>'Tunai','status'=>'aktif','created_at'=>$now,'updated_at'=>$now],
            ['kode'=>'TRANSFER_BANK','nama'=>'Transfer Bank','status'=>'aktif','created_at'=>$now,'updated_at'=>$now],
            ['kode'=>'QRIS','nama'=>'QRIS','status'=>'aktif','created_at'=>$now,'updated_at'=>$now],
            ['kode'=>'LAINNYA','nama'=>'Lainnya','status'=>'aktif','created_at'=>$now,'updated_at'=>$now],
        ]);
    }

    private function createPembayaranIuran(): void
    {
        if ($this->db->tableExists('pembayaran_iuran')) return;
        $this->forge->addField([
            'id'=>['type'=>'INT','unsigned'=>true,'auto_increment'=>true],
            'nomor_pembayaran'=>['type'=>'VARCHAR','constraint'=>40],
            'no_kk'=>['type'=>'VARCHAR','constraint'=>16],
            'tanggal_pembayaran'=>['type'=>'DATE'],
            'total_bayar'=>['type'=>'DECIMAL','constraint'=>'15,2','default'=>0],
            'metode_pembayaran_id'=>['type'=>'INT','unsigned'=>true],
            'nomor_referensi'=>['type'=>'VARCHAR','constraint'=>100,'null'=>true],
            'status'=>['type'=>'ENUM','constraint'=>['valid','dibatalkan'],'default'=>'valid'],
            'keterangan'=>['type'=>'VARCHAR','constraint'=>255,'null'=>true],
            'created_by'=>['type'=>'INT','unsigned'=>true],
            'created_at'=>['type'=>'DATETIME','null'=>true],
            'updated_at'=>['type'=>'DATETIME','null'=>true],
        ]);
        $this->forge->addKey('id',true); $this->forge->addUniqueKey('nomor_pembayaran'); $this->forge->addKey('no_kk'); $this->forge->addKey('status'); $this->forge->createTable('pembayaran_iuran');
        $this->db->query('ALTER TABLE pembayaran_iuran ADD CONSTRAINT fk_pembayaran_metode FOREIGN KEY (metode_pembayaran_id) REFERENCES metode_pembayaran(id) ON UPDATE CASCADE ON DELETE RESTRICT');
    }

    private function createPembayaranDetail(): void
    {
        if ($this->db->tableExists('pembayaran_iuran_detail')) return;
        $this->forge->addField([
            'id'=>['type'=>'INT','unsigned'=>true,'auto_increment'=>true],
            'pembayaran_id'=>['type'=>'INT','unsigned'=>true],
            'tagihan_iuran_id'=>['type'=>'INT','unsigned'=>true],
            'jumlah_dialokasikan'=>['type'=>'DECIMAL','constraint'=>'15,2','default'=>0],
            'created_at'=>['type'=>'DATETIME','null'=>true],
        ]);
        $this->forge->addKey('id',true); $this->forge->addUniqueKey(['pembayaran_id','tagihan_iuran_id']); $this->forge->addKey('tagihan_iuran_id'); $this->forge->createTable('pembayaran_iuran_detail');
        $this->db->query('ALTER TABLE pembayaran_iuran_detail ADD CONSTRAINT fk_pembayaran_detail_payment FOREIGN KEY (pembayaran_id) REFERENCES pembayaran_iuran(id) ON DELETE CASCADE ON UPDATE CASCADE');
        $this->db->query('ALTER TABLE pembayaran_iuran_detail ADD CONSTRAINT fk_pembayaran_detail_tagihan FOREIGN KEY (tagihan_iuran_id) REFERENCES tagihan_iuran(id) ON DELETE RESTRICT ON UPDATE CASCADE');
    }

    private function createPembayaranLampiran(): void
    {
        if ($this->db->tableExists('pembayaran_iuran_lampiran')) return;
        $this->forge->addField([
            'id'=>['type'=>'INT','unsigned'=>true,'auto_increment'=>true],
            'pembayaran_id'=>['type'=>'INT','unsigned'=>true],
            'nama_file'=>['type'=>'VARCHAR','constraint'=>255],
            'path_file'=>['type'=>'VARCHAR','constraint'=>500],
            'jenis_file'=>['type'=>'VARCHAR','constraint'=>100,'null'=>true],
            'ukuran_file'=>['type'=>'INT','unsigned'=>true,'null'=>true],
            'uploaded_by'=>['type'=>'INT','unsigned'=>true],
            'created_at'=>['type'=>'DATETIME','null'=>true],
        ]);
        $this->forge->addKey('id',true); $this->forge->addKey('pembayaran_id'); $this->forge->createTable('pembayaran_iuran_lampiran');
        $this->db->query('ALTER TABLE pembayaran_iuran_lampiran ADD CONSTRAINT fk_pembayaran_lampiran FOREIGN KEY (pembayaran_id) REFERENCES pembayaran_iuran(id) ON DELETE CASCADE ON UPDATE CASCADE');
    }

    private function createPembatalanPembayaran(): void
    {
        if ($this->db->tableExists('pembatalan_pembayaran_iuran')) return;
        $this->forge->addField([
            'id'=>['type'=>'INT','unsigned'=>true,'auto_increment'=>true],
            'pembayaran_id'=>['type'=>'INT','unsigned'=>true],
            'alasan'=>['type'=>'TEXT'],
            'dibatalkan_oleh'=>['type'=>'INT','unsigned'=>true],
            'dibatalkan_pada'=>['type'=>'DATETIME'],
        ]);
        $this->forge->addKey('id',true); $this->forge->addUniqueKey('pembayaran_id'); $this->forge->createTable('pembatalan_pembayaran_iuran');
    }

    private function createPembatalanTagihan(): void
    {
        if ($this->db->tableExists('pembatalan_tagihan_iuran')) return;
        $this->forge->addField([
            'id'=>['type'=>'INT','unsigned'=>true,'auto_increment'=>true],
            'tagihan_iuran_id'=>['type'=>'INT','unsigned'=>true],
            'alasan'=>['type'=>'TEXT'],
            'dibatalkan_oleh'=>['type'=>'INT','unsigned'=>true],
            'dibatalkan_pada'=>['type'=>'DATETIME'],
        ]);
        $this->forge->addKey('id',true); $this->forge->addKey('tagihan_iuran_id'); $this->forge->createTable('pembatalan_tagihan_iuran');
        $this->db->query('ALTER TABLE pembatalan_tagihan_iuran ADD CONSTRAINT fk_batal_tagihan FOREIGN KEY (tagihan_iuran_id) REFERENCES tagihan_iuran(id) ON DELETE RESTRICT ON UPDATE CASCADE');
    }

    private function createPemulihanTagihan(): void
    {
        if ($this->db->tableExists('pemulihan_tagihan_iuran')) return;
        $this->forge->addField([
            'id'=>['type'=>'INT','unsigned'=>true,'auto_increment'=>true],
            'tagihan_iuran_id'=>['type'=>'INT','unsigned'=>true],
            'alasan'=>['type'=>'TEXT'],
            'dipulihkan_oleh'=>['type'=>'INT','unsigned'=>true],
            'dipulihkan_pada'=>['type'=>'DATETIME'],
            'konteks'=>['type'=>'ENUM','constraint'=>['normal','masalah_sistem'],'default'=>'normal'],
        ]);
        $this->forge->addKey('id',true); $this->forge->addKey('tagihan_iuran_id'); $this->forge->createTable('pemulihan_tagihan_iuran');
        $this->db->query('ALTER TABLE pemulihan_tagihan_iuran ADD CONSTRAINT fk_restore_tagihan FOREIGN KEY (tagihan_iuran_id) REFERENCES tagihan_iuran(id) ON DELETE RESTRICT ON UPDATE CASCADE');
    }

    private function createIuranGenerationLog(): void
    {
        if ($this->db->tableExists('iuran_generation_log')) return;
        $this->forge->addField([
            'id'=>['type'=>'INT','unsigned'=>true,'auto_increment'=>true],
            'periode'=>['type'=>'VARCHAR','constraint'=>20], 'tahun'=>['type'=>'YEAR'],
            'jenis_iuran_ids'=>['type'=>'TEXT'], 'kk_diproses'=>['type'=>'INT','unsigned'=>true,'default'=>0],
            'dibuat'=>['type'=>'INT','unsigned'=>true,'default'=>0], 'dilewati'=>['type'=>'INT','unsigned'=>true,'default'=>0],
            'total_nominal'=>['type'=>'DECIMAL','constraint'=>'15,2','default'=>0], 'created_by'=>['type'=>'INT','unsigned'=>true], 'created_at'=>['type'=>'DATETIME'],
        ]);
        $this->forge->addKey('id',true); $this->forge->createTable('iuran_generation_log');
    }

    private function createAuditLog(): void
    {
        if ($this->db->tableExists('audit_log')) return;
        $this->forge->addField([
            'id'=>['type'=>'BIGINT','unsigned'=>true,'auto_increment'=>true],
            'user_id'=>['type'=>'INT','unsigned'=>true,'null'=>true], 'aksi'=>['type'=>'VARCHAR','constraint'=>80],
            'modul'=>['type'=>'VARCHAR','constraint'=>80], 'referensi_id'=>['type'=>'VARCHAR','constraint'=>80,'null'=>true],
            'ringkasan'=>['type'=>'TEXT','null'=>true], 'data_lama'=>['type'=>'LONGTEXT','null'=>true], 'data_baru'=>['type'=>'LONGTEXT','null'=>true],
            'created_at'=>['type'=>'DATETIME'],
        ]);
        $this->forge->addKey('id',true); $this->forge->addKey(['modul','aksi']); $this->forge->createTable('audit_log');
    }

    private function createPengeluaranKategori(): void
    {
        if ($this->db->tableExists('pengeluaran_kategori')) return;
        $this->forge->addField(['id'=>['type'=>'INT','unsigned'=>true,'auto_increment'=>true],'kode'=>['type'=>'VARCHAR','constraint'=>30],'nama'=>['type'=>'VARCHAR','constraint'=>100],'status'=>['type'=>'ENUM','constraint'=>['aktif','nonaktif'],'default'=>'aktif'],'created_at'=>['type'=>'DATETIME','null'=>true],'updated_at'=>['type'=>'DATETIME','null'=>true]]);
        $this->forge->addKey('id',true); $this->forge->addUniqueKey('kode'); $this->forge->createTable('pengeluaran_kategori');
        $now=date('Y-m-d H:i:s');
        $this->db->table('pengeluaran_kategori')->insertBatch([
            ['kode'=>'ADM','nama'=>'Administrasi RT','status'=>'aktif','created_at'=>$now,'updated_at'=>$now],
            ['kode'=>'KEB','nama'=>'Kebersihan','status'=>'aktif','created_at'=>$now,'updated_at'=>$now],
            ['kode'=>'KEA','nama'=>'Keamanan','status'=>'aktif','created_at'=>$now,'updated_at'=>$now],
            ['kode'=>'KEG','nama'=>'Kegiatan Warga','status'=>'aktif','created_at'=>$now,'updated_at'=>$now],
            ['kode'=>'SOS','nama'=>'Sosial','status'=>'aktif','created_at'=>$now,'updated_at'=>$now],
            ['kode'=>'PEM','nama'=>'Pemeliharaan Fasilitas','status'=>'aktif','created_at'=>$now,'updated_at'=>$now],
            ['kode'=>'RAP','nama'=>'Rapat','status'=>'aktif','created_at'=>$now,'updated_at'=>$now],
            ['kode'=>'OPS','nama'=>'Operasional','status'=>'aktif','created_at'=>$now,'updated_at'=>$now],
            ['kode'=>'LAIN','nama'=>'Lainnya','status'=>'aktif','created_at'=>$now,'updated_at'=>$now],
        ]);
    }

    private function createPengeluaranPenerima(): void
    {
        if ($this->db->tableExists('pengeluaran_penerima')) return;
        $this->forge->addField(['id'=>['type'=>'INT','unsigned'=>true,'auto_increment'=>true],'nama'=>['type'=>'VARCHAR','constraint'=>150],'kontak'=>['type'=>'VARCHAR','constraint'=>100,'null'=>true],'status'=>['type'=>'ENUM','constraint'=>['aktif','nonaktif'],'default'=>'aktif'],'created_at'=>['type'=>'DATETIME','null'=>true],'updated_at'=>['type'=>'DATETIME','null'=>true]]);
        $this->forge->addKey('id',true); $this->forge->addKey('status'); $this->forge->createTable('pengeluaran_penerima');
    }

    private function createSumberDana(): void
    {
        if ($this->db->tableExists('sumber_dana')) return;
        $this->forge->addField(['id'=>['type'=>'INT','unsigned'=>true,'auto_increment'=>true],'kode'=>['type'=>'VARCHAR','constraint'=>30],'nama'=>['type'=>'VARCHAR','constraint'=>100],'status'=>['type'=>'ENUM','constraint'=>['aktif','nonaktif'],'default'=>'aktif'],'keterangan'=>['type'=>'VARCHAR','constraint'=>255,'null'=>true],'created_at'=>['type'=>'DATETIME','null'=>true],'updated_at'=>['type'=>'DATETIME','null'=>true]]);
        $this->forge->addKey('id',true); $this->forge->addUniqueKey('kode'); $this->forge->createTable('sumber_dana');
        $now=date('Y-m-d H:i:s'); $this->db->table('sumber_dana')->insertBatch([
            ['kode'=>'TOTAL','nama'=>'TOTAL SUMBER DANA','status'=>'aktif','created_at'=>$now,'updated_at'=>$now],
            ['kode'=>'KAS_RT','nama'=>'Kas RT','status'=>'aktif','created_at'=>$now,'updated_at'=>$now],
            ['kode'=>'BANK_RT','nama'=>'Bank RT','status'=>'aktif','created_at'=>$now,'updated_at'=>$now],
            ['kode'=>'QRIS_RT','nama'=>'QRIS RT','status'=>'aktif','created_at'=>$now,'updated_at'=>$now],
        ]);
    }

    private function createSaldoAwal(): void
    {
        if ($this->db->tableExists('saldo_awal_keuangan')) return;
        $this->forge->addField(['id'=>['type'=>'INT','unsigned'=>true,'auto_increment'=>true],'tanggal_mulai'=>['type'=>'DATE'],'nominal'=>['type'=>'DECIMAL','constraint'=>'15,2','default'=>0],'status'=>['type'=>'ENUM','constraint'=>['aktif','dikoreksi'],'default'=>'aktif'],'keterangan'=>['type'=>'TEXT','null'=>true],'ditetapkan_oleh'=>['type'=>'INT','unsigned'=>true],'created_at'=>['type'=>'DATETIME'],'updated_at'=>['type'=>'DATETIME','null'=>true]]);
        $this->forge->addKey('id',true); $this->forge->addKey('status'); $this->forge->createTable('saldo_awal_keuangan');
    }

    private function createPengeluaran(): void
    {
        if ($this->db->tableExists('pengeluaran')) return;
        $this->forge->addField([
            'id'=>['type'=>'INT','unsigned'=>true,'auto_increment'=>true], 'nomor_bukti'=>['type'=>'VARCHAR','constraint'=>40], 'tanggal_transaksi'=>['type'=>'DATE'],
            'kategori_id'=>['type'=>'INT','unsigned'=>true], 'penerima_id'=>['type'=>'INT','unsigned'=>true], 'sumber_dana_id'=>['type'=>'INT','unsigned'=>true],
            'nominal'=>['type'=>'DECIMAL','constraint'=>'15,2','default'=>0], 'uraian'=>['type'=>'TEXT'], 'catatan'=>['type'=>'TEXT','null'=>true],
            'status'=>['type'=>'ENUM','constraint'=>['draft','menunggu_pemeriksaan','dikembalikan','menunggu_persetujuan','disetujui','ditolak'],'default'=>'draft'],
            'created_by'=>['type'=>'INT','unsigned'=>true], 'created_at'=>['type'=>'DATETIME'], 'updated_at'=>['type'=>'DATETIME','null'=>true],
        ]);
        $this->forge->addKey('id',true); $this->forge->addUniqueKey('nomor_bukti'); $this->forge->addKey(['status','tanggal_transaksi']); $this->forge->createTable('pengeluaran');
        $this->db->query('ALTER TABLE pengeluaran ADD CONSTRAINT fk_pengeluaran_kategori FOREIGN KEY (kategori_id) REFERENCES pengeluaran_kategori(id) ON UPDATE CASCADE ON DELETE RESTRICT');
        $this->db->query('ALTER TABLE pengeluaran ADD CONSTRAINT fk_pengeluaran_penerima FOREIGN KEY (penerima_id) REFERENCES pengeluaran_penerima(id) ON UPDATE CASCADE ON DELETE RESTRICT');
        $this->db->query('ALTER TABLE pengeluaran ADD CONSTRAINT fk_pengeluaran_sumber FOREIGN KEY (sumber_dana_id) REFERENCES sumber_dana(id) ON UPDATE CASCADE ON DELETE RESTRICT');
    }

    private function createPengeluaranLampiran(): void
    {
        if ($this->db->tableExists('pengeluaran_lampiran')) return;
        $this->forge->addField(['id'=>['type'=>'INT','unsigned'=>true,'auto_increment'=>true],'pengeluaran_id'=>['type'=>'INT','unsigned'=>true],'nama_file'=>['type'=>'VARCHAR','constraint'=>255],'path_file'=>['type'=>'VARCHAR','constraint'=>500],'jenis_file'=>['type'=>'VARCHAR','constraint'=>100,'null'=>true],'ukuran_file'=>['type'=>'INT','unsigned'=>true,'null'=>true],'uploaded_by'=>['type'=>'INT','unsigned'=>true],'created_at'=>['type'=>'DATETIME']]);
        $this->forge->addKey('id',true); $this->forge->addKey('pengeluaran_id'); $this->forge->createTable('pengeluaran_lampiran');
        $this->db->query('ALTER TABLE pengeluaran_lampiran ADD CONSTRAINT fk_pengeluaran_lampiran FOREIGN KEY (pengeluaran_id) REFERENCES pengeluaran(id) ON DELETE CASCADE ON UPDATE CASCADE');
    }

    private function createPengeluaranPemeriksaan(): void
    {
        if ($this->db->tableExists('pengeluaran_pemeriksaan')) return;
        $this->forge->addField(['id'=>['type'=>'INT','unsigned'=>true,'auto_increment'=>true],'pengeluaran_id'=>['type'=>'INT','unsigned'=>true],'hasil'=>['type'=>'ENUM','constraint'=>['lolos','dikembalikan']],'catatan'=>['type'=>'TEXT','null'=>true],'diperiksa_oleh'=>['type'=>'INT','unsigned'=>true],'diperiksa_pada'=>['type'=>'DATETIME']]);
        $this->forge->addKey('id',true); $this->forge->addKey('pengeluaran_id'); $this->forge->createTable('pengeluaran_pemeriksaan');
        $this->db->query('ALTER TABLE pengeluaran_pemeriksaan ADD CONSTRAINT fk_pemeriksaan_pengeluaran FOREIGN KEY (pengeluaran_id) REFERENCES pengeluaran(id) ON DELETE CASCADE ON UPDATE CASCADE');
    }

    private function createPengeluaranPersetujuan(): void
    {
        if ($this->db->tableExists('pengeluaran_persetujuan')) return;
        $this->forge->addField(['id'=>['type'=>'INT','unsigned'=>true,'auto_increment'=>true],'pengeluaran_id'=>['type'=>'INT','unsigned'=>true],'keputusan'=>['type'=>'ENUM','constraint'=>['disetujui','ditolak']],'catatan'=>['type'=>'TEXT','null'=>true],'disetujui_oleh'=>['type'=>'INT','unsigned'=>true],'diputuskan_pada'=>['type'=>'DATETIME']]);
        $this->forge->addKey('id',true); $this->forge->addKey('pengeluaran_id'); $this->forge->createTable('pengeluaran_persetujuan');
        $this->db->query('ALTER TABLE pengeluaran_persetujuan ADD CONSTRAINT fk_persetujuan_pengeluaran FOREIGN KEY (pengeluaran_id) REFERENCES pengeluaran(id) ON DELETE CASCADE ON UPDATE CASCADE');
    }

    public function down()
    {
        foreach ([
            'pengeluaran_persetujuan','pengeluaran_pemeriksaan','pengeluaran_lampiran','pengeluaran','saldo_awal_keuangan','sumber_dana','pengeluaran_penerima','pengeluaran_kategori','audit_log','iuran_generation_log','pemulihan_tagihan_iuran','pembatalan_tagihan_iuran','pembatalan_pembayaran_iuran','pembayaran_iuran_lampiran','pembayaran_iuran_detail','pembayaran_iuran','metode_pembayaran'
        ] as $table) {
            if ($this->db->tableExists($table)) $this->forge->dropTable($table, true);
        }
        if ($this->db->tableExists('tagihan_iuran')) {
            try { $this->db->query('ALTER TABLE tagihan_iuran DROP INDEX uq_tagihan_kk_jenis_periode'); } catch (\Throwable $e) {}
            try { $this->db->query('ALTER TABLE tagihan_iuran DROP COLUMN bulan_key'); } catch (\Throwable $e) {}
        }
    }
}
