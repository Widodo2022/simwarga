<?php

namespace App\Database\Migrations;

use CodeIgniter\Database\Migration;

class CreatePermissionsTable extends Migration
{
    public function up()
    {
        $this->forge->addField([
            'id' => [
                'type'           => 'INT',
                'unsigned'       => true,
                'auto_increment' => true,
            ],

            'kode' => [
                'type'       => 'VARCHAR',
                'constraint' => 100,
            ],

            'nama' => [
                'type'       => 'VARCHAR',
                'constraint' => 150,
            ],

            'modul' => [
                'type'       => 'VARCHAR',
                'constraint' => 100,
            ],

            'aksi' => [
                'type'       => 'VARCHAR',
                'constraint' => 50,
            ],

            'deskripsi' => [
                'type' => 'TEXT',
                'null' => true,
            ],

            'status' => [
                'type'       => 'ENUM',
                'constraint' => ['aktif', 'nonaktif'],
                'default'    => 'aktif',
            ],

            'created_at' => [
                'type' => 'DATETIME',
                'null' => true,
            ],

            'updated_at' => [
                'type' => 'DATETIME',
                'null' => true,
            ],
        ]);

        $this->forge->addKey('id', true);

        $this->forge->addUniqueKey('kode');

        $this->forge->addKey('modul');

        $this->forge->createTable('permissions');
    }

    public function down()
    {
        $this->forge->dropTable('permissions', true);
    }
}