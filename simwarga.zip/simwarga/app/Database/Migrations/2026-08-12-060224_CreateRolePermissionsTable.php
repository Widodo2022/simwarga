<?php

namespace App\Database\Migrations;

use CodeIgniter\Database\Migration;

class CreateRolePermissionsTable extends Migration
{
    public function up()
    {
        $this->forge->addField([
            'id' => [
                'type'           => 'INT',
                'unsigned'       => true,
                'auto_increment' => true,
            ],

            'role_id' => [
                'type'     => 'INT',
                'unsigned' => true,
            ],

            'permission_id' => [
                'type'     => 'INT',
                'unsigned' => true,
            ],

            'created_at' => [
                'type' => 'DATETIME',
                'null' => true,
            ],

            'updated_at' => [
                'type' => 'DATETIME',
                'null' => true,
            ],
        ]);

        $this->forge->addKey('id', true);

        // Satu role tidak boleh memiliki permission yang sama dua kali.
        $this->forge->addUniqueKey(['role_id', 'permission_id']);

        // Relasi ke roles
        $this->forge->addForeignKey(
            'role_id',
            'roles',
            'id',
            'CASCADE',
            'CASCADE'
        );

        // Relasi ke permissions
        $this->forge->addForeignKey(
            'permission_id',
            'permissions',
            'id',
            'CASCADE',
            'CASCADE'
        );

        $this->forge->createTable('role_permissions');
    }

    public function down()
    {
        $this->forge->dropTable('role_permissions', true);
    }
}