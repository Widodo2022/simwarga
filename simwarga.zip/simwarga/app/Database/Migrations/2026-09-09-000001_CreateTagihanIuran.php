<?php

namespace App\Database\Migrations;

use CodeIgniter\Database\Migration;

class CreateTagihanIuran extends Migration
{
    public function up()
    {
        if ($this->db->tableExists('tagihan_iuran')) {
            return;
        }

        $this->forge->addField([
            'id' => [
                'type'           => 'INT',
                'constraint'     => 10,
                'unsigned'       => true,
                'auto_increment' => true,
            ],

            'jenis_iuran_id' => [
                'type'       => 'INT',
                'constraint' => 10,
                'unsigned'   => true,
            ],

            'no_kk' => [
                'type'       => 'VARCHAR',
                'constraint' => 16,
            ],

            'periode' => [
                'type'       => 'VARCHAR',
                'constraint' => 20,
            ],

            'tahun' => [
                'type'       => 'YEAR',
            ],

            'bulan' => [
                'type'       => 'TINYINT',
                'constraint' => 2,
                'null'       => true,
            ],

            'nominal' => [
                'type'       => 'DECIMAL',
                'constraint' => '15,2',
                'default'    => 0,
            ],

            'tanggal_tagihan' => [
                'type' => 'DATE',
                'null' => true,
            ],

            'tanggal_jatuh_tempo' => [
                'type' => 'DATE',
                'null' => true,
            ],

            'tanggal_bayar' => [
                'type' => 'DATE',
                'null' => true,
            ],

            'status' => [
                'type'       => 'ENUM',
                'constraint' => [
                    'belum_bayar',
                    'sebagian',
                    'lunas',
                    'dibatalkan',
                ],
                'default' => 'belum_bayar',
            ],

            'keterangan' => [
                'type'       => 'VARCHAR',
                'constraint' => 255,
                'null'       => true,
            ],

            'created_at' => [
                'type' => 'DATETIME',
                'null' => true,
            ],

            'updated_at' => [
                'type' => 'DATETIME',
                'null' => true,
            ],
        ]);

        $this->forge->addKey('id', true);

        $this->forge->addKey('jenis_iuran_id');
        $this->forge->addKey('no_kk');
        $this->forge->addKey('status');

        $this->forge->createTable('tagihan_iuran');

        // Relasi ke jenis_iuran
        $this->db->query("
            ALTER TABLE tagihan_iuran
            ADD CONSTRAINT fk_tagihan_iuran_jenis
            FOREIGN KEY (jenis_iuran_id)
            REFERENCES jenis_iuran(id)
            ON UPDATE CASCADE
            ON DELETE RESTRICT
        ");
    }

    public function down()
    {
        if ($this->db->tableExists('tagihan_iuran')) {
            $this->forge->dropTable('tagihan_iuran', true);
        }
    }
}