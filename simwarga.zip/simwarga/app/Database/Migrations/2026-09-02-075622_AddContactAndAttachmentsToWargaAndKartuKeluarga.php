<?php

namespace App\Database\Migrations;

use CodeIgniter\Database\Migration;

class AddContactAndAttachmentsToWargaAndKartuKeluarga extends Migration
{
    public function up()
    {
        // Warga: pastikan no_hp tersedia pada database lama.
        if (! $this->db->fieldExists('no_hp', 'warga')) {
            $this->forge->addColumn('warga', [
                'no_hp' => [
                    'type'       => 'VARCHAR',
                    'constraint' => 20,
                    'null'       => true,
                    'after'      => 'pekerjaan',
                ],
            ]);
        }

        if (! $this->db->fieldExists('lampiran_ktp', 'warga')) {
            $this->forge->addColumn('warga', [
                'lampiran_ktp' => [
                    'type'       => 'VARCHAR',
                    'constraint' => 255,
                    'null'       => true,
                    'after'      => 'no_hp',
                ],
            ]);
        }

        // Kartu Keluarga: kolom tambahan tetap opsional.
        $kkFields = [];

        if (! $this->db->fieldExists('no_hp', 'kartu_keluarga')) {
            $kkFields['no_hp'] = [
                'type'       => 'VARCHAR',
                'constraint' => 20,
                'null'       => true,
                'after'      => 'kode_wilayah',
            ];
        }

        if (! $this->db->fieldExists('lampiran_kk', 'kartu_keluarga')) {
            $kkFields['lampiran_kk'] = [
                'type'       => 'VARCHAR',
                'constraint' => 255,
                'null'       => true,
                'after'      => 'no_hp',
            ];
        }

        if (! empty($kkFields)) {
            $this->forge->addColumn('kartu_keluarga', $kkFields);
        }
    }

    public function down()
    {
        if ($this->db->fieldExists('lampiran_ktp', 'warga')) {
            $this->forge->dropColumn('warga', 'lampiran_ktp');
        }

        if ($this->db->fieldExists('no_hp', 'warga')) {
            // Hanya hapus jika memang migration ini menambahkannya.
            // Pada database yang sudah memiliki no_hp sejak awal,
            // migration lama sebaiknya tidak di-rollback.
        }

        if ($this->db->fieldExists('no_hp', 'kartu_keluarga')) {
            $this->forge->dropColumn('kartu_keluarga', 'no_hp');
        }

        if ($this->db->fieldExists('lampiran_kk', 'kartu_keluarga')) {
            $this->forge->dropColumn('kartu_keluarga', 'lampiran_kk');
        }
    }
}
