<?php

namespace App\Database\Migrations;

use CodeIgniter\Database\Migration;

class FinalizeRbacMenuAndAccess extends Migration
{
    public function up()
    {
        if (! $this->db->tableExists('permissions')) return;
        $now = date('Y-m-d H:i:s');
        $items = [
            ['rbac.manage','Kelola User, Role & Permission','RBAC','manage','Mengelola akun user dan permission role'],
            ['warga.create','Tambah Warga','Warga','create','Menambah data warga'],
            ['warga.edit','Edit Warga','Warga','edit','Mengubah data warga'],
            ['warga.delete','Nonaktifkan Warga','Warga','delete','Menonaktifkan data warga'],
            ['kk.create','Tambah Kartu Keluarga','Kartu Keluarga','create','Menambah KK'],
            ['kk.edit','Edit Kartu Keluarga','Kartu Keluarga','edit','Mengubah KK'],
            ['kk.delete','Nonaktifkan Kartu Keluarga','Kartu Keluarga','delete','Menonaktifkan KK'],
            ['jenis_iuran.view','Lihat Jenis Iuran','Jenis Iuran','view','Melihat master jenis iuran'],
            ['jenis_iuran.create','Tambah Jenis Iuran','Jenis Iuran','create','Menambah jenis iuran'],
            ['jenis_iuran.edit','Edit Jenis Iuran','Jenis Iuran','edit','Mengubah master jenis iuran'],
            ['jenis_iuran.delete','Nonaktifkan Jenis Iuran','Jenis Iuran','delete','Menonaktifkan jenis iuran'],
            ['keuangan.view','Lihat Keuangan RT','Keuangan','view','Melihat ringkasan keuangan RT'],
            ['master_wilayah.view','Lihat Master Wilayah','Master Wilayah','view','Melihat master wilayah'],
            ['pengeluaran.master.manage','Kelola Master Pengeluaran','Pengeluaran','master','Mengelola kategori, penerima dan sumber dana'],
        ];
        foreach ($items as $p) {
            if ($this->db->table('permissions')->where('kode', $p[0])->countAllResults() === 0) {
                $this->db->table('permissions')->insert([
                    'kode'=>$p[0], 'nama'=>$p[1], 'modul'=>$p[2], 'aksi'=>$p[3], 'deskripsi'=>$p[4], 'status'=>'aktif', 'created_at'=>$now, 'updated_at'=>$now,
                ]);
            }
        }

        $roleMap=[]; foreach($this->db->table('roles')->get()->getResultArray() as $r) $roleMap[$r['kode']]=(int)$r['id'];
        $permMap=[]; foreach($this->db->table('permissions')->where('status','aktif')->get()->getResultArray() as $p) $permMap[$p['kode']]=(int)$p['id'];

        $assignments = [
            'ADMINISTRATOR' => ['dashboard.view','warga.view','kk.view','laporan.view','rbac.manage','system.backup','system.backup.download','system.restore','system.backup.history'],
            'KETUA_RT' => ['dashboard.view','warga.view','warga.create','warga.edit','warga.delete','kk.view','kk.create','kk.edit','kk.delete','tagihan_iuran.view','pembayaran_iuran.view','pengeluaran.view','laporan.view','tagihan_iuran.cancel','tagihan_iuran.restore','pengeluaran.approve'],
            'BENDAHARA' => ['dashboard.view','jenis_iuran.view','jenis_iuran.create','jenis_iuran.edit','jenis_iuran.delete','tagihan_iuran.view','tagihan_iuran.create','tagihan_iuran.edit','pembayaran_iuran.view','pembayaran_iuran.create','pembayaran_iuran.cancel','tagihan_iuran.cancel','pengeluaran.view','pengeluaran.create','pengeluaran.edit','pengeluaran.submit','pengeluaran.master.manage','keuangan.view','keuangan.opening_balance.manage','laporan.view'],
            'SEKRETARIS' => ['dashboard.view','warga.view','warga.create','warga.edit','warga.delete','kk.view','kk.create','kk.edit','kk.delete','tagihan_iuran.view','pembayaran_iuran.view','pengeluaran.view','pengeluaran.check','laporan.view'],
            'WARGA' => ['dashboard.view','tagihan_iuran.view'],
        ];
        // Normalisasi matriks RBAC final agar permission lama dari build sebelumnya
        // tidak tertinggal dan membuat menu/kewenangan menjadi terlalu luas.
        $finalRoleIds = array_values($roleMap);
        if ($finalRoleIds) {
            $this->db->table('role_permissions')->whereIn('role_id', $finalRoleIds)->delete();
        }
        foreach ($assignments as $roleCode=>$codes) {
            if (!isset($roleMap[$roleCode])) continue;
            foreach (array_unique($codes) as $code) {
                if (!isset($permMap[$code])) continue;
                $this->db->table('role_permissions')->insert([
                    'role_id'=>$roleMap[$roleCode],
                    'permission_id'=>$permMap[$code],
                    'created_at'=>$now,
                    'updated_at'=>$now,
                ]);
            }
        }
    }

    public function down() {}
}
