<?php

namespace App\Database\Migrations;

use CodeIgniter\Database\Migration;

class CreateMasterWilayahTable extends Migration
{
    public function up()
    {
        $this->forge->addField([
            'id' => [
                'type'           => 'INT',
                'unsigned'       => true,
                'auto_increment' => true,
            ],

            'kode' => [
                'type'       => 'VARCHAR',
                'constraint' => 50,
            ],

            'nama' => [
                'type'       => 'VARCHAR',
                'constraint' => 150,
            ],

            'jenis' => [
                'type'       => 'ENUM',
                'constraint' => ['PROVINSI', 'KABUPATEN', 'KECAMATAN', 'KELURAHAN', 'RW', 'RT'],
            ],

            'kode_parent' => [
                'type'       => 'VARCHAR',
                'constraint' => 50,
                'null'       => true,
            ],

            'alamat' => [
                'type'       => 'TEXT',
                'null'       => true,
            ],

            'status' => [
                'type'       => 'ENUM',
                'constraint' => ['aktif', 'nonaktif'],
                'default'    => 'aktif',
            ],

            'created_at' => [
                'type' => 'DATETIME',
                'null' => true,
            ],

            'updated_at' => [
                'type' => 'DATETIME',
                'null' => true,
            ],
        ]);

        $this->forge->addKey('id', true);
        $this->forge->addUniqueKey(['kode']);
        $this->forge->addKey(['jenis']);
        $this->forge->addKey(['kode_parent']);

        $this->forge->createTable('master_wilayah');
    }

    public function down()
    {
        $this->forge->dropTable('master_wilayah');
    }
}