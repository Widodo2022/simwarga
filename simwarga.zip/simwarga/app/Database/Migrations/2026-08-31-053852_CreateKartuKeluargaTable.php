<?php

namespace App\Database\Migrations;

use CodeIgniter\Database\Migration;

class CreateKartuKeluargaTable extends Migration
{
    public function up()
    {
        $this->forge->addField([
            'id' => [
                'type'           => 'INT',
                'unsigned'       => true,
                'auto_increment' => true,
            ],

            'no_kk' => [
                'type'       => 'VARCHAR',
                'constraint' => 16,
            ],

            'kepala_keluarga' => [
                'type'       => 'VARCHAR',
                'constraint' => 150,
            ],

            'kode_wilayah' => [
                'type'       => 'VARCHAR',
                'constraint' => 50,
                'null'       => true,
            ],

            'alamat' => [
                'type' => 'TEXT',
                'null' => true,
            ],

            'status' => [
                'type'       => 'ENUM',
                'constraint' => ['aktif', 'nonaktif'],
                'default'    => 'aktif',
            ],

            'created_at' => [
                'type' => 'DATETIME',
                'null' => true,
            ],

            'updated_at' => [
                'type' => 'DATETIME',
                'null' => true,
            ],
        ]);

        $this->forge->addKey('id', true);
        $this->forge->addUniqueKey('no_kk');
        $this->forge->addKey('kode_wilayah');
        $this->forge->addKey('status');

        $this->forge->createTable('kartu_keluarga');
    }

    public function down()
    {
        $this->forge->dropTable('kartu_keluarga');
    }
}