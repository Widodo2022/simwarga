<?php

namespace App\Database\Migrations;

use CodeIgniter\Database\Migration;

class ConfigureFinalRolesAndSystemBackup extends Migration
{
    public function up()
    {
        $db = $this->db;
        if (! $db->tableExists('roles') || ! $db->tableExists('permissions') || ! $db->tableExists('role_permissions')) {
            return;
        }

        $now = date('Y-m-d H:i:s');

        if ($db->tableExists('users') && $db->tableExists('kartu_keluarga')) {
            $fields = $db->getFieldNames('users');
            if (! in_array('no_kk', $fields, true)) {
                $db->query("ALTER TABLE users ADD COLUMN no_kk VARCHAR(16) NULL AFTER email");
                $db->query("ALTER TABLE users ADD INDEX idx_users_no_kk (no_kk)");
                $db->query("ALTER TABLE users ADD CONSTRAINT fk_users_no_kk FOREIGN KEY (no_kk) REFERENCES kartu_keluarga(no_kk) ON UPDATE CASCADE ON DELETE SET NULL");
            }
        }

        $roles = [
            ['kode'=>'ADMINISTRATOR','nama'=>'Administrator','deskripsi'=>'Pengelolaan sistem dan kewenangan administratif tingkat tertinggi. Tidak otomatis memiliki kewenangan bisnis Ketua RT.','status'=>'aktif'],
            ['kode'=>'KETUA_RT','nama'=>'Ketua RT','deskripsi'=>'Pimpinan operasional RT dan pemberi persetujuan akhir sesuai kewenangan.','status'=>'aktif'],
            ['kode'=>'BENDAHARA','nama'=>'Bendahara','deskripsi'=>'Pengelolaan iuran dan transaksi keuangan sesuai permission.','status'=>'aktif'],
            ['kode'=>'SEKRETARIS','nama'=>'Sekretaris','deskripsi'=>'Administrasi dan pemeriksaan pengeluaran sesuai permission.','status'=>'aktif'],
            ['kode'=>'WARGA','nama'=>'Warga','deskripsi'=>'Akses read-only terhadap informasi yang memang menjadi hak warga.','status'=>'aktif'],
        ];
        foreach ($roles as $role) {
            if ($db->table('roles')->where('kode', $role['kode'])->countAllResults() === 0) {
                $db->table('roles')->insert($role + ['created_at'=>$now,'updated_at'=>$now]);
            }
        }

        // Akun admin lama dengan role ADMIN dinaikkan identitasnya menjadi Administrator.
        if ($db->table('roles')->where('kode','ADMINISTRATOR')->countAllResults() > 0 && $db->table('roles')->where('kode','ADMIN')->countAllResults() > 0) {
            $adminRole = $db->table('roles')->where('kode','ADMIN')->get()->getRowArray();
            $administratorRole = $db->table('roles')->where('kode','ADMINISTRATOR')->get()->getRowArray();
            if ($adminRole && $administratorRole && $db->table('user_roles')->where('role_id',$adminRole['id'])->countAllResults() > 0) {
                $db->table('user_roles')->where('role_id',$adminRole['id'])->update(['role_id'=>$administratorRole['id'],'updated_at'=>$now]);
            }
        }

        $permissions = [
            ['system.backup','Backup Sistem','Sistem','backup','Membuat backup database/source'],
            ['system.backup.download','Download Backup Sistem','Sistem','backup_download','Mengunduh file backup'],
            ['system.restore','Restore Sistem','Sistem','restore','Melakukan restore database/source'],
            ['system.backup.history','Riwayat Backup Sistem','Sistem','history','Melihat riwayat backup'],
            ['dashboard.view','Lihat Dashboard','Dashboard','view','Melihat dashboard'],
            ['warga.view','Lihat Data Warga','Warga','view','Melihat data warga'],
            ['kk.view','Lihat Data Kartu Keluarga','Kartu Keluarga','view','Melihat data KK'],
            ['tagihan_iuran.view','Lihat Tagihan Iuran','Tagihan Iuran','view','Melihat tagihan'],
            ['pembayaran_iuran.view','Lihat Pembayaran Iuran','Pembayaran Iuran','view','Melihat pembayaran'],
            ['pengeluaran.view','Lihat Pengeluaran','Pengeluaran','view','Melihat pengeluaran'],
            ['laporan.view','Lihat Laporan','Laporan','view','Melihat laporan'],
            ['tagihan_iuran.create','Generate Tagihan Iuran','Tagihan Iuran','create','Generate tagihan'],
            ['pembayaran_iuran.create','Catat Pembayaran Iuran','Pembayaran Iuran','create','Mencatat pembayaran'],
            ['pembayaran_iuran.cancel','Batalkan Pembayaran Iuran','Pembayaran Iuran','cancel','Membatalkan pembayaran'],
            ['tagihan_iuran.cancel','Batalkan Tagihan Iuran','Tagihan Iuran','cancel','Membatalkan tagihan'],
            ['tagihan_iuran.restore','Pulihkan Tagihan Iuran','Tagihan Iuran','restore','Memulihkan tagihan'],
            ['pengeluaran.create','Buat Pengeluaran','Pengeluaran','create','Membuat draft pengeluaran'],
            ['pengeluaran.edit','Edit Pengeluaran','Pengeluaran','edit','Mengubah pengeluaran'],
            ['pengeluaran.submit','Kirim Pengeluaran','Pengeluaran','submit','Mengirim pengeluaran'],
            ['pengeluaran.check','Periksa Pengeluaran','Pengeluaran','check','Memeriksa pengeluaran'],
            ['pengeluaran.approve','Setujui Pengeluaran','Pengeluaran','approve','Menyetujui/menolak pengeluaran'],
            ['pengeluaran.delete','Hapus Permanen Pengeluaran','Pengeluaran','delete','Menghapus pengeluaran dengan audit'],
            ['pengeluaran.master.manage','Kelola Master Pengeluaran','Pengeluaran','master','Mengelola master pengeluaran'],
            ['keuangan.opening_balance.manage','Kelola Saldo Awal','Keuangan','opening_balance','Menetapkan saldo awal'],
        ];
        foreach ($permissions as $p) {
            if ($db->table('permissions')->where('kode',$p[0])->countAllResults() === 0) {
                $db->table('permissions')->insert(['kode'=>$p[0],'nama'=>$p[1],'modul'=>$p[2],'aksi'=>$p[3],'deskripsi'=>$p[4],'status'=>'aktif','created_at'=>$now,'updated_at'=>$now]);
            }
        }

        $roleMap = [];
        foreach ($db->table('roles')->get()->getResultArray() as $r) $roleMap[$r['kode']] = (int)$r['id'];
        $permMap = [];
        foreach ($db->table('permissions')->get()->getResultArray() as $p) $permMap[$p['kode']] = (int)$p['id'];

        $assignments = [
            'ADMINISTRATOR' => ['dashboard.view','warga.view','kk.view','tagihan_iuran.view','pembayaran_iuran.view','pengeluaran.view','laporan.view','tagihan_iuran.cancel','tagihan_iuran.restore','system.backup','system.backup.download','system.restore','system.backup.history'],
            'KETUA_RT' => ['dashboard.view','warga.view','kk.view','tagihan_iuran.view','pembayaran_iuran.view','pengeluaran.view','laporan.view','tagihan_iuran.cancel','tagihan_iuran.restore','pengeluaran.approve'],
            'BENDAHARA' => ['dashboard.view','tagihan_iuran.view','pembayaran_iuran.view','pengeluaran.view','laporan.view','tagihan_iuran.create','pembayaran_iuran.create','pembayaran_iuran.cancel','tagihan_iuran.cancel','pengeluaran.create','pengeluaran.edit','pengeluaran.submit','keuangan.opening_balance.manage'],
            'SEKRETARIS' => ['dashboard.view','warga.view','kk.view','tagihan_iuran.view','pembayaran_iuran.view','pengeluaran.view','laporan.view','pengeluaran.check'],
            'WARGA' => ['dashboard.view','tagihan_iuran.view','pembayaran_iuran.view'],
        ];
        foreach ($assignments as $roleCode => $codes) {
            if (! isset($roleMap[$roleCode])) continue;
            foreach ($codes as $code) {
                if (! isset($permMap[$code])) continue;
                $exists = $db->table('role_permissions')->where('role_id',$roleMap[$roleCode])->where('permission_id',$permMap[$code])->countAllResults();
                if ($exists === 0) $db->table('role_permissions')->insert(['role_id'=>$roleMap[$roleCode],'permission_id'=>$permMap[$code],'created_at'=>$now,'updated_at'=>$now]);
            }
        }

        // Pastikan user ADMIN yang ada sekarang menjadi Administrator bila belum punya role final.
        if ($db->table('users')->where('username','admin')->countAllResults() > 0 && isset($roleMap['ADMINISTRATOR'])) {
            $user = $db->table('users')->where('username','admin')->get()->getRowArray();
            if ($user) {
                $hasFinal = $db->table('user_roles')->where('user_id',$user['id'])->where('role_id',$roleMap['ADMINISTRATOR'])->countAllResults();
                if ($hasFinal === 0) {
                    $db->table('user_roles')->insert(['user_id'=>$user['id'],'role_id'=>$roleMap['ADMINISTRATOR'],'created_at'=>$now,'updated_at'=>$now]);
                }
            }
        }
    }

    public function down()
    {
        // Tidak menghapus role/permission historis agar rollback aplikasi tidak merusak akun.
    }
}
