<?php

namespace App\Database\Migrations;

use CodeIgniter\Database\Migration;

class CreateWargaTable extends Migration
{
    public function up()
    {
        $this->forge->addField([
            'id' => [
                'type'           => 'INT',
                'unsigned'       => true,
                'auto_increment' => true,
            ],

            'nik' => [
                'type'       => 'VARCHAR',
                'constraint' => 16,
            ],

            'no_kk' => [
                'type'       => 'VARCHAR',
                'constraint' => 16,
            ],

            'nama_lengkap' => [
                'type'       => 'VARCHAR',
                'constraint' => 150,
            ],

            'jenis_kelamin' => [
                'type'       => 'ENUM',
                'constraint' => ['L', 'P'],
            ],

            'tempat_lahir' => [
                'type'       => 'VARCHAR',
                'constraint' => 100,
                'null'       => true,
            ],

            'tanggal_lahir' => [
                'type' => 'DATE',
                'null' => true,
            ],

            'agama' => [
                'type'       => 'VARCHAR',
                'constraint' => 30,
                'null'       => true,
            ],

            'pendidikan' => [
                'type'       => 'VARCHAR',
                'constraint' => 100,
                'null'       => true,
            ],

            'pekerjaan' => [
                'type'       => 'VARCHAR',
                'constraint' => 100,
                'null'       => true,
            ],

            'no_hp' => [
                'type'       => 'VARCHAR',
                'constraint' => 20,
                'null'       => true,
            ],

            'hubungan_keluarga' => [
                'type'       => 'ENUM',
                'constraint' => [
                    'KEPALA_KELUARGA',
                    'ISTRI',
                    'ANAK',
                    'ORANG_TUA',
                    'FAMILI_LAIN',
                    'LAINNYA',
                ],
            ],

            'status' => [
                'type'       => 'ENUM',
                'constraint' => ['aktif', 'nonaktif'],
                'default'    => 'aktif',
            ],

            'created_at' => [
                'type' => 'DATETIME',
                'null' => true,
            ],

            'updated_at' => [
                'type' => 'DATETIME',
                'null' => true,
            ],
        ]);

        $this->forge->addKey('id', true);
        $this->forge->addUniqueKey('nik');
        $this->forge->addKey('no_kk');
        $this->forge->addKey('nama_lengkap');
        $this->forge->addKey('jenis_kelamin');
        $this->forge->addKey('status');

        $this->forge->createTable('warga');
    }

    public function down()
    {
        $this->forge->dropTable('warga');
    }
}