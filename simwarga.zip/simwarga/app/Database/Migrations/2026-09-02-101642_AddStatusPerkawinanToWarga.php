<?php

namespace App\Database\Migrations;

use CodeIgniter\Database\Migration;

class AddStatusPerkawinanToWarga extends Migration
{
    public function up()
    {
        // Aman dijalankan pada database lama maupun database baru.
        if ($this->db->fieldExists('status_perkawinan', 'warga')) {
            return;
        }

        $this->forge->addColumn('warga', [
            'status_perkawinan' => [
                'type'       => 'ENUM',
                'constraint' => [
                    'KAWIN',
                    'BELUM_KAWIN',
                    'JANDA',
                    'DUDA',
                    'MENINGGAL',
                    'LAIN_LAIN',
                ],
                'default'    => 'BELUM_KAWIN',
                'null'       => false,
                'after'      => 'hubungan_keluarga',
            ],
        ]);
    }

    public function down()
    {
        if ($this->db->fieldExists('status_perkawinan', 'warga')) {
            $this->forge->dropColumn('warga', 'status_perkawinan');
        }
    }
}
