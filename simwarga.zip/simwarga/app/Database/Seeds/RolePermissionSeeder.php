<?php

namespace App\Database\Seeds;

use CodeIgniter\Database\Seeder;

class RolePermissionSeeder extends Seeder
{
    public function run()
    {
        $db = \Config\Database::connect();

        $roles = $db->table('roles')
            ->get()
            ->getResultArray();

        $permissions = $db->table('permissions')
            ->get()
            ->getResultArray();

        $roleMap = [];

        foreach ($roles as $role) {
            $roleMap[$role['kode']] = $role['id'];
        }

        $permissionMap = [];

        foreach ($permissions as $permission) {
            $permissionMap[$permission['kode']] = $permission['id'];
        }

        /*
         * SUPERADMIN
         * Semua permission.
         */
        $superadminPermissions = array_keys($permissionMap);

        /*
         * ADMIN RT
         */
        $adminRtPermissions = [
            'dashboard.view',

            'warga.view',
            'warga.create',
            'warga.edit',
            'warga.delete',

            'kk.view',
            'kk.create',
            'kk.edit',
            'kk.delete',

            'iuran.view',

            'kas.view',

            'surat.view',
            'surat.create',
            'surat.edit',
            'surat.delete',
            'surat.print',

            'laporan.view',
            'laporan.export',

            'user.view',
        ];

        /*
         * BENDAHARA
         */
        $bendaharaPermissions = [
            'dashboard.view',

            'iuran.view',
            'iuran.create',
            'iuran.edit',
            'iuran.delete',

            'kas.view',
            'kas.create',
            'kas.edit',
            'kas.delete',

            'laporan.view',
            'laporan.export',
        ];

        /*
         * SEKRETARIS
         */
        $sekretarisPermissions = [
            'dashboard.view',

            'warga.view',
            'warga.create',
            'warga.edit',

            'kk.view',
            'kk.create',
            'kk.edit',

            'surat.view',
            'surat.create',
            'surat.edit',
            'surat.print',

            'laporan.view',
            'laporan.export',
        ];

        /*
         * VIEWER
         */
        $viewerPermissions = [
            'dashboard.view',

            'warga.view',

            'kk.view',

            'iuran.view',

            'kas.view',

            'surat.view',

            'laporan.view',
        ];

        $rolePermissions = [
            'SUPERADMIN' => $superadminPermissions,
            'ADMIN_RT'   => $adminRtPermissions,
            'BENDAHARA'  => $bendaharaPermissions,
            'SEKRETARIS' => $sekretarisPermissions,
            'VIEWER'     => $viewerPermissions,
        ];

        $builder = $db->table('role_permissions');

        foreach ($rolePermissions as $roleCode => $permissionCodes) {

            if (! isset($roleMap[$roleCode])) {
                continue;
            }

            $roleId = $roleMap[$roleCode];

            foreach ($permissionCodes as $permissionCode) {

                if (! isset($permissionMap[$permissionCode])) {
                    continue;
                }

                $permissionId = $permissionMap[$permissionCode];

                $exists = $builder
                    ->where('role_id', $roleId)
                    ->where('permission_id', $permissionId)
                    ->countAllResults();

                if ($exists === 0) {
                    $builder->insert([
                        'role_id'       => $roleId,
                        'permission_id' => $permissionId,
                        'created_at'    => date('Y-m-d H:i:s'),
                        'updated_at'    => date('Y-m-d H:i:s'),
                    ]);
                }
            }
        }
    }
}