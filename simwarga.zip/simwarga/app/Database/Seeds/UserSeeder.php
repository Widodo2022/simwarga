<?php

namespace App\Database\Seeds;

use CodeIgniter\Database\Seeder;

class UserSeeder extends Seeder
{
    public function run()
    {
        $db = \Config\Database::connect();

        /*
         * Cari role SUPERADMIN dari database.
         * Tidak menggunakan ID yang ditanam permanen.
         */
        $role = $db->table('roles')
            ->where('kode', 'SUPERADMIN')
            ->where('status', 'aktif')
            ->get()
            ->getRowArray();

        // Kompatibel dengan database yang sudah memiliki role ADMIN.
        if (! $role) {
            $role = $db->table('roles')
                ->where('kode', 'ADMIN')
                ->where('status', 'aktif')
                ->get()
                ->getRowArray();
        }

        if (! $role) {
            throw new \RuntimeException(
                'Role admin belum tersedia. Jalankan RoleSeeder terlebih dahulu.'
            );
        }

        /*
         * Data akun administrator pertama.
         *
         * Password hanya digunakan saat pembuatan akun.
         * Yang disimpan ke database adalah hasil hash.
         */
        $username = 'admin';
        $password = 'Admin@12345';

        $userBuilder = $db->table('users');

        $user = $userBuilder
            ->where('username', $username)
            ->get()
            ->getRowArray();

        if (! $user) {
            $userBuilder->insert([
                'username'     => $username,
                'password'     => password_hash($password, PASSWORD_DEFAULT),
                'nama_lengkap' => 'Administrator',
                'email'        => 'admin@simwarga.local',
                'status'       => 'aktif',
            ]);

            $userId = $db->insertID();
        } else {
            $userId = $user['id'];
        }

        /*
         * Hubungkan user dengan role SUPERADMIN.
         */
        $userRoleBuilder = $db->table('user_roles');

        $userRoleExists = $userRoleBuilder
            ->where('user_id', $userId)
            ->where('role_id', $role['id'])
            ->countAllResults();

        if ($userRoleExists === 0) {
            $userRoleBuilder->insert([
                'user_id' => $userId,
                'role_id' => $role['id'],
            ]);
        }
    }
}   