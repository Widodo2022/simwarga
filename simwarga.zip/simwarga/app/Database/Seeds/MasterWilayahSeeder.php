<?php

namespace App\Database\Seeds;

use CodeIgniter\Database\Seeder;

class MasterWilayahSeeder extends Seeder
{
    public function run()
    {
        $data = [
            [
                'kode'        => 'RW023',
                'nama'        => 'RW 023',
                'jenis'       => 'RW',
                'kode_parent' => null,
                'alamat'      => null,
                'status'      => 'aktif',
            ],
            [
                'kode'        => 'RT007',
                'nama'        => 'RT 007',
                'jenis'       => 'RT',
                'kode_parent' => 'RW023',
                'alamat'      => null,
                'status'      => 'aktif',
            ],
        ];

        $this->db->table('master_wilayah')->insertBatch($data);
    }
}