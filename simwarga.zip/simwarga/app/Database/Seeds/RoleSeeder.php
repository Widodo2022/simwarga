<?php

namespace App\Database\Seeds;

use CodeIgniter\Database\Seeder;

class RoleSeeder extends Seeder
{
    public function run()
    {
        $roles = [
            [
                'kode'      => 'SUPERADMIN',
                'nama'      => 'Super Administrator',
                'deskripsi' => 'Akses penuh terhadap seluruh sistem',
                'status'    => 'aktif',
            ],
            [
                'kode'      => 'ADMIN_RT',
                'nama'      => 'Administrator RT',
                'deskripsi' => 'Mengelola administrasi RT',
                'status'    => 'aktif',
            ],
            [
                'kode'      => 'BENDAHARA',
                'nama'      => 'Bendahara',
                'deskripsi' => 'Mengelola iuran dan keuangan RT',
                'status'    => 'aktif',
            ],
            [
                'kode'      => 'SEKRETARIS',
                'nama'      => 'Sekretaris',
                'deskripsi' => 'Mengelola administrasi dan surat menyurat',
                'status'    => 'aktif',
            ],
            [
                'kode'      => 'VIEWER',
                'nama'      => 'Viewer',
                'deskripsi' => 'Hanya dapat melihat data sesuai hak akses',
                'status'    => 'aktif',
            ],
        ];

        $builder = $this->db->table('roles');

        foreach ($roles as $role) {
            $exists = $builder
                ->where('kode', $role['kode'])
                ->countAllResults();

            if ($exists === 0) {
                $builder->insert($role);
            }
        }
    }
}