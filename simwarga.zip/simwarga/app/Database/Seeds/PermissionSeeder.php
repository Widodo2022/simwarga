<?php

namespace App\Database\Seeds;

use CodeIgniter\Database\Seeder;

class PermissionSeeder extends Seeder
{
    public function run()
    {
        $permissions = [
            // Dashboard
            [
                'kode'       => 'dashboard.view',
                'nama'       => 'Lihat Dashboard',
                'modul'      => 'Dashboard',
                'aksi'       => 'view',
                'deskripsi'  => 'Melihat dashboard aplikasi',
                'status'     => 'aktif',
            ],

            // Warga
            [
                'kode'       => 'warga.view',
                'nama'       => 'Lihat Data Warga',
                'modul'      => 'Warga',
                'aksi'       => 'view',
                'deskripsi'  => 'Melihat data warga',
                'status'     => 'aktif',
            ],
            [
                'kode'       => 'warga.create',
                'nama'       => 'Tambah Data Warga',
                'modul'      => 'Warga',
                'aksi'       => 'create',
                'deskripsi'  => 'Menambah data warga',
                'status'     => 'aktif',
            ],
            [
                'kode'       => 'warga.edit',
                'nama'       => 'Edit Data Warga',
                'modul'      => 'Warga',
                'aksi'       => 'edit',
                'deskripsi'  => 'Mengubah data warga',
                'status'     => 'aktif',
            ],
            [
                'kode'       => 'warga.delete',
                'nama'       => 'Hapus Data Warga',
                'modul'      => 'Warga',
                'aksi'       => 'delete',
                'deskripsi'  => 'Menghapus data warga',
                'status'     => 'aktif',
            ],

            // Kartu Keluarga
            [
                'kode'       => 'kk.view',
                'nama'       => 'Lihat Data Kartu Keluarga',
                'modul'      => 'Kartu Keluarga',
                'aksi'       => 'view',
                'deskripsi'  => 'Melihat data kartu keluarga',
                'status'     => 'aktif',
            ],
            [
                'kode'       => 'kk.create',
                'nama'       => 'Tambah Kartu Keluarga',
                'modul'      => 'Kartu Keluarga',
                'aksi'       => 'create',
                'deskripsi'  => 'Menambah kartu keluarga',
                'status'     => 'aktif',
            ],
            [
                'kode'       => 'kk.edit',
                'nama'       => 'Edit Kartu Keluarga',
                'modul'      => 'Kartu Keluarga',
                'aksi'       => 'edit',
                'deskripsi'  => 'Mengubah kartu keluarga',
                'status'     => 'aktif',
            ],
            [
                'kode'       => 'kk.delete',
                'nama'       => 'Hapus Kartu Keluarga',
                'modul'      => 'Kartu Keluarga',
                'aksi'       => 'delete',
                'deskripsi'  => 'Menghapus kartu keluarga',
                'status'     => 'aktif',
            ],

            // Iuran
            [
                'kode'       => 'iuran.view',
                'nama'       => 'Lihat Data Iuran',
                'modul'      => 'Iuran',
                'aksi'       => 'view',
                'deskripsi'  => 'Melihat data iuran warga',
                'status'     => 'aktif',
            ],
            [
                'kode'       => 'iuran.create',
                'nama'       => 'Tambah Data Iuran',
                'modul'      => 'Iuran',
                'aksi'       => 'create',
                'deskripsi'  => 'Menambah transaksi iuran',
                'status'     => 'aktif',
            ],
            [
                'kode'       => 'iuran.edit',
                'nama'       => 'Edit Data Iuran',
                'modul'      => 'Iuran',
                'aksi'       => 'edit',
                'deskripsi'  => 'Mengubah transaksi iuran',
                'status'     => 'aktif',
            ],
            [
                'kode'       => 'iuran.delete',
                'nama'       => 'Hapus Data Iuran',
                'modul'      => 'Iuran',
                'aksi'       => 'delete',
                'deskripsi'  => 'Menghapus transaksi iuran',
                'status'     => 'aktif',
            ],

            // Kas
            [
                'kode'       => 'kas.view',
                'nama'       => 'Lihat Kas',
                'modul'      => 'Kas',
                'aksi'       => 'view',
                'deskripsi'  => 'Melihat kas RT',
                'status'     => 'aktif',
            ],
            [
                'kode'       => 'kas.create',
                'nama'       => 'Tambah Kas',
                'modul'      => 'Kas',
                'aksi'       => 'create',
                'deskripsi'  => 'Menambah transaksi kas',
                'status'     => 'aktif',
            ],
            [
                'kode'       => 'kas.edit',
                'nama'       => 'Edit Kas',
                'modul'      => 'Kas',
                'aksi'       => 'edit',
                'deskripsi'  => 'Mengubah transaksi kas',
                'status'     => 'aktif',
            ],
            [
                'kode'       => 'kas.delete',
                'nama'       => 'Hapus Kas',
                'modul'      => 'Kas',
                'aksi'       => 'delete',
                'deskripsi'  => 'Menghapus transaksi kas',
                'status'     => 'aktif',
            ],

            // Surat
            [
                'kode'       => 'surat.view',
                'nama'       => 'Lihat Surat',
                'modul'      => 'Surat',
                'aksi'       => 'view',
                'deskripsi'  => 'Melihat data surat',
                'status'     => 'aktif',
            ],
            [
                'kode'       => 'surat.create',
                'nama'       => 'Buat Surat',
                'modul'      => 'Surat',
                'aksi'       => 'create',
                'deskripsi'  => 'Membuat surat warga',
                'status'     => 'aktif',
            ],
            [
                'kode'       => 'surat.edit',
                'nama'       => 'Edit Surat',
                'modul'      => 'Surat',
                'aksi'       => 'edit',
                'deskripsi'  => 'Mengubah surat',
                'status'     => 'aktif',
            ],
            [
                'kode'       => 'surat.delete',
                'nama'       => 'Hapus Surat',
                'modul'      => 'Surat',
                'aksi'       => 'delete',
                'deskripsi'  => 'Menghapus surat',
                'status'     => 'aktif',
            ],
            [
                'kode'       => 'surat.print',
                'nama'       => 'Cetak Surat',
                'modul'      => 'Surat',
                'aksi'       => 'print',
                'deskripsi'  => 'Mencetak surat',
                'status'     => 'aktif',
            ],

            // Laporan
            [
                'kode'       => 'laporan.view',
                'nama'       => 'Lihat Laporan',
                'modul'      => 'Laporan',
                'aksi'       => 'view',
                'deskripsi'  => 'Melihat laporan',
                'status'     => 'aktif',
            ],
            [
                'kode'       => 'laporan.export',
                'nama'       => 'Export Laporan',
                'modul'      => 'Laporan',
                'aksi'       => 'export',
                'deskripsi'  => 'Export laporan',
                'status'     => 'aktif',
            ],

            // User
            [
                'kode'       => 'user.view',
                'nama'       => 'Lihat User',
                'modul'      => 'User',
                'aksi'       => 'view',
                'deskripsi'  => 'Melihat pengguna',
                'status'     => 'aktif',
            ],
            [
                'kode'       => 'user.create',
                'nama'       => 'Tambah User',
                'modul'      => 'User',
                'aksi'       => 'create',
                'deskripsi'  => 'Menambah pengguna',
                'status'     => 'aktif',
            ],
            [
                'kode'       => 'user.edit',
                'nama'       => 'Edit User',
                'modul'      => 'User',
                'aksi'       => 'edit',
                'deskripsi'  => 'Mengubah pengguna',
                'status'     => 'aktif',
            ],
            [
                'kode'       => 'user.delete',
                'nama'       => 'Hapus User',
                'modul'      => 'User',
                'aksi'       => 'delete',
                'deskripsi'  => 'Menghapus pengguna',
                'status'     => 'aktif',
            ],

            // Role
            [
                'kode'       => 'role.view',
                'nama'       => 'Lihat Role',
                'modul'      => 'Role',
                'aksi'       => 'view',
                'deskripsi'  => 'Melihat role',
                'status'     => 'aktif',
            ],
            [
                'kode'       => 'role.create',
                'nama'       => 'Tambah Role',
                'modul'      => 'Role',
                'aksi'       => 'create',
                'deskripsi'  => 'Menambah role',
                'status'     => 'aktif',
            ],
            [
                'kode'       => 'role.edit',
                'nama'       => 'Edit Role',
                'modul'      => 'Role',
                'aksi'       => 'edit',
                'deskripsi'  => 'Mengubah role',
                'status'     => 'aktif',
            ],
            [
                'kode'       => 'role.delete',
                'nama'       => 'Hapus Role',
                'modul'      => 'Role',
                'aksi'       => 'delete',
                'deskripsi'  => 'Menghapus role',
                'status'     => 'aktif',
            ],

            // Permission
            [
                'kode'       => 'permission.view',
                'nama'       => 'Lihat Permission',
                'modul'      => 'Permission',
                'aksi'       => 'view',
                'deskripsi'  => 'Melihat permission',
                'status'     => 'aktif',
            ],
        ];

        $builder = $this->db->table('permissions');

        foreach ($permissions as $permission) {
            $exists = $builder
                ->where('kode', $permission['kode'])
                ->countAllResults();

            if ($exists === 0) {
                $builder->insert($permission);
            }
        }
    }
}