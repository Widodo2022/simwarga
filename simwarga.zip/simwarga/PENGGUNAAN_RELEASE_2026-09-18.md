# SIMWARGA — Release Penggunaan Awal

Build ini menambahkan penyempurnaan aturan hak akses dan modul Backup & Restore Sistem.

## Role final

- ADMINISTRATOR — pengelolaan sistem. Tidak otomatis menjadi Ketua RT.
- KETUA_RT — kewenangan pimpinan/approval operasional.
- BENDAHARA — iuran dan keuangan sesuai permission.
- SEKRETARIS — administrasi/pemeriksaan sesuai permission.
- WARGA — read-only.

## Restore tagihan

Administrator dan Ketua RT sama-sama dapat restore tagihan melalui permission `tagihan_iuran.restore`.

## Backup & Restore Sistem

Hanya Administrator:

- `system.backup`
- `system.backup.download`
- `system.restore`
- `system.backup.history`

Backup database dibuat dengan transaksi konsisten dan source aplikasi dibuat sebagai arsip. File backup disimpan di `writable/backups/system`, yang dilindungi dari akses langsung web.

Sebelum restore database, sistem membuat emergency backup otomatis. Restore source aplikasi melalui web hanya menyiapkan paket restore; aplikasi aktif tidak ditimpa langsung dari request web untuk menghindari kerusakan aplikasi di tengah proses.

## Warga

Role WARGA hanya dapat GET dashboard dan melihat tagihan. Tidak dapat melakukan POST/ubah/hapus dan tidak dapat membuka modul administrasi/keuangan internal. Akun Warga dapat dihubungkan ke KK melalui kolom `users.no_kk`; daftar tagihan dibatasi ke KK tersebut.

## Instalasi aman

1. Backup database dan source aplikasi yang sedang berjalan.
2. Salin build ini ke project SIMWARGA.
3. Pastikan `.env` mengarah ke database `simwarga_rt007` dan PHP yang digunakan adalah PHP XAMPP.
4. Jalankan `php spark migrate` memakai `/opt/lampp/bin/php` di server XAMPP.
5. Jangan gunakan `migrate:refresh` pada database yang sudah berisi data.
6. Setelah migration selesai, logout/login kembali agar session role dan permission dimuat ulang.
7. Login akun `admin` yang sudah ada akan dipetakan ke role `ADMINISTRATOR` oleh migration.
8. Buat akun untuk Ketua RT/Bendahara/Sekretaris/Warga melalui mekanisme user management yang tersedia/akan dikembangkan.

## Catatan

Backup & Restore Sistem adalah fitur administratif sensitif. Gunakan hanya setelah memastikan backup berhasil dibuat dan dapat dibaca. Simpan salinan backup penting di luar server aplikasi.
